var e=Object.create,t=Object.defineProperty,n=Object.getOwnPropertyDescriptor,r=Object.getOwnPropertyNames,i=Object.getPrototypeOf,a=Object.prototype.hasOwnProperty,o=(e,t)=>()=>(t||(e((t={exports:{}}).exports,t),e=null),t.exports),s=(e,i,o,s)=>{if(i&&typeof i==`object`||typeof i==`function`)for(var c=r(i),l=0,u=c.length,d;l<u;l++)d=c[l],!a.call(e,d)&&d!==o&&t(e,d,{get:(e=>i[e]).bind(null,d),enumerable:!(s=n(i,d))||s.enumerable});return e},c=(n,r,o)=>(o=n==null?{}:e(i(n)),s(r||!n||!n.__esModule||!a.call(n,`default`)?t(o,`default`,{value:n,enumerable:!0}):o,n));(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),t.credentials=e.crossOrigin===`use-credentials`?`include`:e.crossOrigin===`anonymous`?`omit`:`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var l=o((e=>{var t=Symbol.for(`react.transitional.element`),n=Symbol.for(`react.portal`),r=Symbol.for(`react.fragment`),i=Symbol.for(`react.strict_mode`),a=Symbol.for(`react.profiler`),o=Symbol.for(`react.consumer`),s=Symbol.for(`react.context`),c=Symbol.for(`react.forward_ref`),l=Symbol.for(`react.suspense`),u=Symbol.for(`react.memo`),d=Symbol.for(`react.lazy`),f=Symbol.for(`react.activity`),p=Symbol.for(`react.view_transition`),m=Symbol.iterator;function h(e){return typeof e!=`object`||!e?null:(e=m&&e[m]||e[`@@iterator`],typeof e==`function`?e:null)}var g={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},_=Object.assign,v={};function y(e,t,n){this.props=e,this.context=t,this.refs=v,this.updater=n||g}y.prototype.isReactComponent={},y.prototype.setState=function(e,t){if(typeof e!=`object`&&typeof e!=`function`&&e!=null)throw Error(`takes an object of state variables to update or a function which returns an object of state variables.`);this.updater.enqueueSetState(this,e,t,`setState`)},y.prototype.forceUpdate=function(e){this.updater.enqueueForceUpdate(this,e,`forceUpdate`)};function b(){}b.prototype=y.prototype;function ee(e,t,n){this.props=e,this.context=t,this.refs=v,this.updater=n||g}var te=ee.prototype=new b;te.constructor=ee,_(te,y.prototype),te.isPureReactComponent=!0;var ne=Array.isArray;function re(){}var x={H:null,A:null,T:null,S:null},ie=Object.prototype.hasOwnProperty;function S(e,n,r){var i=r.ref;return{$$typeof:t,type:e,key:n,ref:i===void 0?null:i,props:r}}function ae(e,t){return S(e.type,t,e.props)}function C(e){return typeof e==`object`&&!!e&&e.$$typeof===t}function w(e){var t={"=":`=0`,":":`=2`};return`$`+e.replace(/[=:]/g,function(e){return t[e]})}var oe=/\/+/g;function se(e,t){return typeof e==`object`&&e&&e.key!=null?w(``+e.key):t.toString(36)}function ce(e){switch(e.status){case`fulfilled`:return e.value;case`rejected`:throw e.reason;default:switch(typeof e.status==`string`?e.then(re,re):(e.status=`pending`,e.then(function(t){e.status===`pending`&&(e.status=`fulfilled`,e.value=t)},function(t){e.status===`pending`&&(e.status=`rejected`,e.reason=t)})),e.status){case`fulfilled`:return e.value;case`rejected`:throw e.reason}}throw e}function le(e,r,i,a,o){var s=typeof e;(s===`undefined`||s===`boolean`)&&(e=null);var c=!1;if(e===null)c=!0;else switch(s){case`bigint`:case`string`:case`number`:c=!0;break;case`object`:switch(e.$$typeof){case t:case n:c=!0;break;case d:return c=e._init,le(c(e._payload),r,i,a,o)}}if(c)return o=o(e),c=a===``?`.`+se(e,0):a,ne(o)?(i=``,c!=null&&(i=c.replace(oe,`$&/`)+`/`),le(o,r,i,``,function(e){return e})):o!=null&&(C(o)&&(o=ae(o,i+(o.key==null||e&&e.key===o.key?``:(``+o.key).replace(oe,`$&/`)+`/`)+c)),r.push(o)),1;c=0;var l=a===``?`.`:a+`:`;if(ne(e))for(var u=0;u<e.length;u++)a=e[u],s=l+se(a,u),c+=le(a,r,i,s,o);else if(u=h(e),typeof u==`function`)for(e=u.call(e),u=0;!(a=e.next()).done;)a=a.value,s=l+se(a,u++),c+=le(a,r,i,s,o);else if(s===`object`){if(typeof e.then==`function`)return le(ce(e),r,i,a,o);throw r=String(e),Error(`Objects are not valid as a React child (found: `+(r===`[object Object]`?`object with keys {`+Object.keys(e).join(`, `)+`}`:r)+`). If you meant to render a collection of children, use an array instead.`)}return c}function T(e,t,n){if(e==null)return e;var r=[],i=0;return le(e,r,``,``,function(e){return t.call(n,e,i++)}),r}function ue(e){if(e._status===-1){var t=e._result,n=t();n.then(function(t){(e._status===0||e._status===-1)&&(e._status=1,e._result=t,n.status===void 0&&(n.status=`fulfilled`,n.value=t))},function(t){(e._status===0||e._status===-1)&&(e._status=2,e._result=t,n.status===void 0&&(n.status=`rejected`,n.reason=t))}),e._status===-1&&(e._status=0,e._result=n)}if(e._status===1)return e._result.default;throw e._result}var de=typeof reportError==`function`?reportError:function(e){if(typeof window==`object`&&typeof window.ErrorEvent==`function`){var t=new window.ErrorEvent(`error`,{bubbles:!0,cancelable:!0,message:typeof e==`object`&&e&&typeof e.message==`string`?String(e.message):String(e),error:e});if(!window.dispatchEvent(t))return}else if(typeof process==`object`&&typeof process.emit==`function`){process.emit(`uncaughtException`,e);return}console.error(e)};function fe(e){var t=x.T,n={};n.types=t===null?null:t.types,x.T=n;try{var r=e(),i=x.S;i!==null&&i(n,r),typeof r==`object`&&r&&typeof r.then==`function`&&r.then(re,de)}catch(e){de(e)}finally{t!==null&&n.types!==null&&(t.types=n.types),x.T=t}}function pe(e){var t=x.T;if(t!==null){var n=t.types;n===null?t.types=[e]:n.indexOf(e)===-1&&n.push(e)}else fe(pe.bind(null,e))}var me={map:T,forEach:function(e,t,n){T(e,function(){t.apply(this,arguments)},n)},count:function(e){var t=0;return T(e,function(){t++}),t},toArray:function(e){return T(e,function(e){return e})||[]},only:function(e){if(!C(e))throw Error(`React.Children.only expected to receive a single React element child.`);return e}};e.Activity=f,e.Children=me,e.Component=y,e.Fragment=r,e.Profiler=a,e.PureComponent=ee,e.StrictMode=i,e.Suspense=l,e.ViewTransition=p,e.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=x,e.__COMPILER_RUNTIME={__proto__:null,c:function(e){return x.H.useMemoCache(e)}},e.addTransitionType=pe,e.cache=function(e){return function(){return e.apply(null,arguments)}},e.cacheSignal=function(){return null},e.cloneElement=function(e,t,n){if(e==null)throw Error(`The argument must be a React element, but you passed `+e+`.`);var r=_({},e.props),i=e.key;if(t!=null)for(a in t.key!==void 0&&(i=``+t.key),t)!ie.call(t,a)||a===`key`||a===`__self`||a===`__source`||a===`ref`&&t.ref===void 0||(r[a]=t[a]);var a=arguments.length-2;if(a===1)r.children=n;else if(1<a){for(var o=Array(a),s=0;s<a;s++)o[s]=arguments[s+2];r.children=o}return S(e.type,i,r)},e.createContext=function(e){return e={$$typeof:s,_currentValue:e,_currentValue2:e,_threadCount:0,Provider:null,Consumer:null},e.Provider=e,e.Consumer={$$typeof:o,_context:e},e},e.createElement=function(e,t,n){var r,i={},a=null;if(t!=null)for(r in t.key!==void 0&&(a=``+t.key),t)ie.call(t,r)&&r!==`key`&&r!==`__self`&&r!==`__source`&&(i[r]=t[r]);var o=arguments.length-2;if(o===1)i.children=n;else if(1<o){for(var s=Array(o),c=0;c<o;c++)s[c]=arguments[c+2];i.children=s}if(e&&e.defaultProps)for(r in o=e.defaultProps,o)i[r]===void 0&&(i[r]=o[r]);return S(e,a,i)},e.createRef=function(){return{current:null}},e.forwardRef=function(e){return{$$typeof:c,render:e}},e.isValidElement=C,e.lazy=function(e){return{$$typeof:d,_payload:{_status:-1,_result:e},_init:ue}},e.memo=function(e,t){return{$$typeof:u,type:e,compare:t===void 0?null:t}},e.startTransition=fe,e.unstable_useCacheRefresh=function(){return x.H.useCacheRefresh()},e.use=function(e){return x.H.use(e)},e.useActionState=function(e,t,n){return x.H.useActionState(e,t,n)},e.useCallback=function(e,t){return x.H.useCallback(e,t)},e.useContext=function(e){return x.H.useContext(e)},e.useDebugValue=function(){},e.useDeferredValue=function(e,t){return x.H.useDeferredValue(e,t)},e.useEffect=function(e,t){return x.H.useEffect(e,t)},e.useEffectEvent=function(e){return x.H.useEffectEvent(e)},e.useId=function(){return x.H.useId()},e.useImperativeHandle=function(e,t,n){return x.H.useImperativeHandle(e,t,n)},e.useInsertionEffect=function(e,t){return x.H.useInsertionEffect(e,t)},e.useLayoutEffect=function(e,t){return x.H.useLayoutEffect(e,t)},e.useMemo=function(e,t){return x.H.useMemo(e,t)},e.useOptimistic=function(e,t){return x.H.useOptimistic(e,t)},e.useReducer=function(e,t,n){return x.H.useReducer(e,t,n)},e.useRef=function(e){return x.H.useRef(e)},e.useState=function(e){return x.H.useState(e)},e.useSyncExternalStore=function(e,t,n){return x.H.useSyncExternalStore(e,t,n)},e.useTransition=function(){return x.H.useTransition()},e.version=`19.3.0`})),u=o(((e,t)=>{t.exports=l()})),d=o((e=>{function t(e,t){var n=e.length;e.push(t);a:for(;0<n;){var r=n-1>>>1,a=e[r];if(0<i(a,t))e[r]=t,e[n]=a,n=r;else break a}}function n(e){return e.length===0?null:e[0]}function r(e){if(e.length===0)return null;var t=e[0],n=e.pop();if(n!==t){e[0]=n;a:for(var r=0,a=e.length,o=a>>>1;r<o;){var s=2*(r+1)-1,c=e[s],l=s+1,u=e[l];if(0>i(c,n))l<a&&0>i(u,c)?(e[r]=u,e[l]=n,r=l):(e[r]=c,e[s]=n,r=s);else if(l<a&&0>i(u,n))e[r]=u,e[l]=n,r=l;else break a}}return t}function i(e,t){var n=e.sortIndex-t.sortIndex;return n===0?e.id-t.id:n}if(e.unstable_now=void 0,typeof performance==`object`&&typeof performance.now==`function`){var a=performance;e.unstable_now=function(){return a.now()}}else{var o=Date,s=o.now();e.unstable_now=function(){return o.now()-s}}var c=[],l=[],u=1,d=null,f=3,p=!1,m=!1,h=!1,g=!1,_=typeof setTimeout==`function`?setTimeout:null,v=typeof clearTimeout==`function`?clearTimeout:null,y=typeof setImmediate<`u`?setImmediate:null;function b(e){for(var i=n(l);i!==null;){if(i.callback===null)r(l);else if(i.startTime<=e)r(l),i.sortIndex=i.expirationTime,t(c,i);else break;i=n(l)}}function ee(e){if(h=!1,b(e),!m){if(n(c)!==null)m=!0,te||(te=!0,ae());else{var t=n(l);t!==null&&oe(ee,t.startTime-e)}}}var te=!1,ne=-1,re=5,x=-1;function ie(){return g?!0:!(e.unstable_now()-x<re)}function S(){if(g=!1,te){var t=e.unstable_now();x=t;var i=!0;try{a:{m=!1,h&&(h=!1,v(ne),ne=-1),p=!0;var a=f;try{b:{for(b(t),d=n(c);d!==null&&!(d.expirationTime>t&&ie());){var o=d.callback;if(typeof o==`function`){d.callback=null,f=d.priorityLevel;var s=o(d.expirationTime<=t);if(t=e.unstable_now(),typeof s==`function`){d.callback=s,b(t),i=!0;break b}d===n(c)&&r(c),b(t)}else r(c);d=n(c)}if(d!==null)i=!0;else{var u=n(l);u!==null&&oe(ee,u.startTime-t),i=!1}}break a}finally{d=null,f=a,p=!1}i=void 0}}finally{i?ae():te=!1}}}var ae;if(typeof y==`function`)ae=function(){y(S)};else if(typeof MessageChannel<`u`){var C=new MessageChannel,w=C.port2;C.port1.onmessage=S,ae=function(){w.postMessage(null)}}else ae=function(){_(S,0)};function oe(t,n){ne=_(function(){t(e.unstable_now())},n)}e.unstable_IdlePriority=5,e.unstable_ImmediatePriority=1,e.unstable_LowPriority=4,e.unstable_NormalPriority=3,e.unstable_Profiling=null,e.unstable_UserBlockingPriority=2,e.unstable_cancelCallback=function(e){e.callback=null},e.unstable_forceFrameRate=function(e){0>e||125<e?console.error(`forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported`):re=0<e?Math.floor(1e3/e):5},e.unstable_getCurrentPriorityLevel=function(){return f},e.unstable_next=function(e){switch(f){case 1:case 2:case 3:var t=3;break;default:t=f}var n=f;f=t;try{return e()}finally{f=n}},e.unstable_requestPaint=function(){g=!0},e.unstable_runWithPriority=function(e,t){switch(e){case 1:case 2:case 3:case 4:case 5:break;default:e=3}var n=f;f=e;try{return t()}finally{f=n}},e.unstable_scheduleCallback=function(r,i,a){var o=e.unstable_now();switch(typeof a==`object`&&a?(a=a.delay,a=typeof a==`number`&&0<a?o+a:o):a=o,r){case 1:var s=-1;break;case 2:s=250;break;case 5:s=1073741823;break;case 4:s=1e4;break;default:s=5e3}return s=a+s,r={id:u++,callback:i,priorityLevel:r,startTime:a,expirationTime:s,sortIndex:-1},a>o?(r.sortIndex=a,t(l,r),n(c)===null&&r===n(l)&&(h?(v(ne),ne=-1):h=!0,oe(ee,a-o))):(r.sortIndex=s,t(c,r),m||p||(m=!0,te||(te=!0,ae()))),r},e.unstable_shouldYield=ie,e.unstable_wrapCallback=function(e){var t=f;return function(){var n=f;f=t;try{return e.apply(this,arguments)}finally{f=n}}}})),f=o(((e,t)=>{t.exports=d()})),p=o((e=>{var t=u();function n(e){var t=`https://react.dev/errors/`+e;if(1<arguments.length){t+=`?args[]=`+encodeURIComponent(arguments[1]);for(var n=2;n<arguments.length;n++)t+=`&args[]=`+encodeURIComponent(arguments[n])}return`Minified React error #`+e+`; visit `+t+` for the full message or use the non-minified dev environment for full errors and additional helpful warnings.`}function r(){}var i={d:{f:r,r:function(){throw Error(n(522))},D:r,C:r,L:r,m:r,X:r,S:r,M:r},p:0,findDOMNode:null},a=Symbol.for(`react.portal`),o=Symbol.for(`react.recoverable`),s=Symbol.for(`react.optimistic_key`);function c(e,t,n){var r=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:a,key:r==null?null:r===s?s:``+r,children:e,containerInfo:t,implementation:n}}var l=t.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;function d(e,t){if(e===`font`)return``;if(typeof t==`string`)return t===`use-credentials`?t:``}e.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=i,e.browser=function(e){return{$$typeof:o,_reason:e}},e.createPortal=function(e,t){var r=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!t||t.nodeType!==1&&t.nodeType!==9&&t.nodeType!==11)throw Error(n(299));return c(e,t,null,r)},e.flushSync=function(e){var t=l.T,n=i.p;try{if(l.T=null,i.p=2,e)return e()}finally{l.T=t,i.p=n,i.d.f()}},e.preconnect=function(e,t){typeof e==`string`&&(t?(t=t.crossOrigin,t=typeof t==`string`?t===`use-credentials`?t:``:void 0):t=null,i.d.C(e,t))},e.prefetchDNS=function(e){typeof e==`string`&&i.d.D(e)},e.preinit=function(e,t){if(typeof e==`string`&&t&&typeof t.as==`string`){var n=t.as,r=d(n,t.crossOrigin),a=typeof t.integrity==`string`?t.integrity:void 0,o=typeof t.fetchPriority==`string`?t.fetchPriority:void 0;n===`style`?i.d.S(e,typeof t.precedence==`string`?t.precedence:void 0,{crossOrigin:r,integrity:a,fetchPriority:o}):n===`script`&&i.d.X(e,{crossOrigin:r,integrity:a,fetchPriority:o,nonce:typeof t.nonce==`string`?t.nonce:void 0})}},e.preinitModule=function(e,t){if(typeof e==`string`){if(typeof t==`object`&&t){if(t.as==null||t.as===`script`){var n=d(t.as,t.crossOrigin);i.d.M(e,{crossOrigin:n,integrity:typeof t.integrity==`string`?t.integrity:void 0,nonce:typeof t.nonce==`string`?t.nonce:void 0,fetchPriority:typeof t.fetchPriority==`string`?t.fetchPriority:void 0})}}else t??i.d.M(e)}},e.preload=function(e,t){if(typeof e==`string`&&typeof t==`object`&&t&&typeof t.as==`string`){var n=t.as,r=d(n,t.crossOrigin);i.d.L(e,n,{crossOrigin:r,integrity:typeof t.integrity==`string`?t.integrity:void 0,nonce:typeof t.nonce==`string`?t.nonce:void 0,type:typeof t.type==`string`?t.type:void 0,fetchPriority:typeof t.fetchPriority==`string`?t.fetchPriority:void 0,referrerPolicy:typeof t.referrerPolicy==`string`?t.referrerPolicy:void 0,imageSrcSet:typeof t.imageSrcSet==`string`?t.imageSrcSet:void 0,imageSizes:typeof t.imageSizes==`string`?t.imageSizes:void 0,media:typeof t.media==`string`?t.media:void 0})}},e.preloadModule=function(e,t){if(typeof e==`string`){if(t){var n=d(t.as,t.crossOrigin);i.d.m(e,{as:typeof t.as==`string`&&t.as!==`script`?t.as:void 0,crossOrigin:n,integrity:typeof t.integrity==`string`?t.integrity:void 0,nonce:typeof t.nonce==`string`?t.nonce:void 0,fetchPriority:typeof t.fetchPriority==`string`?t.fetchPriority:void 0})}else i.d.m(e)}},e.requestFormReset=function(e){i.d.r(e)},e.unstable_batchedUpdates=function(e,t){return e(t)},e.useFormState=function(e,t,n){return l.H.useFormState(e,t,n)},e.useFormStatus=function(){return l.H.useHostTransitionStatus()},e.version=`19.3.0`})),m=o(((e,t)=>{function n(){if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<`u`&&typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE==`function`)try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(n)}catch(e){console.error(e)}}n(),t.exports=p()})),h=o((e=>{var t=f(),n=u(),r=m();function i(e){var t=`https://react.dev/errors/`+e;if(1<arguments.length){t+=`?args[]=`+encodeURIComponent(arguments[1]);for(var n=2;n<arguments.length;n++)t+=`&args[]=`+encodeURIComponent(arguments[n])}return`Minified React error #`+e+`; visit `+t+` for the full message or use the non-minified dev environment for full errors and additional helpful warnings.`}function a(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11)}function o(e){for(var t=e,n=t;n&&!n.alternate;)t=n,t.flags&4098&&(e=t.return),n=t.return;for(;t.return;)t=t.return;return t.tag===3?e:null}function s(e){if(e.tag===13){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function c(e){if(e.tag===31){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function l(e){if(o(e)!==e)throw Error(i(188))}function d(e){var t=e.alternate;if(!t){if(t=o(e),t===null)throw Error(i(188));return t===e?e:null}for(var n=e,r=t;;){var a=n.return;if(a===null)break;var s=a.alternate;if(s===null){if(r=a.return,r!==null){n=r;continue}break}if(a.child===s.child){for(s=a.child;s;){if(s===n)return l(a),e;if(s===r)return l(a),t;s=s.sibling}throw Error(i(188))}if(n.return!==r.return)n=a,r=s;else{for(var c=!1,u=a.child;u;){if(u===n){c=!0,n=a,r=s;break}if(u===r){c=!0,r=a,n=s;break}u=u.sibling}if(!c){for(u=s.child;u;){if(u===n){c=!0,n=s,r=a;break}if(u===r){c=!0,r=s,n=a;break}u=u.sibling}if(!c)throw Error(i(189))}}if(n.alternate!==r)throw Error(i(190))}if(n.tag!==3)throw Error(i(188));return n.stateNode.current===n?e:t}function p(e){var t=e.tag;if(t===5||t===26||t===27||t===6)return e;for(e=e.child;e!==null;){if(t=p(e),t!==null)return t;e=e.sibling}return null}function h(e,t,n,r,i,a){for(;e!==null;){if((e.tag===5||e.tag===27||e.tag===6)&&n(e,r,i,a)||(e.tag!==22||e.memoizedState===null)&&(t||e.tag!==5&&e.tag!==27)&&h(e.child,t,n,r,i,a))return!0;e=e.sibling}return!1}function g(e){for(e=e.return;e!==null;){if(e.tag===3||e.tag===5||e.tag===27)return e;e=e.return}return null}function _(e){var t=!1;for(e=e.return;e!==null&&(e.tag===4&&(t=!0),e.tag!==3&&e.tag!==5&&e.tag!==27);)e=e.return;return t}function v(e){var t=[null,null],n=g(e);return n===null||y(t,e,n.child,{foundSelf:!1}),t}function y(e,t,n,r){for(;n!==null;){if(n===t)r.foundSelf=!0;else if(n.tag===5||n.tag===27||n.tag===6){if(r.foundSelf)return e[1]=n,!0;e[0]=n}else if((n.tag!==22||n.memoizedState===null)&&y(e,t,n.child,r))return!0;n=n.sibling}return!1}function b(e){switch(e.tag){case 5:case 27:case 6:return e.stateNode;case 3:return e.stateNode.containerInfo;default:throw Error(i(559))}}var ee=null,te=null;function ne(e,t,n){return e===n||e===t&&(ee=e,!0)}function re(e,t,n){return e===n?(te=e,!1):e===t&&(te!==null&&(ee=e),!0)}function x(e){if(e===null)return null;do e=e===null?null:e.return;while(e&&e.tag!==5&&e.tag!==27&&e.tag!==3);return e||null}function ie(e,t,n){for(var r=0,i=e;i;i=n(i))r++;i=0;for(var a=t;a;a=n(a))i++;for(;0<r-i;)e=n(e),r--;for(;0<i-r;)t=n(t),i--;for(;r--;){if(e===t||t!==null&&e===t.alternate)return e;e=n(e),t=n(t)}return null}var S=Object.assign,ae=Symbol.for(`react.element`),C=Symbol.for(`react.transitional.element`),w=Symbol.for(`react.portal`),oe=Symbol.for(`react.fragment`),se=Symbol.for(`react.strict_mode`),ce=Symbol.for(`react.profiler`),le=Symbol.for(`react.consumer`),T=Symbol.for(`react.context`),ue=Symbol.for(`react.forward_ref`),de=Symbol.for(`react.suspense`),fe=Symbol.for(`react.suspense_list`),pe=Symbol.for(`react.memo`),me=Symbol.for(`react.lazy`),he=Symbol.for(`react.activity`),ge=Symbol.for(`react.legacy_hidden`),_e=Symbol.for(`react.memo_cache_sentinel`),ve=Symbol.for(`react.view_transition`),ye=Symbol.for(`react.recoverable`),be=Symbol.iterator;function xe(e){return typeof e!=`object`||!e?null:(e=be&&e[be]||e[`@@iterator`],typeof e==`function`?e:null)}var Se=Symbol.for(`react.client.reference`);function Ce(e){if(e==null)return null;if(typeof e==`function`)return e.$$typeof===Se?null:e.displayName||e.name||null;if(typeof e==`string`)return e;switch(e){case oe:return`Fragment`;case ce:return`Profiler`;case se:return`StrictMode`;case de:return`Suspense`;case fe:return`SuspenseList`;case he:return`Activity`;case ve:return`ViewTransition`}if(typeof e==`object`)switch(e.$$typeof){case w:return`Portal`;case T:return e.displayName||`Context`;case le:return(e._context.displayName||`Context`)+`.Consumer`;case ue:var t=e.render;return e=e.displayName,e||=(e=t.displayName||t.name||``,e===``?`ForwardRef`:`ForwardRef(`+e+`)`),e;case pe:return t=e.displayName||null,t===null?Ce(e.type)||`Memo`:t;case me:t=e._payload,e=e._init;try{return Ce(e(t))}catch{}}return null}var we=Array.isArray,E=n.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,D=r.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,Te={pending:!1,data:null,method:null,action:null},Ee=[],De=-1;function Oe(e){return{current:e}}function ke(e){0>De||(e.current=Ee[De],Ee[De]=null,De--)}function O(e,t){De++,Ee[De]=e.current,e.current=t}var Ae=Oe(null),je=Oe(null),Me=Oe(null),Ne=Oe(null);function Pe(e,t){switch(O(Me,t),O(je,e),O(Ae,null),t.nodeType){case 9:case 11:e=(e=t.documentElement)&&(e=e.namespaceURI)?up(e):0;break;default:if(e=t.tagName,t=t.namespaceURI)t=up(t),e=dp(t,e);else switch(e){case`svg`:e=1;break;case`math`:e=2;break;default:e=0}}ke(Ae),O(Ae,e)}function Fe(){ke(Ae),ke(je),ke(Me)}function Ie(e){var t=e.memoizedState;t!==null&&(sh._currentValue=t.memoizedState,O(Ne,e)),t=Ae.current;var n=dp(t,e.type);t!==n&&(O(je,e),O(Ae,n))}function Le(e){je.current===e&&(ke(Ae),ke(je)),Ne.current===e&&(ke(Ne),sh._currentValue=Te)}var Re,ze;function Be(e){if(Re===void 0)try{throw Error()}catch(e){var t=e.stack.trim().match(/\n( *(at )?)/);Re=t&&t[1]||``,ze=-1<e.stack.indexOf(`
    at`)?` (<anonymous>)`:-1<e.stack.indexOf(`@`)?`@unknown:0:0`:``}return`
`+Re+e+ze}var Ve=!1;function He(e,t){if(!e||Ve)return``;Ve=!0;var n=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{var r={DetermineComponentFrameRoot:function(){try{if(t){var n=function(){throw Error()};if(Object.defineProperty(n.prototype,"props",{set:function(){throw Error()}}),typeof Reflect==`object`&&Reflect.construct){try{Reflect.construct(n,[])}catch(e){var r=e}Reflect.construct(e,[],n)}else{try{n.call()}catch(e){r=e}n=!1;try{var i=Object.getOwnPropertyDescriptor(e.prototype,`props`);Object.defineProperty(e.prototype,"props",{configurable:!0,set:function(){throw Error()}}),n=!0,new e}finally{n&&(i===void 0?delete e.prototype.props:Object.defineProperty(e.prototype,"props",i))}}}else{try{throw Error()}catch(e){r=e}(n=e())&&typeof n.catch==`function`&&n.catch(function(){})}}catch(e){if(e&&r&&typeof e.stack==`string`)return[e.stack,r.stack]}return[null,null]}};r.DetermineComponentFrameRoot.displayName=`DetermineComponentFrameRoot`;var i=Object.getOwnPropertyDescriptor(r.DetermineComponentFrameRoot,`name`);i&&i.configurable&&Object.defineProperty(r.DetermineComponentFrameRoot,"name",{value:`DetermineComponentFrameRoot`});var a=r.DetermineComponentFrameRoot(),o=a[0],s=a[1];if(o&&s){var c=o.split(`
`),l=s.split(`
`);for(i=r=0;r<c.length&&!c[r].includes(`DetermineComponentFrameRoot`);)r++;for(;i<l.length&&!l[i].includes(`DetermineComponentFrameRoot`);)i++;if(r===c.length||i===l.length)for(r=c.length-1,i=l.length-1;1<=r&&0<=i&&c[r]!==l[i];)i--;for(;1<=r&&0<=i;r--,i--)if(c[r]!==l[i]){if(r!==1||i!==1)do if(r--,i--,0>i||c[r]!==l[i]){var u=`
`+c[r].replace(` at new `,` at `);return e.displayName&&u.includes(`<anonymous>`)&&(u=u.replace(`<anonymous>`,e.displayName)),u}while(1<=r&&0<=i);break}}}finally{Ve=!1,Error.prepareStackTrace=n}return(n=e?e.displayName||e.name:``)?Be(n):``}function Ue(e,t){switch(e.tag){case 26:case 27:case 5:return Be(e.type);case 16:return Be(`Lazy`);case 13:return e.child!==t&&t!==null?Be(`Suspense Fallback`):Be(`Suspense`);case 19:return Be(`SuspenseList`);case 0:case 15:return He(e.type,!1);case 11:return He(e.type.render,!1);case 1:return He(e.type,!0);case 31:return Be(`Activity`);case 30:return Be(`ViewTransition`);default:return``}}function We(e){try{var t=``,n=null;do t+=Ue(e,n),n=e,e=e.return;while(e);return t}catch(e){return`
Error generating stack: `+e.message+`
`+e.stack}}var Ge=Object.prototype.hasOwnProperty,Ke=t.unstable_scheduleCallback,qe=t.unstable_cancelCallback,Je=t.unstable_shouldYield,Ye=t.unstable_requestPaint,Xe=t.unstable_now,Ze=t.unstable_getCurrentPriorityLevel,Qe=t.unstable_ImmediatePriority,$e=t.unstable_UserBlockingPriority,et=t.unstable_NormalPriority,tt=t.unstable_LowPriority,nt=t.unstable_IdlePriority,rt=t.log,it=t.unstable_setDisableYieldValue,at=null,ot=null;function st(e){if(typeof rt==`function`&&it(e),ot&&typeof ot.setStrictMode==`function`)try{ot.setStrictMode(at,e)}catch{}}var ct=Math.clz32?Math.clz32:dt,lt=Math.log,ut=Math.LN2;function dt(e){return e>>>=0,e===0?32:31-(lt(e)/ut|0)|0}var ft=256,pt=262144,mt=4194304;function ht(e){var t=e&42;if(t!==0)return t;switch(e&-e){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:return 64;case 128:return 128;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:return e&-e;case 262144:case 524288:case 1048576:case 2097152:return e&3932160;case 4194304:case 8388608:case 16777216:case 33554432:return e&62914560;case 67108864:return 67108864;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 0;default:return e}}function gt(e,t,n){var r=e.pendingLanes;if(r===0)return 0;var i=0,a=e.suspendedLanes,o=e.pingedLanes;e=e.warmLanes;var s=r&134217727;return s===0?(s=r&~a,s===0?o===0?n||(n=r&~e,n!==0&&(i=ht(n))):i=ht(o):i=ht(s)):(r=s&~a,r===0?(o&=s,o===0?n||(n=s&~e,n!==0&&(i=ht(n))):i=ht(o)):i=ht(r)),i===0?0:t!==0&&t!==i&&(t&a)===0&&(a=i&-i,n=t&-t,a>=n||a===32&&n&4194048)?t:i}function _t(e,t){return(e.pendingLanes&~(e.suspendedLanes&~e.pingedLanes)&t)===0}function vt(e,t){t&8&&(t|=t&32);var n=e.entangledLanes;if(n!==0)for(e=e.entanglements,n&=t;0<n;){var r=31-ct(n),i=1<<r;t|=e[r],n&=~i}return t}function yt(e,t){switch(e){case 1:case 2:case 4:case 8:case 64:return t+250;case 16:case 32:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return t+5e3;case 4194304:case 8388608:case 16777216:case 33554432:return-1;case 67108864:case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function bt(){var e=mt;return mt<<=1,!(mt&62914560)&&(mt=4194304),e}function xt(e){for(var t=[],n=0;31>n;n++)t.push(e);return t}function St(e,t){e.pendingLanes|=t,t!==268435456&&(e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0)}function Ct(e,t,n,r,i,a){var o=e.pendingLanes;e.pendingLanes=n,e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0,e.expiredLanes&=n,e.entangledLanes&=n,e.errorRecoveryDisabledLanes&=n,e.shellSuspendCounter=0;var s=e.entanglements,c=e.expirationTimes,l=e.hiddenUpdates;for(n=o&~n;0<n;){var u=31-ct(n),d=1<<u;s[u]=0,c[u]=-1;var f=l[u];if(f!==null)for(l[u]=null,u=0;u<f.length;u++){var p=f[u];p!==null&&(p.lane&=-536870913)}n&=~d}r!==0&&wt(e,r,0),a!==0&&i===0&&e.tag!==0&&(e.suspendedLanes|=a&~(o&~t))}function wt(e,t,n){e.pendingLanes|=t,e.suspendedLanes&=~t;var r=31-ct(t);e.entangledLanes|=t,e.entanglements[r]=e.entanglements[r]|1073741824|n&261930}function Tt(e,t){var n=e.entangledLanes|=t;for(e=e.entanglements;n;){var r=31-ct(n),i=1<<r;i&t|e[r]&t&&(e[r]|=t),n&=~i}}function Et(e,t){var n=t&-t;return n=n&42?1:Dt(n),(n&(e.suspendedLanes|t))===0?n:0}function Dt(e){switch(e){case 2:e=1;break;case 8:e=4;break;case 32:e=16;break;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:e=128;break;case 268435456:e=134217728;break;default:e=0}return e}function Ot(e){return e&=-e,2<e?8<e?e&134217727?32:268435456:8:2}function kt(){var e=D.p;return e===0?(e=window.event,e===void 0?32:Ch(e.type)):e}function At(e,t){var n=D.p;try{return D.p=e,t()}finally{D.p=n}}var jt=Math.random().toString(36).slice(2),Mt=`__reactFiber$`+jt,Nt=`__reactProps$`+jt,Pt=`__reactContainer$`+jt,Ft=`__reactEvents$`+jt,It=`__reactListeners$`+jt,Lt=`__reactHandles$`+jt,Rt=`__reactResources$`+jt,zt=`__reactMarker$`+jt,Bt=`__reactLoad$`+jt;function Vt(e){delete e[Mt],delete e[Nt],delete e[It],delete e[Lt]}function Ht(e){var t;if(t=e[Mt])return t;for(var n=e.parentNode;n;){if(t=n[Pt]||n[Mt]){if(n=t.alternate,t.child!==null||n!==null&&n.child!==null)for(e=fm(e);e!==null;){if(n=e[Mt])return n;e=fm(e)}return t}e=n,n=e.parentNode}return null}function Ut(e){if(e=e[Mt]||e[Pt]){var t=e.tag;if(t===5||t===6||t===13||t===31||t===26||t===27||t===3)return e}return null}function Wt(e){var t=e.tag;if(t===5||t===26||t===27||t===6)return e.stateNode;throw Error(i(33))}function Gt(e){var t=e[Rt];return t||=e[Rt]={hoistableStyles:new Map,hoistableScripts:new Map},t}function k(e){e[zt]=!0}function Kt(e){e[Bt]=void 0}var qt=new Set,Jt={};function Yt(e,t){Xt(e,t),Xt(e+`Capture`,t)}function Xt(e,t){for(Jt[e]=t,e=0;e<t.length;e++)qt.add(t[e])}var Zt=RegExp(`^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$`),Qt={},$t={};function en(e){return Ge.call($t,e)?!0:Ge.call(Qt,e)?!1:Zt.test(e)?$t[e]=!0:(Qt[e]=!0,!1)}var A=!1;function tn(){var e=A;return A=!1,e}function nn(e,t,n){if(en(t)){if(n===null)e.removeAttribute(t);else{switch(typeof n){case`undefined`:case`function`:case`symbol`:e.removeAttribute(t);return;case`boolean`:var r=t.toLowerCase().slice(0,5);if(r!==`data-`&&r!==`aria-`){e.removeAttribute(t);return}}e.setAttribute(t,n)}}}function rn(e,t,n){if(n===null)e.removeAttribute(t);else{switch(typeof n){case`undefined`:case`function`:case`symbol`:case`boolean`:e.removeAttribute(t);return}e.setAttribute(t,n)}}function an(e,t,n,r){if(r===null)e.removeAttribute(n);else{switch(typeof r){case`undefined`:case`function`:case`symbol`:case`boolean`:e.removeAttribute(n);return}e.setAttributeNS(t,n,r)}}function on(e){switch(typeof e){case`bigint`:case`boolean`:case`number`:case`string`:case`undefined`:return e;case`object`:return e;default:return``}}function sn(e){var t=e.type;return(e=e.nodeName)&&e.toLowerCase()===`input`&&(t===`checkbox`||t===`radio`)}function cn(e,t,n){var r=Object.getOwnPropertyDescriptor(e.constructor.prototype,t);if(!e.hasOwnProperty(t)&&r!==void 0&&typeof r.get==`function`&&typeof r.set==`function`){var i=r.get,a=r.set;return Object.defineProperty(e,t,{configurable:!0,get:function(){return i.call(this)},set:function(e){n=``+e,a.call(this,e)}}),Object.defineProperty(e,t,{enumerable:r.enumerable}),{getValue:function(){return n},setValue:function(e){n=``+e},stopTracking:function(){e._valueTracker=null,delete e[t]}}}}function ln(e){if(!e._valueTracker){var t=sn(e)?`checked`:`value`;e._valueTracker=cn(e,t,``+e[t])}}function un(e){if(!e)return!1;var t=e._valueTracker;if(!t)return!0;var n=t.getValue(),r=``;return e&&(r=sn(e)?e.checked?`true`:`false`:e.value),e=r,e!==n&&(t.setValue(e),!0)}var dn=/[\n"\\]/g;function fn(e){return e.replace(dn,function(e){return`\\`+e.charCodeAt(0).toString(16)+` `})}function pn(e,t,n,r,i,a,o,s){e.name=``,o!=null&&typeof o!=`function`&&typeof o!=`symbol`&&typeof o!=`boolean`?e.type=o:e.removeAttribute(`type`),t==null?o!==`submit`&&o!==`reset`||e.removeAttribute(`value`):o===`number`?(t===0&&e.value===``||e.value!=t)&&(e.value=``+on(t)):e.value!==``+on(t)&&(e.value=``+on(t)),t==null?n==null?r!=null&&e.removeAttribute(`value`):hn(e,on(n)):o===`number`&&e.value==t?hn(e,on(e.value)):hn(e,on(t)),i==null&&a!=null&&(e.defaultChecked=!!a),i!=null&&(e.checked=i&&typeof i!=`function`&&typeof i!=`symbol`),s!=null&&typeof s!=`function`&&typeof s!=`symbol`&&typeof s!=`boolean`?e.name=``+on(s):e.removeAttribute(`name`)}function mn(e,t,n,r,i,a,o,s){if(a!=null&&typeof a!=`function`&&typeof a!=`symbol`&&typeof a!=`boolean`&&(e.type=a),t!=null||n!=null){if(!(a!==`submit`&&a!==`reset`||t!=null)){ln(e);return}n=n==null?``:``+on(n),t=t==null?n:``+on(t),s||t===e.value||(e.value=t),e.defaultValue=t}r??=i,r=typeof r!=`function`&&typeof r!=`symbol`&&!!r,e.checked=s?e.checked:!!r,e.defaultChecked=!!r,o!=null&&typeof o!=`function`&&typeof o!=`symbol`&&typeof o!=`boolean`&&(e.name=o),ln(e)}function hn(e,t){e.defaultValue!==``+t&&(e.defaultValue=``+t)}function gn(e,t,n,r){if(e=e.options,t){t={};for(var i=0;i<n.length;i++)t[`$`+n[i]]=!0;for(n=0;n<e.length;n++)i=t.hasOwnProperty(`$`+e[n].value),e[n].selected!==i&&(e[n].selected=i),i&&r&&(e[n].defaultSelected=!0)}else{for(n=``+on(n),t=null,i=0;i<e.length;i++){if(e[i].value===n){e[i].selected=!0,r&&(e[i].defaultSelected=!0);return}t!==null||e[i].disabled||(t=e[i])}t!==null&&(t.selected=!0)}}function _n(e,t,n){if(t!=null&&(t=``+on(t),t!==e.value&&(e.value=t),n==null)){e.defaultValue!==t&&(e.defaultValue=t);return}e.defaultValue=n==null?``:``+on(n)}function vn(e,t,n,r){if(t==null){if(r!=null){if(n!=null)throw Error(i(92));if(we(r)){if(1<r.length)throw Error(i(93));r=r[0]}n=r}n??=``,t=n}n=on(t),e.defaultValue=n,r=e.textContent,r===n&&r!==``&&r!==null&&(e.value=r),ln(e)}function yn(e,t){if(t){var n=e.firstChild;if(n&&n===e.lastChild&&n.nodeType===3){n.nodeValue=t;return}}e.textContent=t}var bn=new Set(`animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp`.split(` `));function xn(e,t,n){var r=t.indexOf(`--`)===0;n==null||typeof n==`boolean`||n===``?r?e.setProperty(t,``):t===`float`?e.cssFloat=``:e[t]=``:r?e.setProperty(t,n):typeof n!=`number`||n===0||bn.has(t)?t===`float`?e.cssFloat=n:e[t]=(``+n).trim():e[t]=n+`px`}function Sn(e,t,n){if(t!=null&&typeof t!=`object`)throw Error(i(62));if(e=e.style,n!=null){for(var r in n)!n.hasOwnProperty(r)||t!=null&&t.hasOwnProperty(r)||(r.indexOf(`--`)===0?e.setProperty(r,``):r===`float`?e.cssFloat=``:e[r]=``,A=!0);for(var a in t)r=t[a],t.hasOwnProperty(a)&&n[a]!==r&&(xn(e,a,r),A=!0)}else for(var o in t)t.hasOwnProperty(o)&&xn(e,o,t[o])}function Cn(e){if(e.indexOf(`-`)===-1)return!1;switch(e){case`annotation-xml`:case`color-profile`:case`font-face`:case`font-face-src`:case`font-face-uri`:case`font-face-format`:case`font-face-name`:case`missing-glyph`:return!1;default:return!0}}var wn=new Map([[`acceptCharset`,`accept-charset`],[`htmlFor`,`for`],[`httpEquiv`,`http-equiv`],[`crossOrigin`,`crossorigin`],[`accentHeight`,`accent-height`],[`alignmentBaseline`,`alignment-baseline`],[`arabicForm`,`arabic-form`],[`baselineShift`,`baseline-shift`],[`capHeight`,`cap-height`],[`clipPath`,`clip-path`],[`clipRule`,`clip-rule`],[`colorInterpolation`,`color-interpolation`],[`colorInterpolationFilters`,`color-interpolation-filters`],[`colorProfile`,`color-profile`],[`colorRendering`,`color-rendering`],[`dominantBaseline`,`dominant-baseline`],[`enableBackground`,`enable-background`],[`fillOpacity`,`fill-opacity`],[`fillRule`,`fill-rule`],[`floodColor`,`flood-color`],[`floodOpacity`,`flood-opacity`],[`fontFamily`,`font-family`],[`fontSize`,`font-size`],[`fontSizeAdjust`,`font-size-adjust`],[`fontStretch`,`font-stretch`],[`fontStyle`,`font-style`],[`fontVariant`,`font-variant`],[`fontWeight`,`font-weight`],[`glyphName`,`glyph-name`],[`glyphOrientationHorizontal`,`glyph-orientation-horizontal`],[`glyphOrientationVertical`,`glyph-orientation-vertical`],[`horizAdvX`,`horiz-adv-x`],[`horizOriginX`,`horiz-origin-x`],[`imageRendering`,`image-rendering`],[`letterSpacing`,`letter-spacing`],[`lightingColor`,`lighting-color`],[`markerEnd`,`marker-end`],[`markerMid`,`marker-mid`],[`markerStart`,`marker-start`],[`maskType`,`mask-type`],[`overlinePosition`,`overline-position`],[`overlineThickness`,`overline-thickness`],[`paintOrder`,`paint-order`],[`panose-1`,`panose-1`],[`pointerEvents`,`pointer-events`],[`renderingIntent`,`rendering-intent`],[`shapeRendering`,`shape-rendering`],[`stopColor`,`stop-color`],[`stopOpacity`,`stop-opacity`],[`strikethroughPosition`,`strikethrough-position`],[`strikethroughThickness`,`strikethrough-thickness`],[`strokeDasharray`,`stroke-dasharray`],[`strokeDashoffset`,`stroke-dashoffset`],[`strokeLinecap`,`stroke-linecap`],[`strokeLinejoin`,`stroke-linejoin`],[`strokeMiterlimit`,`stroke-miterlimit`],[`strokeOpacity`,`stroke-opacity`],[`strokeWidth`,`stroke-width`],[`textAnchor`,`text-anchor`],[`textDecoration`,`text-decoration`],[`textRendering`,`text-rendering`],[`transformOrigin`,`transform-origin`],[`underlinePosition`,`underline-position`],[`underlineThickness`,`underline-thickness`],[`unicodeBidi`,`unicode-bidi`],[`unicodeRange`,`unicode-range`],[`unitsPerEm`,`units-per-em`],[`vAlphabetic`,`v-alphabetic`],[`vHanging`,`v-hanging`],[`vIdeographic`,`v-ideographic`],[`vMathematical`,`v-mathematical`],[`vectorEffect`,`vector-effect`],[`vertAdvY`,`vert-adv-y`],[`vertOriginX`,`vert-origin-x`],[`vertOriginY`,`vert-origin-y`],[`wordSpacing`,`word-spacing`],[`writingMode`,`writing-mode`],[`xmlnsXlink`,`xmlns:xlink`],[`xHeight`,`x-height`]]),Tn=/^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;function En(e){return Tn.test(``+e)?`javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')`:e}function Dn(){}var On=null;function kn(e){return e=e.target||e.srcElement||window,e.correspondingUseElement&&(e=e.correspondingUseElement),e.nodeType===3?e.parentNode:e}var An=null,jn=null;function j(e){var t=Ut(e);if(t&&(e=t.stateNode)){var n=e[Nt]||null;a:switch(e=t.stateNode,t.type){case`input`:if(pn(e,n.value,n.defaultValue,n.defaultValue,n.checked,n.defaultChecked,n.type,n.name),t=n.name,n.type===`radio`&&t!=null){for(n=e;n.parentNode;)n=n.parentNode;for(n=n.querySelectorAll(`input[name="`+fn(``+t)+`"][type="radio"]`),t=0;t<n.length;t++){var r=n[t];if(r!==e&&r.form===e.form){var a=r[Nt]||null;if(!a)throw Error(i(90));pn(r,a.value,a.defaultValue,a.defaultValue,a.checked,a.defaultChecked,a.type,a.name)}}for(t=0;t<n.length;t++)r=n[t],r.form===e.form&&un(r)}break a;case`textarea`:_n(e,n.value,n.defaultValue);break a;case`select`:t=n.value,t!=null&&gn(e,!!n.multiple,t,!1)}}}var Mn=!1;function Nn(e,t,n){if(Mn)return e(t,n);Mn=!0;try{return e(t)}finally{if(Mn=!1,(An!==null||jn!==null)&&(zd(),An&&(t=An,e=jn,jn=An=null,j(t),e)))for(t=0;t<e.length;t++)j(e[t])}}function Pn(e,t){var n=e.stateNode;if(n===null)return null;var r=n[Nt]||null;if(r===null)return null;n=r[t];a:switch(t){case`onClick`:case`onClickCapture`:case`onDoubleClick`:case`onDoubleClickCapture`:case`onMouseDown`:case`onMouseDownCapture`:case`onMouseMove`:case`onMouseMoveCapture`:case`onMouseUp`:case`onMouseUpCapture`:case`onMouseEnter`:(r=!r.disabled)||(e=e.type,r=e!==`button`&&e!==`input`&&e!==`select`&&e!==`textarea`),e=!r;break a;default:e=!1}if(e)return null;if(n&&typeof n!=`function`)throw Error(i(231,t,typeof n));return n}var Fn=typeof window<`u`&&window.document!==void 0&&window.document.createElement!==void 0,In=!1;if(Fn)try{var Ln={};Object.defineProperty(Ln,"passive",{get:function(){In=!0}}),window.addEventListener(`test`,Ln,Ln),window.removeEventListener(`test`,Ln,Ln)}catch{In=!1}var Rn=null,zn=null,Bn=null;function Vn(){if(Bn)return Bn;var e,t=zn,n=t.length,r,i=`value`in Rn?Rn.value:Rn.textContent,a=i.length;for(e=0;e<n&&t[e]===i[e];e++);var o=n-e;for(r=1;r<=o&&t[n-r]===i[a-r];r++);return Bn=i.slice(e,1<r?1-r:void 0)}function Hn(e){var t=e.keyCode;return`charCode`in e?(e=e.charCode,e===0&&t===13&&(e=13)):e=t,e===10&&(e=13),32<=e||e===13?e:0}function Un(){return!0}function Wn(){return!1}function Gn(e){function t(t,n,r,i,a){for(var o in this._reactName=t,this._targetInst=r,this.type=n,this.nativeEvent=i,this.target=a,this.currentTarget=null,e)e.hasOwnProperty(o)&&(t=e[o],this[o]=t?t(i):i[o]);return this.isDefaultPrevented=(i.defaultPrevented==null?!1===i.returnValue:i.defaultPrevented)?Un:Wn,this.isPropagationStopped=Wn,this}return S(t.prototype,{preventDefault:function(){this.defaultPrevented=!0;var e=this.nativeEvent;e&&(e.preventDefault?e.preventDefault():typeof e.returnValue!=`unknown`&&(e.returnValue=!1),this.isDefaultPrevented=Un)},stopPropagation:function(){var e=this.nativeEvent;e&&(e.stopPropagation?e.stopPropagation():typeof e.cancelBubble!=`unknown`&&(e.cancelBubble=!0),this.isPropagationStopped=Un)},persist:function(){},isPersistent:Un}),t}var Kn={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(e){return e.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},qn=Gn(Kn),Jn=S({},Kn,{view:0,detail:0}),Yn=Gn(Jn),Xn,Zn,Qn,$n=S({},Jn,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:lr,button:0,buttons:0,relatedTarget:function(e){return e.relatedTarget===void 0?e.fromElement===e.srcElement?e.toElement:e.fromElement:e.relatedTarget},movementX:function(e){return`movementX`in e?e.movementX:(e!==Qn&&(Qn&&e.type===`mousemove`?(Xn=e.screenX-Qn.screenX,Zn=e.screenY-Qn.screenY):Zn=Xn=0,Qn=e),Xn)},movementY:function(e){return`movementY`in e?e.movementY:Zn}}),er=Gn($n),tr=Gn(S({},$n,{dataTransfer:0})),nr=Gn(S({},Jn,{relatedTarget:0})),rr=Gn(S({},Kn,{animationName:0,elapsedTime:0,pseudoElement:0})),ir=Gn(S({},Kn,{clipboardData:function(e){return`clipboardData`in e?e.clipboardData:window.clipboardData}})),ar=Gn(S({},Kn,{data:0})),or={Esc:`Escape`,Spacebar:` `,Left:`ArrowLeft`,Up:`ArrowUp`,Right:`ArrowRight`,Down:`ArrowDown`,Del:`Delete`,Win:`OS`,Menu:`ContextMenu`,Apps:`ContextMenu`,Scroll:`ScrollLock`,MozPrintableKey:`Unidentified`},sr={8:`Backspace`,9:`Tab`,12:`Clear`,13:`Enter`,16:`Shift`,17:`Control`,18:`Alt`,19:`Pause`,20:`CapsLock`,27:`Escape`,32:` `,33:`PageUp`,34:`PageDown`,35:`End`,36:`Home`,37:`ArrowLeft`,38:`ArrowUp`,39:`ArrowRight`,40:`ArrowDown`,45:`Insert`,46:`Delete`,112:`F1`,113:`F2`,114:`F3`,115:`F4`,116:`F5`,117:`F6`,118:`F7`,119:`F8`,120:`F9`,121:`F10`,122:`F11`,123:`F12`,144:`NumLock`,145:`ScrollLock`,224:`Meta`},M={Alt:`altKey`,Control:`ctrlKey`,Meta:`metaKey`,Shift:`shiftKey`};function cr(e){var t=this.nativeEvent;return t.getModifierState?t.getModifierState(e):(e=M[e])?!!t[e]:!1}function lr(){return cr}var ur=Gn(S({},Jn,{key:function(e){if(e.key){var t=or[e.key]||e.key;if(t!==`Unidentified`)return t}return e.type===`keypress`?(e=Hn(e),e===13?`Enter`:String.fromCharCode(e)):e.type===`keydown`||e.type===`keyup`?sr[e.keyCode]||`Unidentified`:``},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:lr,charCode:function(e){return e.type===`keypress`?Hn(e):0},keyCode:function(e){return e.type===`keydown`||e.type===`keyup`?e.keyCode:0},which:function(e){return e.type===`keypress`?Hn(e):e.type===`keydown`||e.type===`keyup`?e.keyCode:0}})),dr=Gn(S({},$n,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0})),fr=Gn(S({},Kn,{submitter:0})),pr=Gn(S({},Jn,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:lr})),mr=Gn(S({},Kn,{propertyName:0,elapsedTime:0,pseudoElement:0})),hr=Gn(S({},$n,{deltaX:function(e){return`deltaX`in e?e.deltaX:`wheelDeltaX`in e?-e.wheelDeltaX:0},deltaY:function(e){return`deltaY`in e?e.deltaY:`wheelDeltaY`in e?-e.wheelDeltaY:`wheelDelta`in e?-e.wheelDelta:0},deltaZ:0,deltaMode:0})),gr=Gn(S({},Kn,{newState:0,oldState:0,source:0})),_r=[9,13,27,32],vr=Fn&&`CompositionEvent`in window,yr=null;Fn&&`documentMode`in document&&(yr=document.documentMode);var br=Fn&&`TextEvent`in window&&!yr,xr=Fn&&(!vr||yr&&8<yr&&11>=yr),Sr=` `,Cr=!1;function wr(e,t){switch(e){case`keyup`:return _r.indexOf(t.keyCode)!==-1;case`keydown`:return t.keyCode!==229;case`keypress`:case`mousedown`:case`focusout`:return!0;default:return!1}}function Tr(e){return e=e.detail,typeof e==`object`&&`data`in e?e.data:null}var Er=!1;function Dr(e,t){switch(e){case`compositionend`:return Tr(t);case`keypress`:return t.which===32?(Cr=!0,Sr):null;case`textInput`:return e=t.data,e===Sr&&Cr?null:e;default:return null}}function Or(e,t){if(Er)return e===`compositionend`||!vr&&wr(e,t)?(e=Vn(),Bn=zn=Rn=null,Er=!1,e):null;switch(e){case`paste`:return null;case`keypress`:if(!(t.ctrlKey||t.altKey||t.metaKey)||t.ctrlKey&&t.altKey){if(t.char&&1<t.char.length)return t.char;if(t.which)return String.fromCharCode(t.which)}return null;case`compositionend`:return xr&&t.locale!==`ko`?null:t.data;default:return null}}var kr={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function Ar(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t===`input`?!!kr[e.type]:t===`textarea`}function jr(e,t,n,r){An?jn?jn.push(r):jn=[r]:An=r,t=Jf(t,`onChange`),0<t.length&&(n=new qn(`onChange`,`change`,null,n,r),e.push({event:n,listeners:t}))}var Mr=null,Nr=null;function Pr(e){Vf(e,0)}function Fr(e){if(un(Wt(e)))return e}function Ir(e,t){if(e===`change`)return t}var Lr=!1;if(Fn){var Rr;if(Fn){var zr=`oninput`in document;if(!zr){var Br=document.createElement(`div`);Br.setAttribute(`oninput`,`return;`),zr=typeof Br.oninput==`function`}Rr=zr}else Rr=!1;Lr=Rr&&(!document.documentMode||9<document.documentMode)}function Vr(){Mr&&(Mr.detachEvent(`onpropertychange`,Hr),Nr=Mr=null)}function Hr(e){if(e.propertyName===`value`&&Fr(Nr)){var t=[];jr(t,Nr,e,kn(e)),Nn(Pr,t)}}function Ur(e,t,n){e===`focusin`?(Vr(),Mr=t,Nr=n,Mr.attachEvent(`onpropertychange`,Hr)):e===`focusout`&&Vr()}function Wr(e){if(e===`selectionchange`||e===`keyup`||e===`keydown`)return Fr(Nr)}function Gr(e,t){if(e===`click`)return Fr(t)}function Kr(e,t){if(e===`input`||e===`change`)return Fr(t)}function qr(e,t){return e===t&&(e!==0||1/e==1/t)||e!==e&&t!==t}var Jr=typeof Object.is==`function`?Object.is:qr;function Yr(e,t){if(Jr(e,t))return!0;if(typeof e!=`object`||!e||typeof t!=`object`||!t)return!1;var n=Object.keys(e),r=Object.keys(t);if(n.length!==r.length)return!1;for(r=0;r<n.length;r++){var i=n[r];if(!Ge.call(t,i)||!Jr(e[i],t[i]))return!1}return!0}function Xr(e){if(e||=typeof document<`u`?document:void 0,e===void 0)return null;try{return e.activeElement||e.body}catch{return e.body}}function Zr(e){for(;e&&e.firstChild;)e=e.firstChild;return e}function Qr(e,t){var n=Zr(e);e=0;for(var r;n;){if(n.nodeType===3){if(r=e+n.textContent.length,e<=t&&r>=t)return{node:n,offset:t-e};e=r}a:{for(;n;){if(n.nextSibling){n=n.nextSibling;break a}n=n.parentNode}n=void 0}n=Zr(n)}}function $r(e,t){return e&&t?e===t?!0:e&&e.nodeType===3?!1:t&&t.nodeType===3?$r(e,t.parentNode):`contains`in e?e.contains(t):e.compareDocumentPosition?!!(e.compareDocumentPosition(t)&16):!1:!1}function ei(e){e=e!=null&&e.ownerDocument!=null&&e.ownerDocument.defaultView!=null?e.ownerDocument.defaultView:window;for(var t=Xr(e.document);t instanceof e.HTMLIFrameElement;){try{var n=typeof t.contentWindow.location.href==`string`}catch{n=!1}if(n)e=t.contentWindow;else break;t=Xr(e.document)}return t}function ti(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t&&(t===`input`&&(e.type===`text`||e.type===`search`||e.type===`tel`||e.type===`url`||e.type===`password`)||t===`textarea`||e.contentEditable===`true`)}var ni=Fn&&`documentMode`in document&&11>=document.documentMode,ri=null,ii=null,ai=null,oi=!1;function si(e,t,n){var r=n.window===n?n.document:n.nodeType===9?n:n.ownerDocument;oi||ri==null||ri!==Xr(r)||(r=ri,`selectionStart`in r&&ti(r)?r={start:r.selectionStart,end:r.selectionEnd}:(r=(r.ownerDocument&&r.ownerDocument.defaultView||window).getSelection(),r={anchorNode:r.anchorNode,anchorOffset:r.anchorOffset,focusNode:r.focusNode,focusOffset:r.focusOffset}),ai&&Yr(ai,r)||(ai=r,r=Jf(ii,`onSelect`),0<r.length&&(t=new qn(`onSelect`,`select`,null,t,n),e.push({event:t,listeners:r}),t.target=ri)))}function ci(e,t){var n={};return n[e.toLowerCase()]=t.toLowerCase(),n[`Webkit`+e]=`webkit`+t,n[`Moz`+e]=`moz`+t,n}var li={animationend:ci(`Animation`,`AnimationEnd`),animationiteration:ci(`Animation`,`AnimationIteration`),animationstart:ci(`Animation`,`AnimationStart`),transitionrun:ci(`Transition`,`TransitionRun`),transitionstart:ci(`Transition`,`TransitionStart`),transitioncancel:ci(`Transition`,`TransitionCancel`),transitionend:ci(`Transition`,`TransitionEnd`)},ui={},di={};Fn&&(di=document.createElement(`div`).style,`AnimationEvent`in window||(delete li.animationend.animation,delete li.animationiteration.animation,delete li.animationstart.animation),`TransitionEvent`in window||delete li.transitionend.transition);function fi(e){if(ui[e])return ui[e];if(!li[e])return e;var t=li[e],n;for(n in t)if(t.hasOwnProperty(n)&&n in di)return ui[e]=t[n];return e}var pi=fi(`animationend`),mi=fi(`animationiteration`),hi=fi(`animationstart`),gi=fi(`transitionrun`),_i=fi(`transitionstart`),vi=fi(`transitioncancel`),yi=fi(`transitionend`),bi=new Map,xi=`abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error fullscreenChange fullscreenError gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel`.split(` `);xi.push(`scrollEnd`);function Si(e,t){bi.set(e,t),Yt(t,[e])}var Ci=0;function wi(e,t){if(e.name!=null&&e.name!==`auto`)return e.name;if(t.autoName!==null)return t.autoName;e=bd.identifierPrefix;var n=Ci++;return e=`_`+e+`t_`+n.toString(32)+`_`,t.autoName=e}function Ti(e){if(e==null||typeof e==`string`)return e;var t=null,n=Od;if(n!==null)for(var r=0;r<n.length;r++){var i=e[n[r]];if(i!=null){if(i===`none`)return`none`;t=t==null?i:t+(` `+i)}}return t??e.default}function Ei(e,t){return e=Ti(e),t=Ti(t),t==null?e===`auto`?null:e:t===`auto`?null:t}var Di=typeof reportError==`function`?reportError:function(e){if(typeof window==`object`&&typeof window.ErrorEvent==`function`){var t=new window.ErrorEvent(`error`,{bubbles:!0,cancelable:!0,message:typeof e==`object`&&e&&typeof e.message==`string`?String(e.message):String(e),error:e});if(!window.dispatchEvent(t))return}else if(typeof process==`object`&&typeof process.emit==`function`){process.emit(`uncaughtException`,e);return}console.error(e)},Oi=[],ki=0,Ai=0;function ji(){for(var e=ki,t=Ai=ki=0;t<e;){var n=Oi[t];Oi[t++]=null;var r=Oi[t];Oi[t++]=null;var i=Oi[t];Oi[t++]=null;var a=Oi[t];if(Oi[t++]=null,r!==null&&i!==null){var o=r.pending;o===null?i.next=i:(i.next=o.next,o.next=i),r.pending=i}a!==0&&Fi(n,i,a)}}function Mi(e,t,n,r){Oi[ki++]=e,Oi[ki++]=t,Oi[ki++]=n,Oi[ki++]=r,Ai|=r,e.lanes|=r,e=e.alternate,e!==null&&(e.lanes|=r)}function Ni(e,t,n,r){return Mi(e,t,n,r),Ii(e)}function Pi(e,t){return Mi(e,null,null,t),Ii(e)}function Fi(e,t,n){e.lanes|=n;var r=e.alternate;r!==null&&(r.lanes|=n);for(var i=!1,a=e.return;a!==null;)a.childLanes|=n,r=a.alternate,r!==null&&(r.childLanes|=n),a.tag===22&&(e=a.stateNode,e===null||e._visibility&1||(i=!0)),e=a,a=a.return;return e.tag===3?(a=e.stateNode,i&&t!==null&&(i=31-ct(n),e=a.hiddenUpdates,r=e[i],r===null?e[i]=[t]:r.push(t),t.lane=n|536870912),a):null}function Ii(e){if(50<kd)throw kd=0,Ad=null,Error(i(185));for(var t=e.return;t!==null;)e=t,t=e.return;return e.tag===3?e.stateNode:null}var Li={};function Ri(e,t,n,r){this.tag=e,this.key=n,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.refCleanup=this.ref=null,this.pendingProps=t,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=r,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function zi(e,t,n,r){return new Ri(e,t,n,r)}function Bi(e){return e=e.prototype,!(!e||!e.isReactComponent)}function Vi(e,t){var n=e.alternate;return n===null?(n=zi(e.tag,t,e.key,e.mode),n.elementType=e.elementType,n.type=e.type,n.stateNode=e.stateNode,n.alternate=e,e.alternate=n):(n.pendingProps=t,n.type=e.type,n.flags=0,n.subtreeFlags=0,n.deletions=null),n.flags=e.flags&1206910976,n.childLanes=e.childLanes,n.lanes=e.lanes,n.child=e.child,n.memoizedProps=e.memoizedProps,n.memoizedState=e.memoizedState,n.updateQueue=e.updateQueue,t=e.dependencies,n.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext},n.sibling=e.sibling,n.index=e.index,n.ref=e.ref,n.refCleanup=e.refCleanup,n}function Hi(e,t){e.flags&=1206910978;var n=e.alternate;return n===null?(e.childLanes=0,e.lanes=t,e.child=null,e.subtreeFlags=0,e.memoizedProps=null,e.memoizedState=null,e.updateQueue=null,e.dependencies=null,e.stateNode=null):(e.childLanes=n.childLanes,e.lanes=n.lanes,e.child=n.child,e.subtreeFlags=0,e.deletions=null,e.memoizedProps=n.memoizedProps,e.memoizedState=n.memoizedState,e.updateQueue=n.updateQueue,e.type=n.type,t=n.dependencies,e.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext}),e}function Ui(e,t,n,r,a,o){var s=0;if(r=e,typeof r==`function`)Bi(r)&&(s=1);else if(typeof r==`string`)s=qm(e,n,Ae.current)?26:e===`html`||e===`head`||e===`body`?27:5;else a:switch(r){case he:return e=zi(31,n,t,a),e.elementType=he,e.lanes=o,e;case oe:return Wi(n.children,a,o,t);case se:s=8,a|=24;break;case ce:return e=zi(12,n,t,a|2),e.elementType=ce,e.lanes=o,e;case de:return e=zi(13,n,t,a),e.elementType=de,e.lanes=o,e;case fe:return e=zi(19,n,t,a),e.elementType=fe,e.lanes=o,e;case ge:case ve:return e=a|32,e=zi(30,n,t,e),e.elementType=ve,e.lanes=o,e.stateNode={autoName:null,paired:null,clones:null,ref:null},e;default:if(typeof r==`object`&&r)switch(r.$$typeof){case T:s=10;break a;case le:s=9;break a;case ue:s=11;break a;case pe:s=14;break a;case me:s=16,r=null;break a}s=29,n=Error(i(130,e===null?`null`:typeof e,``)),r=null}return t=zi(s,n,t,a),t.elementType=e,t.type=r,t.lanes=o,t}function Wi(e,t,n,r){return e=zi(7,e,r,t),e.lanes=n,e}function Gi(e,t,n){return e=zi(6,e,null,t),e.lanes=n,e}function Ki(e){var t=zi(18,null,null,0);return t.stateNode=e,t}function qi(e,t,n){return t=zi(4,e.children===null?[]:e.children,e.key,t),t.lanes=n,t.stateNode={containerInfo:e.containerInfo,pendingChildren:null,implementation:e.implementation},t}var Ji=new WeakMap;function Yi(e,t){if(typeof e==`object`&&e){var n=Ji.get(e);return n===void 0?(t={value:e,source:t,stack:We(t)},Ji.set(e,t),t):n}return{value:e,source:t,stack:We(t)}}var Xi=[],Zi=0,Qi=null,$i=0,ea=[],ta=0,na=null,ra=1,ia=``;function aa(e,t){Xi[Zi++]=$i,Xi[Zi++]=Qi,Qi=e,$i=t}function oa(e,t,n){ea[ta++]=ra,ea[ta++]=ia,ea[ta++]=na,na=e;var r=ra;e=ia;var i=32-ct(r)-1;r&=~(1<<i),n+=1;var a=32-ct(t)+i;if(30<a){var o=i-i%5;a=(r&(1<<o)-1).toString(32),r>>=o,i-=o,ra=1<<32-ct(t)+i|n<<i|r,ia=a+e}else ra=1<<a|n<<i|r,ia=e}function sa(e){e.return!==null&&(aa(e,1),oa(e,1,0))}function ca(e){for(;e===Qi;)Qi=Xi[--Zi],Xi[Zi]=null,$i=Xi[--Zi],Xi[Zi]=null;for(;e===na;)na=ea[--ta],ea[ta]=null,ia=ea[--ta],ea[ta]=null,ra=ea[--ta],ea[ta]=null}function la(e,t){ea[ta++]=ra,ea[ta++]=ia,ea[ta++]=na,ra=t.id,ia=t.overflow,na=e}var ua=null,N=null,P=!1,da=null,fa=!1,pa=Error(i(519));function ma(e){throw ba(Yi(Error(i(418,1<arguments.length&&arguments[1]!==void 0&&arguments[1]?`text`:`HTML`,``)),e)),pa}function ha(e){var t=e.stateNode,n=e.type,r=e.memoizedProps;switch(t[Mt]=e,t[Nt]=r,n){case`dialog`:Q(`cancel`,t),Q(`close`,t);break;case`iframe`:case`object`:case`embed`:Q(`load`,t);break;case`video`:case`audio`:for(n=0;n<zf.length;n++)Q(zf[n],t);break;case`source`:Q(`error`,t);break;case`img`:case`image`:case`link`:Q(`error`,t),Q(`load`,t);break;case`details`:Q(`toggle`,t);break;case`input`:Q(`invalid`,t),mn(t,r.value,r.defaultValue,r.checked,r.defaultChecked,r.type,r.name,!0);break;case`select`:Q(`invalid`,t);break;case`textarea`:Q(`invalid`,t),vn(t,r.value,r.defaultValue,r.children)}n=r.children,typeof n!=`string`&&typeof n!=`number`&&typeof n!=`bigint`||t.textContent===``+n||!0===r.suppressHydrationWarning||ep(t.textContent,n)?(r.popover!=null&&(Q(`beforetoggle`,t),Q(`toggle`,t)),r.onScroll!=null&&Q(`scroll`,t),r.onScrollEnd!=null&&Q(`scrollend`,t),r.onClick!=null&&(t.onclick=Dn),t=!0):t=!1,t||ma(e,!0)}function ga(e){for(ua=e.return;ua;)switch(ua.tag){case 5:case 31:case 13:fa=!1;return;case 27:case 3:fa=!0;return;default:ua=ua.return}}function _a(e){if(e!==ua)return!1;if(!P)return ga(e),P=!0,!1;var t=e.tag,n;if((n=t!==3&&t!==27)&&((n=t===5)&&(n=e.type,n=n===`form`||n===`button`||pp(e.type,e.memoizedProps)),n=!n),n&&N&&ma(e),ga(e),t===13){if(e=e.memoizedState,e=e===null?null:e.dehydrated,!e)throw Error(i(317));N=dm(e)}else if(t===31){if(e=e.memoizedState,e=e===null?null:e.dehydrated,!e)throw Error(i(317));N=dm(e)}else t===27?(t=N,Sp(e.type)?(e=um,um=null,N=e):N=t):N=ua?lm(e.stateNode.nextSibling):null;return!0}function va(){N=ua=null,P=!1}function ya(){var e=da;return e!==null&&(pd===null?pd=e:pd.push.apply(pd,e),da=null),e}function ba(e){da===null?da=[e]:da.push(e)}var xa=Oe(null),Sa=null,Ca=null;function wa(e,t,n){O(xa,t._currentValue),t._currentValue=n}function Ta(e){e._currentValue=xa.current,ke(xa)}function Ea(e,t,n){for(;e!==null;){var r=e.alternate;if((e.childLanes&t)===t?r!==null&&(r.childLanes&t)!==t&&(r.childLanes|=t):(e.childLanes|=t,r!==null&&(r.childLanes|=t)),e===n)break;e=e.return}}function Da(e,t,n,r){var a=e.child;for(a!==null&&(a.return=e);a!==null;){var o=a.dependencies;if(o!==null){var s=a.child;o=o.firstContext;a:for(;o!==null;){var c=o;o=a;for(var l=0;l<t.length;l++)if(c.context===t[l]){o.lanes|=n,c=o.alternate,c!==null&&(c.lanes|=n),Ea(o.return,n,e),r||(s=null);break a}o=c.next}}else if(a.tag===18){if(s=a.return,s===null)throw Error(i(341));s.lanes|=n,o=s.alternate,o!==null&&(o.lanes|=n),Ea(s,n,e),s=null}else a.tag===13&&a.memoizedState!==null&&a.memoizedState.dehydrated===null?(a.lanes|=n,s=a.alternate,s!==null&&(s.lanes|=n),Ea(a.return,n,e),s=a.child,s=s===null?null:s.sibling):s=a.child;if(s!==null)s.return=a;else for(s=a;s!==null;){if(s===e){s=null;break}if(a=s.sibling,a!==null){a.return=s.return,s=a;break}s=s.return}a=s}}function Oa(e,t,n,r){e=null;for(var a=t,o=!1;a!==null;){if(!o){if(a.flags&524288)o=!0;else if(a.flags&262144)break}if(a.tag===10){var s=a.alternate;if(s===null)throw Error(i(387));if(s=s.memoizedProps,s!==null){var c=a.type;Jr(a.pendingProps.value,s.value)||(e===null?e=[c]:e.push(c))}}else if(a===Ne.current){if(s=a.alternate,s===null)throw Error(i(387));s.memoizedState.memoizedState!==a.memoizedState.memoizedState&&(e===null?e=[sh]:e.push(sh))}a=a.return}return e!==null&&Da(t,e,n,r),t.flags|=262144,e!==null}function ka(e){for(e=e.firstContext;e!==null;){if(!Jr(e.context._currentValue,e.memoizedValue))return!0;e=e.next}return!1}function Aa(e){Sa=e,Ca=null,e=e.dependencies,e!==null&&(e.firstContext=null)}function ja(e){return Na(Sa,e)}function Ma(e,t){return Sa===null&&Aa(e),Na(e,t)}function Na(e,t){var n=t._currentValue;if(t={context:t,memoizedValue:n,next:null},Ca===null){if(e===null)throw Error(i(308));Ca=t,e.dependencies={lanes:0,firstContext:t},e.flags|=524288}else Ca=Ca.next=t;return n}var Pa=typeof AbortController<`u`?AbortController:function(){var e=[],t=this.signal={aborted:!1,addEventListener:function(t,n){e.push(n)}};this.abort=function(){t.aborted=!0,e.forEach(function(e){return e()})}},Fa=t.unstable_scheduleCallback,Ia=t.unstable_NormalPriority,F={$$typeof:T,Consumer:null,Provider:null,_currentValue:null,_currentValue2:null,_threadCount:0};function La(){return{controller:new Pa,data:new Map,refCount:0}}function Ra(e){e.refCount--,e.refCount===0&&Fa(Ia,function(){e.controller.abort()})}function za(e,t){if(e.pendingLanes&4194048){var n=e.transitionTypes;for(n===null&&(n=e.transitionTypes=[]),e=0;e<t.length;e++){var r=t[e];n.indexOf(r)===-1&&n.push(r)}}}var Ba=null;function Va(e){var t=e.transitionTypes;return e.transitionTypes=null,t}var Ha=null,Ua=0,Wa=0,Ga=null;function Ka(e,t){if(Ha===null){var n=Ha=[];Ua=0,Wa=Pf(),Ga={status:`pending`,value:void 0,then:function(e){n.push(e)}}}return Ua++,t.then(qa,qa),t}function qa(){if(--Ua===0&&(Ba=null,Ha!==null)){Ga!==null&&(Ga.status=`fulfilled`);var e=Ha;Ha=null,Wa=0,Ga=null;for(var t=0;t<e.length;t++)(0,e[t])()}}function Ja(e,t){var n=[],r={status:`pending`,value:null,reason:null,then:function(e){n.push(e)}};return e.then(function(){r.status=`fulfilled`,r.value=t;for(var e=0;e<n.length;e++)(0,n[e])(t)},function(e){for(r.status=`rejected`,r.reason=e,e=0;e<n.length;e++)(0,n[e])(void 0)}),r}var Ya=E.S;E.S=function(e,t){if(gd=Xe(),typeof t==`object`&&t&&typeof t.then==`function`&&Ka(e,t),Ba!==null)for(var n=bf;n!==null;)za(n,Ba),n=n.next;if(n=e.types,n!==null){for(var r=bf;r!==null;)za(r,n),r=r.next;if(Wa!==0){r=Ba,r===null&&(r=Ba=[]);for(var i=0;i<n.length;i++){var a=n[i];r.indexOf(a)===-1&&r.push(a)}}}Ya!==null&&Ya(e,t)};var Xa=Oe(null);function Za(){var e=Xa.current;return e===null?G.pooledCache:e}function Qa(e,t){t===null?O(Xa,Xa.current):O(Xa,t.pool)}function $a(){var e=Za();return e===null?null:{parent:F._currentValue,pool:e}}var eo=Error(i(460)),to=Error(i(474)),no=Error(i(542)),ro={then:function(){}};function io(e){return e=e.status,e===`fulfilled`||e===`rejected`}function ao(e,t,n){switch(n=e[n],n===void 0?e.push(t):n!==t&&(t.then(Dn,Dn),t=n),t.status){case`fulfilled`:return t.value;case`rejected`:throw e=t.reason,lo(e),e===void 0&&!(`reason`in t)?Error(i(600)):e;default:if(typeof t.status==`string`)t.then(Dn,Dn);else{if(e=G,e!==null&&100<e.shellSuspendCounter)throw Error(i(482));e=t,e.status=`pending`,e.then(function(e){if(t.status===`pending`){var n=t;n.status=`fulfilled`,n.value=e}},function(e){if(t.status===`pending`){var n=t;n.status=`rejected`,n.reason=e}})}switch(t.status){case`fulfilled`:return t.value;case`rejected`:throw e=t.reason,lo(e),e}throw so=t,eo}}function oo(e){try{var t=e._init;return t(e._payload)}catch(e){throw typeof e==`object`&&e&&typeof e.then==`function`?(so=e,eo):e}}var so=null;function co(){if(so===null)throw Error(i(459));var e=so;return so=null,e}function lo(e){if(e===eo||e===no)throw Error(i(483))}var uo=null,fo=0;function po(e){var t=fo;return fo+=1,uo===null&&(uo=[]),ao(uo,e,t)}function mo(e,t){t=t.props.ref,e.ref=t===void 0?null:t}function ho(e,t){throw t.$$typeof===ae?Error(i(525)):(e=Object.prototype.toString.call(t),Error(i(31,e===`[object Object]`?`object with keys {`+Object.keys(t).join(`, `)+`}`:e)))}function go(e){function t(t,n){if(e){var r=t.deletions;r===null?(t.deletions=[n],t.flags|=16):r.push(n)}}function n(n,r){if(!e)return null;for(;r!==null;)t(n,r),r=r.sibling;return null}function r(e){for(var t=new Map;e!==null;)e.key===null?t.set(e.index,e):t.set(e.key,e),e=e.sibling;return t}function a(e,t){return e=Vi(e,t),e.index=0,e.sibling=null,e}function o(t,n,r){return t.index=r,e?(r=t.alternate,r===null?(t.flags|=134217730,n):(r=r.index,r<n?(t.flags|=2,n):r)):(t.flags|=1048576,n)}function s(t){return e&&t.alternate===null&&(t.flags|=134217730),t}function c(e,t,n,r){return t===null||t.tag!==6?(t=Gi(n,e.mode,r),t.return=e,t):(t=a(t,n),t.return=e,t)}function l(e,t,n,r){var i=n.type;return i===oe?(e=d(e,t,n.props.children,r,n.key),mo(e,n),e):t!==null&&(t.elementType===i||typeof i==`object`&&i&&i.$$typeof===me&&oo(i)===t.type)?(t=a(t,n.props),mo(t,n),t.return=e,t):(t=Ui(n.type,n.key,n.props,null,e.mode,r),mo(t,n),t.return=e,t)}function u(e,t,n,r){return t===null||t.tag!==4||t.stateNode.containerInfo!==n.containerInfo||t.stateNode.implementation!==n.implementation?(t=qi(n,e.mode,r),t.return=e,t):(t=a(t,n.children||[]),t.return=e,t)}function d(e,t,n,r,i){return t===null||t.tag!==7?(t=Wi(n,e.mode,r,i),t.return=e,t):(t=a(t,n),t.return=e,t)}function f(e,t,n){if(typeof t==`string`&&t!==``||typeof t==`number`||typeof t==`bigint`)return t=Gi(``+t,e.mode,n),t.return=e,t;if(typeof t==`object`&&t){switch(t.$$typeof){case C:return n=Ui(t.type,t.key,t.props,null,e.mode,n),mo(n,t),n.return=e,n;case w:return t=qi(t,e.mode,n),t.return=e,t;case me:return t=oo(t),f(e,t,n)}if(we(t)||xe(t))return t=Wi(t,e.mode,n,null),t.return=e,t;if(typeof t.then==`function`)return f(e,po(t),n);if(t.$$typeof===T)return f(e,Ma(e,t),n);ho(e,t)}return null}function p(e,t,n,r){var i=t===null?null:t.key;if(typeof n==`string`&&n!==``||typeof n==`number`||typeof n==`bigint`)return i===null?c(e,t,``+n,r):null;if(typeof n==`object`&&n){switch(n.$$typeof){case C:return n.key===i?l(e,t,n,r):null;case w:return n.key===i?u(e,t,n,r):null;case me:return n=oo(n),p(e,t,n,r)}if(we(n)||xe(n))return i===null?d(e,t,n,r,null):null;if(typeof n.then==`function`)return p(e,t,po(n),r);if(n.$$typeof===T)return p(e,t,Ma(e,n),r);ho(e,n)}return null}function m(e,t,n,r,i){if(typeof r==`string`&&r!==``||typeof r==`number`||typeof r==`bigint`)return e=e.get(n)||null,c(t,e,``+r,i);if(typeof r==`object`&&r){switch(r.$$typeof){case C:return e=e.get(r.key===null?n:r.key)||null,l(t,e,r,i);case w:return e=e.get(r.key===null?n:r.key)||null,u(t,e,r,i);case me:return r=oo(r),m(e,t,n,r,i)}if(we(r)||xe(r))return e=e.get(n)||null,d(t,e,r,i,null);if(typeof r.then==`function`)return m(e,t,n,po(r),i);if(r.$$typeof===T)return m(e,t,n,Ma(t,r),i);ho(t,r)}return null}function h(i,a,s,c){for(var l=null,u=null,d=a,h=a=0,g=null;d!==null&&h<s.length;h++){d.index>h?(g=d,d=null):g=d.sibling;var _=p(i,d,s[h],c);if(_===null){d===null&&(d=g);break}e&&d&&_.alternate===null&&t(i,d),a=o(_,a,h),u===null?l=_:u.sibling=_,u=_,d=g}if(h===s.length)return n(i,d),P&&aa(i,h),l;if(d===null){for(;h<s.length;h++)d=f(i,s[h],c),d!==null&&(a=o(d,a,h),u===null?l=d:u.sibling=d,u=d);return P&&aa(i,h),l}for(d=r(d);h<s.length;h++)g=m(d,i,h,s[h],c),g!==null&&(e&&(_=g.alternate,_!==null&&d.delete(_.key===null?h:_.key)),a=o(g,a,h),u===null?l=g:u.sibling=g,u=g);return e&&d.forEach(function(e){return t(i,e)}),P&&aa(i,h),l}function g(a,s,c,l){if(c==null)throw Error(i(151));for(var u=null,d=null,h=s,g=s=0,_=null,v=c.next();h!==null&&!v.done;g++,v=c.next()){h.index>g?(_=h,h=null):_=h.sibling;var y=p(a,h,v.value,l);if(y===null){h===null&&(h=_);break}e&&h&&y.alternate===null&&t(a,h),s=o(y,s,g),d===null?u=y:d.sibling=y,d=y,h=_}if(v.done)return n(a,h),P&&aa(a,g),u;if(h===null){for(;!v.done;g++,v=c.next())v=f(a,v.value,l),v!==null&&(s=o(v,s,g),d===null?u=v:d.sibling=v,d=v);return P&&aa(a,g),u}for(h=r(h);!v.done;g++,v=c.next())v=m(h,a,g,v.value,l),v!==null&&(e&&(_=v.alternate,_!==null&&h.delete(_.key===null?g:_.key)),s=o(v,s,g),d===null?u=v:d.sibling=v,d=v);return e&&h.forEach(function(e){return t(a,e)}),P&&aa(a,g),u}function _(e,r,o,c){if(typeof o==`object`&&o&&o.type===oe&&o.key===null&&o.props.ref===void 0&&(o=o.props.children),typeof o==`object`&&o){switch(o.$$typeof){case C:a:{for(var l=o.key;r!==null;){if(r.key===l){if(l=o.type,l===oe){if(r.tag===7){n(e,r.sibling),c=a(r,o.props.children),mo(c,o),c.return=e,e=c;break a}}else if(r.elementType===l||typeof l==`object`&&l&&l.$$typeof===me&&oo(l)===r.type){n(e,r.sibling),c=a(r,o.props),mo(c,o),c.return=e,e=c;break a}n(e,r);break}t(e,r),r=r.sibling}o.type===oe?(c=Wi(o.props.children,e.mode,c,o.key),mo(c,o),c.return=e,e=c):(c=Ui(o.type,o.key,o.props,null,e.mode,c),mo(c,o),c.return=e,e=c)}return s(e);case w:a:{for(l=o.key;r!==null;){if(r.key===l){if(r.tag===4&&r.stateNode.containerInfo===o.containerInfo&&r.stateNode.implementation===o.implementation){n(e,r.sibling),c=a(r,o.children||[]),c.return=e,e=c;break a}n(e,r);break}t(e,r),r=r.sibling}c=qi(o,e.mode,c),c.return=e,e=c}return s(e);case me:return o=oo(o),_(e,r,o,c)}if(we(o))return h(e,r,o,c);if(xe(o)){if(l=xe(o),typeof l!=`function`)throw Error(i(150));return o=l.call(o),g(e,r,o,c)}if(typeof o.then==`function`)return _(e,r,po(o),c);if(o.$$typeof===T)return _(e,r,Ma(e,o),c);ho(e,o)}return typeof o==`string`&&o!==``||typeof o==`number`||typeof o==`bigint`?(o=``+o,r!==null&&r.tag===6?(n(e,r.sibling),c=a(r,o),c.return=e,e=c):(n(e,r),c=Gi(o,e.mode,c),c.return=e,e=c),s(e)):n(e,r)}return function(e,t,n,r){try{fo=0;var i=_(e,t,n,r);return uo=null,i}catch(t){if(t===eo||t===no)throw t;var a=zi(29,t,null,e.mode);return a.lanes=r,a.return=e,a}}}var _o=go(!0),vo=go(!1),yo=!1;function bo(e){e.updateQueue={baseState:e.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,lanes:0,hiddenCallbacks:null},callbacks:null}}function xo(e,t){e=e.updateQueue,t.updateQueue===e&&(t.updateQueue={baseState:e.baseState,firstBaseUpdate:e.firstBaseUpdate,lastBaseUpdate:e.lastBaseUpdate,shared:e.shared,callbacks:null})}function So(e){return{lane:e,tag:0,payload:null,callback:null,next:null}}function Co(e,t,n){var r=e.updateQueue;if(r===null)return null;if(r=r.shared,W&2){var i=r.pending;return i===null?t.next=t:(t.next=i.next,i.next=t),r.pending=t,t=Ii(e),Fi(e,null,n),t}return Mi(e,r,t,n),Ii(e)}function wo(e,t,n){if(t=t.updateQueue,t!==null&&(t=t.shared,n&4194048)){var r=t.lanes;r&=e.pendingLanes,n|=r,t.lanes=n,Tt(e,n)}}function To(e,t){var n=e.updateQueue,r=e.alternate;if(r!==null&&(r=r.updateQueue,n===r)){var i=null,a=null;if(n=n.firstBaseUpdate,n!==null){do{var o={lane:n.lane,tag:n.tag,payload:n.payload,callback:null,next:null};a===null?i=a=o:a=a.next=o,n=n.next}while(n!==null);a===null?i=a=t:a=a.next=t}else i=a=t;n={baseState:r.baseState,firstBaseUpdate:i,lastBaseUpdate:a,shared:r.shared,callbacks:r.callbacks},e.updateQueue=n;return}e=n.lastBaseUpdate,e===null?n.firstBaseUpdate=t:e.next=t,n.lastBaseUpdate=t}var Eo=!1;function Do(){if(Eo){var e=Ga;if(e!==null)throw e}}function Oo(e,t,n,r){Eo=!1;var i=e.updateQueue;yo=!1;var a=i.firstBaseUpdate,o=i.lastBaseUpdate,s=i.shared.pending;if(s!==null){i.shared.pending=null;var c=s,l=c.next;c.next=null,o===null?a=l:o.next=l,o=c;var u=e.alternate;u!==null&&(u=u.updateQueue,s=u.lastBaseUpdate,s!==o&&(s===null?u.firstBaseUpdate=l:s.next=l,u.lastBaseUpdate=c))}if(a!==null){var d=i.baseState;o=0,u=l=c=null,s=a;do{var f=s.lane&-536870913,p=f!==s.lane;if(p?(q&f)===f:(r&f)===f){f!==0&&f===Wa&&(Eo=!0),u!==null&&(u=u.next={lane:0,tag:s.tag,payload:s.payload,callback:null,next:null});a:{var m=e,h=s;f=t;var g=n;switch(h.tag){case 1:if(m=h.payload,typeof m==`function`){d=m.call(g,d,f);break a}d=m;break a;case 3:m.flags=m.flags&-65537|128;case 0:if(m=h.payload,f=typeof m==`function`?m.call(g,d,f):m,f==null)break a;d=S({},d,f);break a;case 2:yo=!0}}f=s.callback,f!==null&&(e.flags|=64,p&&(e.flags|=8192),p=i.callbacks,p===null?i.callbacks=[f]:p.push(f))}else p={lane:f,tag:s.tag,payload:s.payload,callback:s.callback,next:null},u===null?(l=u=p,c=d):u=u.next=p,o|=f;if(s=s.next,s===null){if(s=i.shared.pending,s===null)break;p=s,s=p.next,p.next=null,i.lastBaseUpdate=p,i.shared.pending=null}}while(1);u===null&&(c=d),i.baseState=c,i.firstBaseUpdate=l,i.lastBaseUpdate=u,a===null&&(i.shared.lanes=0),sd|=o,e.lanes=o,e.memoizedState=d}}function ko(e,t){if(typeof e!=`function`)throw Error(i(191,e));e.call(t)}function Ao(e,t){var n=e.callbacks;if(n!==null)for(e.callbacks=null,e=0;e<n.length;e++)ko(n[e],t)}var jo=Oe(null),Mo=Oe(0);function No(e,t){e=od,O(Mo,e),O(jo,t),od=e|t.baseLanes}function Po(){O(Mo,od),O(jo,jo.current)}function Fo(){od=Mo.current,ke(jo),ke(Mo)}var Io=Oe(null),Lo=null;function Ro(e){var t=e.alternate;O(Uo,Uo.current&1),O(Io,e),Lo===null&&(t===null||jo.current!==null||t.memoizedState!==null)&&(Lo=e)}function zo(e){O(Uo,Uo.current),O(Io,e),Lo===null&&(Lo=e)}function Bo(e){e.tag===22?(O(Uo,Uo.current),O(Io,e),Lo===null&&(Lo=e)):Vo()}function Vo(){O(Uo,Uo.current),O(Io,Io.current)}function Ho(e){ke(Io),Lo===e&&(Lo=null),ke(Uo)}var Uo=Oe(0);function Wo(e,t){O(Io,Io.current),O(Uo,t)}function Go(e){ke(Uo),ke(Io),Lo===e&&(Lo=null)}function Ko(e){for(var t=e;t!==null;){if(t.tag===13){var n=t.memoizedState;if(n!==null&&(n=n.dehydrated,n===null||om(n)||sm(n)))return t}else if(t.tag===19&&t.memoizedProps.revealOrder!==`independent`){if(t.flags&128)return t}else if(t.child!==null){t.child.return=t,t=t.child;continue}if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return null;t=t.return}t.sibling.return=t.return,t=t.sibling}return null}var qo=0,I=null,L=null,R=null,Jo=!1,Yo=!1,Xo=!1,Zo=0,Qo=0,$o=null,es=0;function z(){throw Error(i(321))}function ts(e,t){if(t===null)return!1;for(var n=0;n<t.length&&n<e.length;n++)if(!Jr(e[n],t[n]))return!1;return!0}function ns(e,t,n,r,i,a){return qo=a,I=t,t.memoizedState=null,t.updateQueue=null,t.lanes=0,E.H=e===null||e.memoizedState===null?vc:yc,Xo=!1,a=n(r,i),Xo=!1,Yo&&(a=is(t,n,r,i)),rs(e),a}function rs(e){E.H=_c;var t=L!==null&&L.next!==null;if(qo=0,R=L=I=null,Jo=!1,Qo=0,$o=null,t)throw Error(i(300));e===null||Ic||(e=e.dependencies,e!==null&&ka(e)&&(Ic=!0))}function is(e,t,n,r){I=e;var a=0;do{if(Yo&&($o=null),Qo=0,Yo=!1,25<=a)throw Error(i(301));if(a+=1,R=L=null,e.updateQueue!=null){var o=e.updateQueue;o.lastEffect=null,o.events=null,o.stores=null,o.memoCache!=null&&(o.memoCache.index=0)}E.H=bc,o=t(n,r)}while(Yo);return o}function as(){var e=E.H,t=e.useState()[0];return t=typeof t.then==`function`?ds(t):t,e=e.useState()[0],(L===null?null:L.memoizedState)!==e&&(I.flags|=1024),t}function os(){var e=Zo!==0;return Zo=0,e}function ss(e,t,n){t.updateQueue=e.updateQueue,t.flags&=-2053,e.lanes&=~n}function cs(e){if(Jo){for(e=e.memoizedState;e!==null;){var t=e.queue;t!==null&&(t.pending=null),e=e.next}Jo=!1}qo=0,R=L=I=null,Yo=!1,Qo=Zo=0,$o=null}function ls(){var e={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return R===null?I.memoizedState=R=e:R=R.next=e,R}function B(){if(L===null){var e=I.alternate;e=e===null?null:e.memoizedState}else e=L.next;var t=R===null?I.memoizedState:R.next;if(t!==null)R=t,L=e;else{if(e===null)throw I.alternate===null?Error(i(467)):Error(i(310));L=e,e={memoizedState:L.memoizedState,baseState:L.baseState,baseQueue:L.baseQueue,queue:L.queue,next:null},R===null?I.memoizedState=R=e:R=R.next=e}return R}function us(){return{lastEffect:null,events:null,stores:null,memoCache:null}}function ds(e){var t=Qo;return Qo+=1,$o===null&&($o=[]),e=ao($o,e,t),t=I,(R===null?t.memoizedState:R.next)===null&&(t=t.alternate,E.H=t===null||t.memoizedState===null?vc:yc),e}function fs(e){if(typeof e==`object`&&e){if(typeof e.then==`function`)return ds(e);if(e.$$typeof===ye)return;if(e.$$typeof===T)return ja(e)}throw Error(i(438,String(e)))}function ps(e){var t=null,n=I.updateQueue;if(n!==null&&(t=n.memoCache),t==null){var r=I.alternate;r!==null&&(r=r.updateQueue,r!==null&&(r=r.memoCache,r!=null&&(t={data:r.data.map(function(e){return e.slice()}),index:0})))}if(t??={data:[],index:0},n===null&&(n=us(),I.updateQueue=n),n.memoCache=t,n=t.data[t.index],n===void 0)for(n=t.data[t.index]=Array(e),r=0;r<e;r++)n[r]=_e;return t.index++,n}function ms(e,t){return typeof t==`function`?t(e):t}function hs(e){return gs(B(),L,e)}function gs(e,t,n){var r=e.queue;if(r===null)throw Error(i(311));r.lastRenderedReducer=n;var a=e.baseQueue,o=r.pending;if(o!==null){if(a!==null){var s=a.next;a.next=o.next,o.next=s}t.baseQueue=a=o,r.pending=null}if(o=e.baseState,a===null)e.memoizedState=o;else{t=a.next;var c=s=null,l=null,u=t,d=!1;do{var f=u.lane&-536870913;if(f===u.lane?(qo&f)===f:(q&f)===f){var p=u.revertLane;if(p===0)l!==null&&(l=l.next={lane:0,revertLane:0,gesture:null,action:u.action,hasEagerState:u.hasEagerState,eagerState:u.eagerState,next:null}),f===Wa&&(d=!0);else if((qo&p)===p){u=u.next,p===Wa&&(d=!0);continue}else f={lane:0,revertLane:u.revertLane,gesture:null,action:u.action,hasEagerState:u.hasEagerState,eagerState:u.eagerState,next:null},l===null?(c=l=f,s=o):l=l.next=f,I.lanes|=p,sd|=p;f=u.action,Xo&&n(o,f),o=u.hasEagerState?u.eagerState:n(o,f)}else p={lane:f,revertLane:u.revertLane,gesture:u.gesture,action:u.action,hasEagerState:u.hasEagerState,eagerState:u.eagerState,next:null},l===null?(c=l=p,s=o):l=l.next=p,I.lanes|=f,sd|=f;u=u.next}while(u!==null&&u!==t);if(l===null?s=o:l.next=c,!Jr(o,e.memoizedState)&&(Ic=!0,d&&(n=Ga,n!==null)))throw n;e.memoizedState=o,e.baseState=s,e.baseQueue=l,r.lastRenderedState=o}return a===null&&(r.lanes=0),[e.memoizedState,r.dispatch]}function _s(e){var t=B(),n=t.queue;if(n===null)throw Error(i(311));n.lastRenderedReducer=e;var r=n.dispatch,a=n.pending,o=t.memoizedState;if(a!==null){n.pending=null;var s=a=a.next;do o=e(o,s.action),s=s.next;while(s!==a);Jr(o,t.memoizedState)||(Ic=!0),t.memoizedState=o,t.baseQueue===null&&(t.baseState=o),n.lastRenderedState=o}return[o,r]}function vs(e,t,n){var r=I,a=B(),o=P;if(o){if(n===void 0)throw Error(i(407));n=n()}else n=t();var s=!Jr((L||a).memoizedState,n);if(s&&(a.memoizedState=n,Ic=!0),a=a.queue,Us(xs.bind(null,r,a,e),[e]),e=a.getSnapshot!==t||s||R!==null&&!!(R.memoizedState.tag&1),Rs(e?9:8,{destroy:void 0},bs.bind(null,r,a,n,t),null),e){if(r.flags|=2048,G===null)throw Error(i(349));o||qo&127||ys(r,t,n)}return n}function ys(e,t,n){e.flags|=16384,e={getSnapshot:t,value:n},t=I.updateQueue,t===null?(t=us(),I.updateQueue=t,t.stores=[e]):(n=t.stores,n===null?t.stores=[e]:n.push(e))}function bs(e,t,n,r){t.value=n,t.getSnapshot=r,Ss(t)&&Cs(e)}function xs(e,t,n){return n(function(){Ss(t)&&Cs(e)})}function Ss(e){var t=e.getSnapshot;e=e.value;try{var n=t();return!Jr(e,n)}catch{return!0}}function Cs(e){var t=Pi(e,2);t!==null&&Pd(t,e,2)}function ws(e){var t=ls();if(typeof e==`function`){var n=e;if(e=n(),Xo){st(!0);try{n()}finally{st(!1)}}}return t.memoizedState=t.baseState=e,t.queue={pending:null,lanes:0,dispatch:null,lastRenderedReducer:ms,lastRenderedState:e},t}function Ts(e,t,n,r){return e.baseState=n,gs(e,L,typeof r==`function`?r:ms)}function Es(e,t,n,r,a){if(mc(e))throw Error(i(485));if(e=t.action,e!==null){var o={payload:a,action:e,next:null,isTransition:!0,status:`pending`,value:null,reason:null,listeners:[],then:function(e){o.listeners.push(e)}};E.T===null?o.isTransition=!1:n(!0),r(o),n=t.pending,n===null?(o.next=t.pending=o,Ds(t,o)):(o.next=n.next,t.pending=n.next=o)}}function Ds(e,t){var n=t.action,r=t.payload,i=e.state;if(t.isTransition){var a=E.T,o={};o.types=a===null?null:a.types,E.T=o;try{var s=n(i,r),c=E.S;c!==null&&c(o,s),Os(e,t,s)}catch(n){As(e,t,n)}finally{a!==null&&o.types!==null&&(a.types=o.types),E.T=a}}else try{a=n(i,r),Os(e,t,a)}catch(n){As(e,t,n)}}function Os(e,t,n){typeof n==`object`&&n&&typeof n.then==`function`?n.then(function(n){ks(e,t,n)},function(n){return As(e,t,n)}):ks(e,t,n)}function ks(e,t,n){t.status=`fulfilled`,t.value=n,js(t),e.state=n,t=e.pending,t!==null&&(n=t.next,n===t?e.pending=null:(n=n.next,t.next=n,Ds(e,n)))}function As(e,t,n){var r=e.pending;if(e.pending=null,r!==null){r=r.next;do t.status=`rejected`,t.reason=n,js(t),t=t.next;while(t!==r)}e.action=null}function js(e){e=e.listeners;for(var t=0;t<e.length;t++)(0,e[t])()}function Ms(e,t){return t}function Ns(e,t){if(P){var n=G.formState;if(n!==null){a:{var r=I;if(P){if(N){b:{for(var i=N,a=fa;i.nodeType!==8;){if(!a){i=null;break b}if(i=lm(i.nextSibling),i===null){i=null;break b}}a=i.data,i=a===`F!`||a===`F`?i:null}if(i){N=lm(i.nextSibling),r=i.data===`F!`;break a}}ma(r)}r=!1}r&&(t=n[0])}}return n=ls(),n.memoizedState=n.baseState=t,r={pending:null,lanes:0,dispatch:null,lastRenderedReducer:Ms,lastRenderedState:t},n.queue=r,n=dc.bind(null,I,r),r.dispatch=n,r=ws(!1),a=pc.bind(null,I,!1,r.queue),r=ls(),i={state:t,dispatch:null,action:e,pending:null},r.queue=i,n=Es.bind(null,I,i,a,n),i.dispatch=n,r.memoizedState=e,[t,n,!1]}function Ps(e){return Fs(B(),L,e)}function Fs(e,t,n){if(t=gs(e,t,Ms)[0],e=hs(ms)[0],typeof t==`object`&&t&&typeof t.then==`function`)try{var r=ds(t)}catch(e){throw e===eo?no:e}else r=t;t=B();var i=t.queue,a=i.dispatch;return n!==t.memoizedState&&(I.flags|=2048,Rs(9,{destroy:void 0},Is.bind(null,i,n),null)),[r,a,e]}function Is(e,t){e.action=t}function Ls(e){var t=B(),n=L;if(n!==null)return Fs(t,n,e);B(),t=t.memoizedState,n=B();var r=n.queue.dispatch;return n.memoizedState=e,[t,r,!1]}function Rs(e,t,n,r){return e={tag:e,create:n,deps:r,inst:t,next:null},t=I.updateQueue,t===null&&(t=us(),I.updateQueue=t),n=t.lastEffect,n===null?t.lastEffect=e.next=e:(r=n.next,n.next=e,e.next=r,t.lastEffect=e),e}function zs(){return B().memoizedState}function Bs(e,t,n,r){var i=ls();I.flags|=e,i.memoizedState=Rs(1|t,{destroy:void 0},n,r===void 0?null:r)}function Vs(e,t,n,r){var i=B();r=r===void 0?null:r;var a=i.memoizedState.inst;L!==null&&r!==null&&ts(r,L.memoizedState.deps)?i.memoizedState=Rs(t,a,n,r):(I.flags|=e,i.memoizedState=Rs(1|t,a,n,r))}function Hs(e,t){Bs(8390656,8,e,t)}function Us(e,t){Vs(2048,8,e,t)}function Ws(e){I.flags|=4;var t=I.updateQueue;if(t===null)t=us(),I.updateQueue=t,t.events=[e];else{var n=t.events;n===null?t.events=[e]:n.push(e)}}function Gs(e){var t=B().memoizedState;return Ws({ref:t,nextImpl:e}),function(){if(W&2)throw Error(i(440));return t.impl.apply(void 0,arguments)}}function Ks(e,t){return Vs(4,2,e,t)}function qs(e,t){return Vs(4,4,e,t)}function Js(e,t){if(typeof t==`function`){e=e();var n=t(e);return function(){typeof n==`function`?n():t(null)}}if(t!=null)return e=e(),t.current=e,function(){t.current=null}}function Ys(e,t,n){n=n==null?null:n.concat([e]),Vs(4,4,Js.bind(null,t,e),n)}function Xs(){}function Zs(e,t){var n=B();t=t===void 0?null:t;var r=n.memoizedState;return t!==null&&ts(t,r[1])?r[0]:(n.memoizedState=[e,t],e)}function Qs(e,t){var n=B();t=t===void 0?null:t;var r=n.memoizedState;if(t!==null&&ts(t,r[1]))return r[0];if(r=e(),Xo){st(!0);try{e()}finally{st(!1)}}return n.memoizedState=[r,t],r}function $s(e,t,n){return n===void 0||qo&1073741824&&!(q&261930)?e.memoizedState=t:(e.memoizedState=n,e=Md(),I.lanes|=e,sd|=e,n)}function ec(e,t,n,r){return Jr(n,t)?n:jo.current===null?!(qo&106)||qo&1073741824&&!(q&261930)?(Ic=!0,e.memoizedState=n):(e=Md(),I.lanes|=e,sd|=e,t):(e=$s(e,n,r),Jr(e,t)||(Ic=!0),e)}function tc(e,t,n,r,i){var a=D.p;D.p=a!==0&&8>a?a:8;var o=E.T,s={};s.types=o===null?null:o.types,E.T=s,pc(e,!1,t,n);try{var c=i(),l=E.S;l!==null&&l(s,c),typeof c==`object`&&c&&typeof c.then==`function`?fc(e,t,Ja(c,r),jd(e)):fc(e,t,r,jd(e))}catch(n){fc(e,t,{then:function(){},status:`rejected`,reason:n},jd())}finally{D.p=a,o!==null&&s.types!==null&&(o.types=s.types),E.T=o}}function nc(){}function rc(e,t,n,r){if(e.tag!==5)throw Error(i(476));var a=ic(e).queue;tc(e,a,t,Te,n===null?nc:function(){return ac(e),n(r)})}function ic(e){var t=e.memoizedState;if(t!==null)return t;t={memoizedState:Te,baseState:Te,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:ms,lastRenderedState:Te},next:null};var n={};return t.next={memoizedState:n,baseState:n,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:ms,lastRenderedState:n},next:null},e.memoizedState=t,e=e.alternate,e!==null&&(e.memoizedState=t),t}function ac(e){var t=ic(e);t.next===null&&(t=e.alternate.memoizedState),fc(e,t.next.queue,{},jd())}function oc(){return ja(sh)}function sc(){return B().memoizedState}function cc(){return B().memoizedState}function lc(e){for(var t=e.return;t!==null;){switch(t.tag){case 24:case 3:var n=jd();e=So(n);var r=Co(t,e,n);r!==null&&(Pd(r,t,n),wo(r,t,n)),t={cache:La()},e.payload=t;return}t=t.return}}function uc(e,t,n){var r=jd();n={lane:r,revertLane:0,gesture:null,action:n,hasEagerState:!1,eagerState:null,next:null},mc(e)?hc(t,n):(n=Ni(e,t,n,r),n!==null&&(Pd(n,e,r),gc(n,t,r)))}function dc(e,t,n){fc(e,t,n,jd())}function fc(e,t,n,r){var i={lane:r,revertLane:0,gesture:null,action:n,hasEagerState:!1,eagerState:null,next:null};if(mc(e))hc(t,i);else{var a=e.alternate;if(e.lanes===0&&(a===null||a.lanes===0)&&(a=t.lastRenderedReducer,a!==null))try{var o=t.lastRenderedState,s=a(o,n);if(i.hasEagerState=!0,i.eagerState=s,Jr(s,o))return Mi(e,t,i,0),G===null&&ji(),!1}catch{}if(n=Ni(e,t,i,r),n!==null)return Pd(n,e,r),gc(n,t,r),!0}return!1}function pc(e,t,n,r){if(r={lane:2,revertLane:Pf(),gesture:null,action:r,hasEagerState:!1,eagerState:null,next:null},mc(e)){if(t)throw Error(i(479))}else t=Ni(e,n,r,2),t!==null&&Pd(t,e,2)}function mc(e){var t=e.alternate;return e===I||t!==null&&t===I}function hc(e,t){Yo=Jo=!0;var n=e.pending;n===null?t.next=t:(t.next=n.next,n.next=t),e.pending=t}function gc(e,t,n){if(n&4194048){var r=t.lanes;r&=e.pendingLanes,n|=r,t.lanes=n,Tt(e,n)}}var _c={readContext:ja,use:fs,useCallback:z,useContext:z,useEffect:z,useImperativeHandle:z,useLayoutEffect:z,useInsertionEffect:z,useMemo:z,useReducer:z,useRef:z,useState:z,useDebugValue:z,useDeferredValue:z,useTransition:z,useSyncExternalStore:z,useId:z,useHostTransitionStatus:z,useFormState:z,useActionState:z,useOptimistic:z,useMemoCache:z,useCacheRefresh:z,useEffectEvent:z},vc={readContext:ja,use:fs,useCallback:function(e,t){return ls().memoizedState=[e,t===void 0?null:t],e},useContext:ja,useEffect:Hs,useImperativeHandle:function(e,t,n){n=n==null?null:n.concat([e]),Bs(4194308,4,Js.bind(null,t,e),n)},useLayoutEffect:function(e,t){return Bs(4194308,4,e,t)},useInsertionEffect:function(e,t){Bs(4,2,e,t)},useMemo:function(e,t){var n=ls();t=t===void 0?null:t;var r=e();if(Xo){st(!0);try{e()}finally{st(!1)}}return n.memoizedState=[r,t],r},useReducer:function(e,t,n){var r=ls();if(n!==void 0){var i=n(t);if(Xo){st(!0);try{n(t)}finally{st(!1)}}}else i=t;return r.memoizedState=r.baseState=i,e={pending:null,lanes:0,dispatch:null,lastRenderedReducer:e,lastRenderedState:i},r.queue=e,e=e.dispatch=uc.bind(null,I,e),[r.memoizedState,e]},useRef:function(e){var t=ls();return e={current:e},t.memoizedState=e},useState:function(e){e=ws(e);var t=e.queue,n=dc.bind(null,I,t);return t.dispatch=n,[e.memoizedState,n]},useDebugValue:Xs,useDeferredValue:function(e,t){return $s(ls(),e,t)},useTransition:function(){var e=ws(!1);return e=tc.bind(null,I,e.queue,!0,!1),ls().memoizedState=e,[!1,e]},useSyncExternalStore:function(e,t,n){var r=I,a=ls();if(P){if(n===void 0)throw Error(i(407));n=n()}else{if(n=t(),G===null)throw Error(i(349));q&127||ys(r,t,n)}a.memoizedState=n;var o={value:n,getSnapshot:t};return a.queue=o,Hs(xs.bind(null,r,o,e),[e]),r.flags|=2048,Rs(9,{destroy:void 0},bs.bind(null,r,o,n,t),null),n},useId:function(){var e=ls(),t=G.identifierPrefix;if(P){var n=ia,r=ra;n=(r&~(1<<32-ct(r)-1)).toString(32)+n,t=`_`+t+`R_`+n,n=Zo++,0<n&&(t+=`H`+n.toString(32)),t+=`_`}else n=es++,t=`_`+t+`r_`+n.toString(32)+`_`;return e.memoizedState=t},useHostTransitionStatus:oc,useFormState:Ns,useActionState:Ns,useOptimistic:function(e){var t=ls();t.memoizedState=t.baseState=e;var n={pending:null,lanes:0,dispatch:null,lastRenderedReducer:null,lastRenderedState:null};return t.queue=n,t=pc.bind(null,I,!0,n),n.dispatch=t,[e,t]},useMemoCache:ps,useCacheRefresh:function(){return ls().memoizedState=lc.bind(null,I)},useEffectEvent:function(e){var t=ls(),n={impl:e};return t.memoizedState=n,function(){if(W&2)throw Error(i(440));return n.impl.apply(void 0,arguments)}}},yc={readContext:ja,use:fs,useCallback:Zs,useContext:ja,useEffect:Us,useImperativeHandle:Ys,useInsertionEffect:Ks,useLayoutEffect:qs,useMemo:Qs,useReducer:hs,useRef:zs,useState:function(){return hs(ms)},useDebugValue:Xs,useDeferredValue:function(e,t){return ec(B(),L.memoizedState,e,t)},useTransition:function(){var e=hs(ms)[0],t=B().memoizedState;return[typeof e==`boolean`?e:ds(e),t]},useSyncExternalStore:vs,useId:sc,useHostTransitionStatus:oc,useFormState:Ps,useActionState:Ps,useOptimistic:function(e,t){return Ts(B(),L,e,t)},useMemoCache:ps,useCacheRefresh:cc,useEffectEvent:Gs},bc={readContext:ja,use:fs,useCallback:Zs,useContext:ja,useEffect:Us,useImperativeHandle:Ys,useInsertionEffect:Ks,useLayoutEffect:qs,useMemo:Qs,useReducer:_s,useRef:zs,useState:function(){return _s(ms)},useDebugValue:Xs,useDeferredValue:function(e,t){var n=B();return L===null?$s(n,e,t):ec(n,L.memoizedState,e,t)},useTransition:function(){var e=_s(ms)[0],t=B().memoizedState;return[typeof e==`boolean`?e:ds(e),t]},useSyncExternalStore:vs,useId:sc,useHostTransitionStatus:oc,useFormState:Ls,useActionState:Ls,useOptimistic:function(e,t){var n=B();return L===null?(n.baseState=e,[e,n.queue.dispatch]):Ts(n,L,e,t)},useMemoCache:ps,useCacheRefresh:cc,useEffectEvent:Gs};function xc(e,t,n,r){t=e.memoizedState,n=n(r,t),n=n==null?t:S({},t,n),e.memoizedState=n,e.lanes===0&&(e.updateQueue.baseState=n)}var Sc={enqueueSetState:function(e,t,n){e=e._reactInternals;var r=jd(),i=So(r);i.payload=t,n!=null&&(i.callback=n),t=Co(e,i,r),t!==null&&(Pd(t,e,r),wo(t,e,r))},enqueueReplaceState:function(e,t,n){e=e._reactInternals;var r=jd(),i=So(r);i.tag=1,i.payload=t,n!=null&&(i.callback=n),t=Co(e,i,r),t!==null&&(Pd(t,e,r),wo(t,e,r))},enqueueForceUpdate:function(e,t){e=e._reactInternals;var n=jd(),r=So(n);r.tag=2,t!=null&&(r.callback=t),t=Co(e,r,n),t!==null&&(Pd(t,e,n),wo(t,e,n))}};function Cc(e,t,n,r,i,a,o){return e=e.stateNode,typeof e.shouldComponentUpdate==`function`?e.shouldComponentUpdate(r,a,o):t.prototype&&t.prototype.isPureReactComponent?!Yr(n,r)||!Yr(i,a):!0}function wc(e,t,n,r){e=t.state,typeof t.componentWillReceiveProps==`function`&&t.componentWillReceiveProps(n,r),typeof t.UNSAFE_componentWillReceiveProps==`function`&&t.UNSAFE_componentWillReceiveProps(n,r),t.state!==e&&Sc.enqueueReplaceState(t,t.state,null)}function Tc(e,t){var n=t;if(`ref`in t)for(var r in n={},t)r!==`ref`&&(n[r]=t[r]);if(e=e.defaultProps)for(var i in n===t&&(n=S({},n)),e)n[i]===void 0&&(n[i]=e[i]);return n}function Ec(e){Di(e)}function Dc(e){console.error(e)}function Oc(e){Di(e)}function kc(e,t){try{var n=e.onUncaughtError;n(t.value,{componentStack:t.stack})}catch(e){setTimeout(function(){throw e})}}function Ac(e,t,n){try{var r=e.onCaughtError;r(n.value,{componentStack:n.stack,errorBoundary:t.tag===1?t.stateNode:null})}catch(e){setTimeout(function(){throw e})}}function jc(e,t,n){return n=So(n),n.tag=3,n.payload={element:null},n.callback=function(){kc(e,t)},n}function Mc(e){return e=So(e),e.tag=3,e}function Nc(e,t,n,r){var i=n.type.getDerivedStateFromError;if(typeof i==`function`){var a=r.value;e.payload=function(){return i(a)},e.callback=function(){Ac(t,n,r)}}var o=n.stateNode;o!==null&&typeof o.componentDidCatch==`function`&&(e.callback=function(){Ac(t,n,r),typeof i!=`function`&&(yd===null?yd=new Set([this]):yd.add(this));var e=r.stack;this.componentDidCatch(r.value,{componentStack:e===null?``:e})})}function Pc(e,t,n,r,a){if(n.flags|=32768,typeof r==`object`&&r&&typeof r.then==`function`){if(t=n.alternate,t!==null&&Oa(t,n,a,!0),n=Io.current,n!==null){switch(n.tag){case 31:case 13:case 19:return Lo===null?Kd():n.alternate===null&&Y===0&&(Y=3),n.flags&=-257,n.flags|=65536,n.lanes=a,r===ro?n.flags|=16384:(t=n.updateQueue,t===null?n.updateQueue=new Set([r]):t.add(r),mf(e,r,a)),!1;case 22:return n.flags|=65536,r===ro?n.flags|=16384:(t=n.updateQueue,t===null?(t={transitions:null,markerInstances:null,retryQueue:new Set([r])},n.updateQueue=t):(n=t.retryQueue,n===null?t.retryQueue=new Set([r]):n.add(r)),mf(e,r,a)),!1}throw Error(i(435,n.tag))}return mf(e,r,a),Kd(),!1}if(P)return t=Io.current,t===null?(r!==pa&&(t=Error(i(423),{cause:r}),ba(Yi(t,n))),e=e.current.alternate,e.flags|=65536,a&=-a,e.lanes|=a,r=Yi(r,n),a=jc(e.stateNode,r,a),To(e,a),Y!==4&&(Y=2)):(!(t.flags&65536)&&(t.flags|=256),t.flags|=65536,t.lanes=a,r!==pa&&(e=Error(i(422),{cause:r}),ba(Yi(e,n)))),!1;var o=Error(i(520),{cause:r});if(o=Yi(o,n),fd===null?fd=[o]:fd.push(o),Y!==4&&(Y=2),t===null)return!0;r=Yi(r,n),n=t;do{switch(n.tag){case 3:return n.flags|=65536,e=a&-a,n.lanes|=e,e=jc(n.stateNode,r,e),To(n,e),!1;case 1:if(t=n.type,o=n.stateNode,!(n.flags&128)&&(typeof t.getDerivedStateFromError==`function`||o!==null&&typeof o.componentDidCatch==`function`&&(yd===null||!yd.has(o))))return n.flags|=65536,a&=-a,n.lanes|=a,a=Mc(a),Nc(a,e,n,r),To(n,a),!1;break;case 22:if(n.memoizedState!==null)return n.flags|=65536,!1}n=n.return}while(n!==null);return!1}var Fc=Error(i(461)),Ic=!1;function Lc(e,t,n,r){t.child=e===null?vo(t,null,n,r):_o(t,e.child,n,r)}function Rc(e,t,n,r,i){n=n.render;var a=t.ref;if(`ref`in r){var o={};for(var s in r)s!==`ref`&&(o[s]=r[s])}else o=r;return Aa(t),r=ns(e,t,n,o,a,i),s=os(),e!==null&&!Ic?(ss(e,t,i),fl(e,t,i)):(P&&s&&sa(t),t.flags|=1,Lc(e,t,r,i),t.child)}function zc(e,t,n,r,i){if(e===null){var a=n.type;return typeof a==`function`&&!Bi(a)&&a.defaultProps===void 0&&n.compare===null?(t.tag=15,t.type=a,Bc(e,t,a,r,i)):(e=Ui(n.type,null,r,t,t.mode,i),e.ref=t.ref,e.return=t,t.child=e)}if(a=e.child,!pl(e,i)){var o=a.memoizedProps;if(n=n.compare,n=n===null?Yr:n,n(o,r)&&e.ref===t.ref)return fl(e,t,i)}return t.flags|=1,e=Vi(a,r),e.ref=t.ref,e.return=t,t.child=e}function Bc(e,t,n,r,i){if(e!==null){var a=e.memoizedProps;if(Yr(a,r)&&e.ref===t.ref){if(Ic=!1,t.pendingProps=r=a,pl(e,i))e.flags&131072&&(Ic=!0);else return t.lanes=e.lanes,fl(e,t,i)}}return Jc(e,t,n,r,i)}function Vc(e,t,n,r){var i=r.children,a=e===null?null:e.memoizedState;if(e===null&&t.stateNode===null&&(t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),r.mode===`hidden`){if(t.flags&128){if(a=a===null?n:a.baseLanes|n,e!==null){for(r=t.child=e.child,i=0;r!==null;)i=i|r.lanes|r.childLanes,r=r.sibling;r=i&~a}else r=0,t.child=null;return Uc(e,t,a,n,r)}if(n&536870912)t.memoizedState={baseLanes:0,cachePool:null},e!==null&&Qa(t,a===null?null:a.cachePool),a===null?Po():No(t,a),Bo(t);else return r=t.lanes=536870912,Uc(e,t,a===null?n:a.baseLanes|n,n,r)}else a===null?(e!==null&&Qa(t,null),Po(),Vo()):(Qa(t,a.cachePool),No(t,a),Vo(),t.memoizedState=null);return Lc(e,t,i,n),t.child}function Hc(e,t){return e!==null&&e.tag===22||t.stateNode!==null||(t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),t.sibling}function Uc(e,t,n,r,i){var a=Za();return a=a===null?null:{parent:F._currentValue,pool:a},t.memoizedState={baseLanes:n,cachePool:a},e!==null&&Qa(t,null),Po(),Bo(t),e!==null&&Oa(e,t,r,!0),t.childLanes=i,null}function Wc(e,t){return t=rl({mode:t.mode,children:t.children},e.mode),t.ref=e.ref,e.child=t,t.return=e,t}function Gc(e,t,n){return _o(t,e.child,null,n),e=Wc(t,t.pendingProps),e.flags|=2,Ho(t),t.memoizedState=null,e}function Kc(e,t,n){var r=t.pendingProps,a=!!(t.flags&128);if(t.flags&=-129,e===null){if(P){if(r.mode===`hidden`)return e=Wc(t,r),t.lanes=536870912,e.memoizedState={baseLanes:0,cachePool:null},Hc(null,e);if(zo(t),(e=N)?(e=am(e,fa),e=e!==null&&e.data===`&`?e:null,e!==null&&(t.memoizedState={dehydrated:e,treeContext:na===null?null:{id:ra,overflow:ia},retryLane:536870912,hydrationErrors:null},n=Ki(e),n.return=t,t.child=n,ua=t,N=null)):e=null,e===null)throw ma(t);return t.lanes=536870912,null}return Wc(t,r)}var o=e.memoizedState;if(o!==null){var s=o.dehydrated;if(zo(t),a){if(t.flags&256)t.flags&=-257,t=Gc(e,t,n);else if(t.memoizedState!==null)t.child=e.child,t.flags|=128,t=null;else throw Error(i(558))}else if(Ic||Oa(e,t,n,!1),a=(n&e.childLanes)!==0,Ic||a){if(jo.current===null){if(r=G,r!==null&&(s=Et(r,n),s!==0&&s!==o.retryLane))throw o.retryLane=s,Pi(e,s),Pd(r,e,s),Fc;Kd()}t=Gc(e,t,n)}else e=o.treeContext,N=lm(s.nextSibling),ua=t,P=!0,da=null,fa=!1,e!==null&&la(t,e),t=Wc(t,r),t.flags|=134221824;return t}return e=Vi(e.child,{mode:r.mode,children:r.children}),e.ref=t.ref,t.child=e,e.return=t,e}function qc(e,t){var n=t.ref;if(n===null)e!==null&&e.ref!==null&&(t.flags|=4194816);else{if(typeof n!=`function`&&typeof n!=`object`)throw Error(i(284));(e===null||e.ref!==n)&&(t.flags|=4194816)}}function Jc(e,t,n,r,i){return Aa(t),n=ns(e,t,n,r,void 0,i),r=os(),e!==null&&!Ic?(ss(e,t,i),fl(e,t,i)):(P&&r&&sa(t),t.flags|=1,Lc(e,t,n,i),t.child)}function Yc(e,t,n,r,i,a){return Aa(t),t.updateQueue=null,n=is(t,r,n,i),rs(e),r=os(),e!==null&&!Ic?(ss(e,t,a),fl(e,t,a)):(P&&r&&sa(t),t.flags|=1,Lc(e,t,n,a),t.child)}function Xc(e,t,n,r,i){if(Aa(t),t.stateNode===null){var a=Li,o=n.contextType;typeof o==`object`&&o&&(a=ja(o)),a=new n(r,a),t.memoizedState=a.state!==null&&a.state!==void 0?a.state:null,a.updater=Sc,t.stateNode=a,a._reactInternals=t,a=t.stateNode,a.props=r,a.state=t.memoizedState,a.refs={},bo(t),o=n.contextType,a.context=typeof o==`object`&&o?ja(o):Li,a.state=t.memoizedState,o=n.getDerivedStateFromProps,typeof o==`function`&&(xc(t,n,o,r),a.state=t.memoizedState),typeof n.getDerivedStateFromProps==`function`||typeof a.getSnapshotBeforeUpdate==`function`||typeof a.UNSAFE_componentWillMount!=`function`&&typeof a.componentWillMount!=`function`||(o=a.state,typeof a.componentWillMount==`function`&&a.componentWillMount(),typeof a.UNSAFE_componentWillMount==`function`&&a.UNSAFE_componentWillMount(),o!==a.state&&Sc.enqueueReplaceState(a,a.state,null),Oo(t,r,a,i),Do(),a.state=t.memoizedState),typeof a.componentDidMount==`function`&&(t.flags|=4194308),r=!0}else if(e===null){a=t.stateNode;var s=t.memoizedProps,c=Tc(n,s);a.props=c;var l=a.context,u=n.contextType;o=Li,typeof u==`object`&&u&&(o=ja(u));var d=n.getDerivedStateFromProps;u=typeof d==`function`||typeof a.getSnapshotBeforeUpdate==`function`,s=t.pendingProps!==s,u||typeof a.UNSAFE_componentWillReceiveProps!=`function`&&typeof a.componentWillReceiveProps!=`function`||(s||l!==o)&&wc(t,a,r,o),yo=!1;var f=t.memoizedState;a.state=f,Oo(t,r,a,i),Do(),l=t.memoizedState,s||f!==l||yo?(typeof d==`function`&&(xc(t,n,d,r),l=t.memoizedState),(c=yo||Cc(t,n,c,r,f,l,o))?(u||typeof a.UNSAFE_componentWillMount!=`function`&&typeof a.componentWillMount!=`function`||(typeof a.componentWillMount==`function`&&a.componentWillMount(),typeof a.UNSAFE_componentWillMount==`function`&&a.UNSAFE_componentWillMount()),typeof a.componentDidMount==`function`&&(t.flags|=4194308)):(typeof a.componentDidMount==`function`&&(t.flags|=4194308),t.memoizedProps=r,t.memoizedState=l),a.props=r,a.state=l,a.context=o,r=c):(typeof a.componentDidMount==`function`&&(t.flags|=4194308),r=!1)}else{a=t.stateNode,xo(e,t),o=t.memoizedProps,u=Tc(n,o),a.props=u,d=t.pendingProps,f=a.context,l=n.contextType,c=Li,typeof l==`object`&&l&&(c=ja(l)),s=n.getDerivedStateFromProps,(l=typeof s==`function`||typeof a.getSnapshotBeforeUpdate==`function`)||typeof a.UNSAFE_componentWillReceiveProps!=`function`&&typeof a.componentWillReceiveProps!=`function`||(o!==d||f!==c)&&wc(t,a,r,c),yo=!1,f=t.memoizedState,a.state=f,Oo(t,r,a,i),Do();var p=t.memoizedState;o!==d||f!==p||yo||e!==null&&e.dependencies!==null&&ka(e.dependencies)?(typeof s==`function`&&(xc(t,n,s,r),p=t.memoizedState),(u=yo||Cc(t,n,u,r,f,p,c)||e!==null&&e.dependencies!==null&&ka(e.dependencies))?(l||typeof a.UNSAFE_componentWillUpdate!=`function`&&typeof a.componentWillUpdate!=`function`||(typeof a.componentWillUpdate==`function`&&a.componentWillUpdate(r,p,c),typeof a.UNSAFE_componentWillUpdate==`function`&&a.UNSAFE_componentWillUpdate(r,p,c)),typeof a.componentDidUpdate==`function`&&(t.flags|=4),typeof a.getSnapshotBeforeUpdate==`function`&&(t.flags|=1024)):(typeof a.componentDidUpdate!=`function`||o===e.memoizedProps&&f===e.memoizedState||(t.flags|=4),typeof a.getSnapshotBeforeUpdate!=`function`||o===e.memoizedProps&&f===e.memoizedState||(t.flags|=1024),t.memoizedProps=r,t.memoizedState=p),a.props=r,a.state=p,a.context=c,r=u):(typeof a.componentDidUpdate!=`function`||o===e.memoizedProps&&f===e.memoizedState||(t.flags|=4),typeof a.getSnapshotBeforeUpdate!=`function`||o===e.memoizedProps&&f===e.memoizedState||(t.flags|=1024),r=!1)}return a=r,qc(e,t),r=!!(t.flags&128),a||r?(a=t.stateNode,n=r&&typeof n.getDerivedStateFromError!=`function`?null:a.render(),t.flags|=1,e!==null&&r?(t.child=_o(t,e.child,null,i),t.child=_o(t,null,n,i)):Lc(e,t,n,i),t.memoizedState=a.state,e=t.child):e=fl(e,t,i),e}function Zc(e,t,n,r){return va(),t.flags|=256,Lc(e,t,n,r),t.child}var Qc={dehydrated:null,treeContext:null,retryLane:0,hydrationErrors:null};function $c(e){return{baseLanes:e,cachePool:$a()}}function el(e,t,n){return e=e===null?0:e.childLanes&~n,t&&(e|=ud),e}function tl(e,t,n){var r=t.pendingProps,i=!1,a=!!(t.flags&128),o;if((o=a)||(o=e!==null&&e.memoizedState===null?!1:!!(Uo.current&2)),o&&(i=!0,t.flags&=-129),o=!!(t.flags&32),t.flags&=-33,e===null){if(P){if(i?Ro(t):Vo(),(e=N)?(e=am(e,fa),e=e!==null&&e.data!==`&`?e:null,e!==null&&(t.memoizedState={dehydrated:e,treeContext:na===null?null:{id:ra,overflow:ia},retryLane:536870912,hydrationErrors:null},n=Ki(e),n.return=t,t.child=n,ua=t,N=null)):e=null,e===null)throw ma(t);return t.lanes=sm(e)?32:536870912,null}return a=r.children,r=r.fallback,i?(Vo(),i=t.mode,a=rl({mode:`hidden`,children:a},i),r=Wi(r,i,n,null),a.return=t,r.return=t,a.sibling=r,t.child=a,r=t.child,r.memoizedState=$c(n),r.childLanes=el(e,o,n),t.memoizedState=Qc,Hc(null,r)):(Ro(t),nl(t,a))}var s=e.memoizedState;if(s!==null){var c=s.dehydrated;if(c!==null)return al(e,t,a,o,r,c,s,n)}return i?(Vo(),i=r.fallback,a=t.mode,s=e.child,c=s.sibling,r=Vi(s,{mode:`hidden`,children:r.children}),r.subtreeFlags=s.subtreeFlags&1206910976,c===null?(i=Wi(i,a,n,null),i.flags|=2):i=Vi(c,i),i.return=t,r.return=t,r.sibling=i,t.child=r,Hc(null,r),r=t.child,i=e.child.memoizedState,i===null?i=$c(n):(a=i.cachePool,a===null?a=$a():(s=F._currentValue,a=a.parent===s?a:{parent:s,pool:s}),i={baseLanes:i.baseLanes|n,cachePool:a}),r.memoizedState=i,r.childLanes=el(e,o,n),t.memoizedState=Qc,Hc(e.child,r)):(Ro(t),n=e.child,e=n.sibling,n=Vi(n,{mode:`visible`,children:r.children}),n.return=t,n.sibling=null,e!==null&&(o=t.deletions,o===null?(t.deletions=[e],t.flags|=16):o.push(e)),t.child=n,t.memoizedState=null,n)}function nl(e,t){return t=rl({mode:`visible`,children:t},e.mode),t.return=e,e.child=t}function rl(e,t){return e=zi(22,e,null,t),e.lanes=0,e}function il(e,t,n){return _o(t,e.child,null,n),e=nl(t,t.pendingProps.children),e.flags|=2,t.memoizedState=null,e}function al(e,t,n,r,a,o,s,c){if(n)return t.flags&256?(Ro(t),t.flags&=-257,il(e,t,c)):t.memoizedState===null?(Vo(),o=a.fallback,s=t.mode,a=rl({mode:`visible`,children:a.children},s),o=Wi(o,s,c,null),o.flags|=2,a.return=t,o.return=t,a.sibling=o,t.child=a,_o(t,e.child,null,c),a=t.child,a.memoizedState=$c(c),a.childLanes=el(e,r,c),t.memoizedState=Qc,Hc(null,a)):(Vo(),t.child=e.child,t.flags|=128,null);if(Ro(t),sm(o)){if(r=o.nextSibling&&o.nextSibling.dataset,r)var l=r.dgst;return r=l,r!==``&&(a=Error(i(419)),a.stack=``,a.digest=r,ba({value:a,source:null,stack:null})),il(e,t,c)}if(Ic||Oa(e,t,c,!1),r=(c&e.childLanes)!==0,Ic||r){if(jo.current!==null)return il(e,t,c);if(r=G,r!==null&&(a=Et(r,c),a!==0&&a!==s.retryLane))throw s.retryLane=a,Pi(e,a),Pd(r,e,a),Fc;return om(o)||Kd(),il(e,t,c)}return om(o)?(t.flags|=192,t.child=e.child,null):(e=s.treeContext,N=lm(o.nextSibling),ua=t,P=!0,da=null,fa=!1,e!==null&&la(t,e),t=nl(t,a.children),t.flags|=134221824,t)}function ol(e,t,n){e.lanes|=t;var r=e.alternate;r!==null&&(r.lanes|=t),Ea(e.return,t,n)}function sl(e){for(var t=null;e!==null;){var n=e.alternate;n!==null&&Ko(n)===null&&(t=e),e=e.sibling}return t}function cl(e,t,n,r,i,a){var o=e.memoizedState;o===null?e.memoizedState={isBackwards:t,rendering:null,renderingStartTime:0,last:r,tail:n,tailMode:i,treeForkCount:a}:(o.isBackwards=t,o.rendering=null,o.renderingStartTime=0,o.last=r,o.tail=n,o.tailMode=i,o.treeForkCount=a)}function ll(e){var t=e.child;for(e.child=null;t!==null;){var n=t.sibling;t.sibling=e.child,e.child=t,t=n}}function ul(e,t,n){var r=t.pendingProps,i=r.revealOrder,a=r.tail;r=r.children;var o=Uo.current;if(t.flags&128)return Wo(t,o),null;var s=!!(o&2);if(s?(o=o&1|2,t.flags|=128):o&=1,Wo(t,o),i===`backwards`&&e!==null?(ll(e),Lc(e,t,r,n),ll(e)):Lc(e,t,r,n),r=P?$i:0,!s&&e!==null&&e.flags&128)a:for(e=t.child;e!==null;){if(e.tag===13)e.memoizedState!==null&&ol(e,n,t);else if(e.tag===19)ol(e,n,t);else if(e.child!==null){e.child.return=e,e=e.child;continue}if(e===t)break a;for(;e.sibling===null;){if(e.return===null||e.return===t)break a;e=e.return}e.sibling.return=e.return,e=e.sibling}switch(i){case`backwards`:n=sl(t.child),n===null?(i=t.child,t.child=null):(i=n.sibling,n.sibling=null,ll(t)),cl(t,!0,i,null,a,r);break;case`unstable_legacy-backwards`:for(n=null,i=t.child,t.child=null;i!==null;){if(e=i.alternate,e!==null&&Ko(e)===null){t.child=i;break}e=i.sibling,i.sibling=n,n=i,i=e}cl(t,!0,n,null,a,r);break;case`together`:cl(t,!1,null,null,void 0,r);break;case`independent`:t.memoizedState=null;break;default:n=sl(t.child),n===null?(i=t.child,t.child=null):(i=n.sibling,n.sibling=null),cl(t,!1,i,n,a,r)}return t.child}function dl(e,t,n){var r=t.pendingProps;return wa(t,t.type,r.value),Lc(e,t,r.children,n),t.child}function fl(e,t,n){if(e!==null&&(t.dependencies=e.dependencies),sd|=t.lanes,(n&t.childLanes)===0){if(e!==null){if(Oa(e,t,n,!1),(n&t.childLanes)===0)return null}else return null}if(e!==null&&t.child!==e.child)throw Error(i(153));if(t.child!==null){for(e=t.child,n=Vi(e,e.pendingProps),t.child=n,n.return=t;e.sibling!==null;)e=e.sibling,n=n.sibling=Vi(e,e.pendingProps),n.return=t;n.sibling=null}return t.child}function pl(e,t){return(e.lanes&t)!==0||(e=e.dependencies,!!(e!==null&&ka(e)))}function ml(e,t,n){switch(t.tag){case 3:Pe(t,t.stateNode.containerInfo),wa(t,F,e.memoizedState.cache),va();break;case 27:case 5:Ie(t);break;case 4:Pe(t,t.stateNode.containerInfo);break;case 10:wa(t,t.type,t.memoizedProps.value);break;case 31:if(t.memoizedState!==null)return t.flags|=128,zo(t),null;break;case 13:var r=t.memoizedState;if(r!==null){if(r.dehydrated!==null)return Ro(t),t.flags|=128,null;r=Oa(e,t,n,!1);var i=t.child.childLanes;return r||(n&i)!==0?tl(e,t,n):(Ro(t),e=fl(e,t,n),e===null?null:e.sibling)}Ro(t);break;case 19:if(t.flags&128)return ul(e,t,n);if(i=!!(e.flags&128),r=(n&t.childLanes)!==0,r||=(Oa(e,t,n,!1),(n&t.childLanes)!==0),i){if(r)return ul(e,t,n);t.flags|=128}if(i=t.memoizedState,i!==null&&(i.rendering=null,i.tail=null,i.lastEffect=null),Wo(t,Uo.current),r)break;return null;case 22:return t.lanes=0,Vc(e,t,n,t.pendingProps);case 24:wa(t,F,e.memoizedState.cache)}return fl(e,t,n)}function hl(e,t,n){if(e!==null){if(e.memoizedProps!==t.pendingProps)Ic=!0;else{if(!pl(e,n)&&!(t.flags&128))return Ic=!1,ml(e,t,n);Ic=!!(e.flags&131072)}}else Ic=!1,P&&t.flags&1048576&&oa(t,$i,t.index);switch(t.lanes=0,t.tag){case 16:a:{var r=t.pendingProps;if(e=oo(t.elementType),t.type=e,typeof e==`function`)Bi(e)?(r=Tc(e,r),t.tag=1,t=Xc(null,t,e,r,n)):(t.tag=0,t=Jc(null,t,e,r,n));else{if(e!=null){var a=e.$$typeof;if(a===ue){t.tag=11,t=Rc(null,t,e,r,n);break a}if(a===pe){t.tag=14,t=zc(null,t,e,r,n);break a}if(a===T){t.tag=10,t.type=e,t=dl(null,t,n);break a}}throw t=Ce(e)||e,Error(i(306,t,``))}}return t;case 0:return Jc(e,t,t.type,t.pendingProps,n);case 1:return r=t.type,a=Tc(r,t.pendingProps),Xc(e,t,r,a,n);case 3:a:{if(Pe(t,t.stateNode.containerInfo),e===null)throw Error(i(387));r=t.pendingProps;var o=t.memoizedState;a=o.element,xo(e,t),Oo(t,r,null,n);var s=t.memoizedState;if(r=s.cache,wa(t,F,r),r!==o.cache&&Da(t,[F],n,!0),Do(),r=s.element,o.isDehydrated){if(o={element:r,isDehydrated:!1,cache:s.cache},t.updateQueue.baseState=o,t.memoizedState=o,t.flags&256){t=Zc(e,t,r,n);break a}if(r!==a){a=Yi(Error(i(424)),t),ba(a),t=Zc(e,t,r,n);break a}switch(e=t.stateNode.containerInfo,e.nodeType){case 9:e=e.body;break;default:e=e.nodeName===`HTML`?e.ownerDocument.body:e}for(N=lm(e.firstChild),ua=t,P=!0,da=null,fa=!0,n=vo(t,null,r,n),t.child=n;n;)n.flags=n.flags&-3|134221824,n=n.sibling}else{if(va(),r===a){t=fl(e,t,n);break a}Lc(e,t,r,n)}t=t.child}return t;case 26:return qc(e,t),e===null?(n=Nm(t.type,null,t.pendingProps,null))?t.memoizedState=n:P||(t.stateNode=fp(t.type,t.pendingProps,Me.current,t)):t.memoizedState=Nm(t.type,e.memoizedProps,t.pendingProps,e.memoizedState),null;case 27:return Ie(t),e===null&&P&&(r=t.stateNode=hm(t.type,t.pendingProps,Me.current),ua=t,fa=!0,a=N,Sp(t.type)?(um=a,N=lm(r.firstChild)):N=a),Lc(e,t,t.pendingProps.children,n),qc(e,t),e===null&&(t.flags|=4194304),t.child;case 5:return e===null&&P&&((a=r=N)&&(r=rm(r,t.type,t.pendingProps,fa),r===null?a=!1:(t.stateNode=r,ua=t,N=lm(r.firstChild),fa=!1,a=!0)),a||ma(t)),Ie(t),a=t.type,o=t.pendingProps,s=e===null?null:e.memoizedProps,r=o.children,pp(a,o)?r=null:s!==null&&pp(a,s)&&(t.flags|=32),t.memoizedState!==null&&(a=ns(e,t,as,null,null,n),sh._currentValue=a),qc(e,t),Lc(e,t,r,n),t.child;case 6:return e===null&&P&&((e=n=N)&&(n=im(n,t.pendingProps,fa),n===null?e=!1:(t.stateNode=n,ua=t,N=null,e=!0)),e||ma(t)),null;case 13:return tl(e,t,n);case 4:return Pe(t,t.stateNode.containerInfo),r=t.pendingProps,e===null?t.child=_o(t,null,r,n):Lc(e,t,r,n),t.child;case 11:return Rc(e,t,t.type,t.pendingProps,n);case 7:return r=t.pendingProps,qc(e,t),Lc(e,t,r,n),t.child;case 8:return Lc(e,t,t.pendingProps.children,n),t.child;case 12:return Lc(e,t,t.pendingProps.children,n),t.child;case 10:return dl(e,t,n);case 9:return a=t.type._context,r=t.pendingProps.children,Aa(t),a=ja(a),r=r(a),t.flags|=1,Lc(e,t,r,n),t.child;case 14:return zc(e,t,t.type,t.pendingProps,n);case 15:return Bc(e,t,t.type,t.pendingProps,n);case 19:return ul(e,t,n);case 31:return Kc(e,t,n);case 22:return Vc(e,t,n,t.pendingProps);case 24:return Aa(t),r=ja(F),e===null?(a=Za(),a===null&&(a=G,o=La(),a.pooledCache=o,o.refCount++,o!==null&&(a.pooledCacheLanes|=n),a=o),t.memoizedState={parent:r,cache:a},bo(t),wa(t,F,a)):((e.lanes&n)!==0&&(xo(e,t),Oo(t,null,null,n),Do()),a=e.memoizedState,o=t.memoizedState,a.parent===r?(r=o.cache,wa(t,F,r),r!==a.cache&&Da(t,[F],n,!0)):(a={parent:r,cache:r},t.memoizedState=a,t.lanes===0&&(t.memoizedState=t.updateQueue.baseState=a),wa(t,F,r))),Lc(e,t,t.pendingProps.children,n),t.child;case 30:return t.stateNode===null&&(t.stateNode={autoName:null,paired:null,clones:null,ref:null}),r=t.pendingProps,r.name!=null&&r.name!==`auto`?t.flags|=e===null?18882560:18874368:P&&sa(t),e!==null&&e.memoizedProps.name!==r.name?t.flags|=4194816:qc(e,t),Lc(e,t,r.children,n),t.child;case 29:throw t.pendingProps}throw Error(i(156,t.tag))}function gl(e){e.flags|=4}function _l(e,t,n,r,i){var a;if((a=!!(e.mode&32))&&(a=n===null?Jm(t,r):Jm(t,r)&&(r.src!==n.src||r.srcSet!==n.srcSet)),a){if(e.flags|=16777216,(i&335544128)===i){if(e.stateNode.complete)e.flags|=8192;else if(Ud())e.flags|=8192;else throw so=ro,to}}else e.flags&=-16777217}function vl(e,t){if(t.type!==`stylesheet`||t.state.loading&4)e.flags&=-16777217;else if(e.flags|=16777216,!Ym(t)){if(Ud())e.flags|=8192;else throw so=ro,to}}function yl(e,t){t!==null&&(e.flags|=4),e.flags&16384&&(t=e.tag===22?536870912:bt(),e.lanes|=t,dd|=t)}function bl(e,t){if(!P)switch(e.tailMode){case`visible`:break;case`collapsed`:for(var n=e.tail,r=null;n!==null;)n.alternate!==null&&(r=n),n=n.sibling;r===null?t||e.tail===null?e.tail=null:e.tail.sibling=null:r.sibling=null;break;default:for(t=e.tail,n=null;t!==null;)t.alternate!==null&&(n=t),t=t.sibling;n===null?e.tail=null:n.sibling=null}}function V(e){var t=e.alternate!==null&&e.alternate.child===e.child,n=0,r=0;if(t)for(var i=e.child;i!==null;)n|=i.lanes|i.childLanes,r|=i.subtreeFlags&1206910976,r|=i.flags&1206910976,i.return=e,i=i.sibling;else for(i=e.child;i!==null;)n|=i.lanes|i.childLanes,r|=i.subtreeFlags,r|=i.flags,i.return=e,i=i.sibling;return e.subtreeFlags|=r,e.childLanes=n,t}function xl(e,t,n){var r=t.pendingProps;switch(ca(t),t.tag){case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return V(t),null;case 1:return V(t),null;case 3:return n=t.stateNode,r=null,e!==null&&(r=e.memoizedState.cache),t.memoizedState.cache!==r&&(t.flags|=2048),Ta(F),Fe(),n.pendingContext&&(n.context=n.pendingContext,n.pendingContext=null),(e===null||e.child===null)&&(_a(t)?gl(t):e===null||e.memoizedState.isDehydrated&&!(t.flags&256)||(t.flags|=1024,ya())),V(t),null;case 26:var a=t.type,o=t.memoizedState;return e===null?(gl(t),o===null?(V(t),_l(t,a,null,r,n)):(V(t),vl(t,o))):o?o===e.memoizedState?(V(t),t.flags&=-16777217):(gl(t),V(t),vl(t,o)):(e=e.memoizedProps,e!==r&&gl(t),V(t),_l(t,a,e,r,n)),null;case 27:if(Le(t),n=Me.current,a=t.type,e!==null&&t.stateNode!=null)e.memoizedProps!==r&&gl(t);else{if(!r){if(t.stateNode===null)throw Error(i(166));return V(t),t.subtreeFlags&=-33554433,null}e=Ae.current,_a(t)?ha(t,e):(e=hm(a,r,n),t.stateNode=e,gl(t))}return V(t),t.subtreeFlags&=-33554433,null;case 5:if(Le(t),a=t.type,e!==null&&t.stateNode!=null)e.memoizedProps!==r&&gl(t);else{if(!r){if(t.stateNode===null)throw Error(i(166));return V(t),t.subtreeFlags&=-33554433,null}if(o=Ae.current,_a(t))ha(t,o);else{var s=lp(Me.current);switch(o){case 1:o=s.createElementNS(`http://www.w3.org/2000/svg`,a);break;case 2:o=s.createElementNS(`http://www.w3.org/1998/Math/MathML`,a);break;default:switch(a){case`svg`:o=s.createElementNS(`http://www.w3.org/2000/svg`,a);break;case`math`:o=s.createElementNS(`http://www.w3.org/1998/Math/MathML`,a);break;case`script`:o=s.createElement(`div`),o.innerHTML=`<script><\/script>`,o=o.removeChild(o.firstChild);break;case`select`:o=typeof r.is==`string`?s.createElement(`select`,{is:r.is}):s.createElement(`select`),r.multiple?o.multiple=!0:r.size&&(o.size=r.size);break;default:o=typeof r.is==`string`?s.createElement(a,{is:r.is}):s.createElement(a)}}o[Mt]=t,o[Nt]=r;a:for(s=t.child;s!==null;){if(s.tag===5||s.tag===6)o.appendChild(s.stateNode);else if(s.tag!==4&&s.tag!==27&&s.child!==null){s.child.return=s,s=s.child;continue}if(s===t)break a;for(;s.sibling===null;){if(s.return===null||s.return===t)break a;s=s.return}s.sibling.return=s.return,s=s.sibling}t.stateNode=o;a:switch(np(o,a,r),a){case`button`:case`input`:case`select`:case`textarea`:r=!!r.autoFocus;break a;case`img`:r=!0;break a;default:r=!1}r&&gl(t)}}return V(t),t.subtreeFlags&=-33554433,_l(t,t.type,e===null?null:e.memoizedProps,t.pendingProps,n),null;case 6:if(e&&t.stateNode!=null)e.memoizedProps!==r&&gl(t);else{if(typeof r!=`string`&&t.stateNode===null)throw Error(i(166));if(e=Me.current,_a(t)){if(e=t.stateNode,n=t.memoizedProps,r=null,a=ua,a!==null)switch(a.tag){case 27:case 5:r=a.memoizedProps}e[Mt]=t,e=!!(e.nodeValue===n||r!==null&&!0===r.suppressHydrationWarning||ep(e.nodeValue,n)),e||ma(t,!0)}else e=lp(e).createTextNode(r),e[Mt]=t,t.stateNode=e}return V(t),null;case 31:if(n=t.memoizedState,e===null||e.memoizedState!==null){if(r=_a(t),n!==null){if(e===null){if(!r)throw Error(i(318));if(e=t.memoizedState,e=e===null?null:e.dehydrated,!e)throw Error(i(557));e[Mt]=t}else va(),!(t.flags&128)&&(t.memoizedState=null),t.flags|=4;V(t),e=!1}else n=ya(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=n),e=!0;if(!e)return t.flags&256?(Ho(t),t):(Ho(t),null);if(t.flags&128)throw Error(i(558))}return V(t),null;case 13:if(r=t.memoizedState,e===null||e.memoizedState!==null&&e.memoizedState.dehydrated!==null){if(a=_a(t),r!==null&&r.dehydrated!==null){if(e===null){if(!a)throw Error(i(318));if(a=t.memoizedState,a=a===null?null:a.dehydrated,!a)throw Error(i(317));a[Mt]=t}else va(),!(t.flags&128)&&(t.memoizedState=null),t.flags|=4;V(t),a=!1}else a=ya(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=a),a=!0;if(!a)return t.flags&256?(Ho(t),t):(Ho(t),null)}return Ho(t),t.flags&128?(t.lanes=n,t):(n=r!==null,e=e!==null&&e.memoizedState!==null,n&&(r=t.child,a=null,r.alternate!==null&&r.alternate.memoizedState!==null&&r.alternate.memoizedState.cachePool!==null&&(a=r.alternate.memoizedState.cachePool.pool),o=null,r.memoizedState!==null&&r.memoizedState.cachePool!==null&&(o=r.memoizedState.cachePool.pool),o!==a&&(r.flags|=2048)),n!==e&&n&&(t.child.flags|=8192),yl(t,t.updateQueue),V(t),null);case 4:return Fe(),e===null&&Wf(t.stateNode.containerInfo),t.flags|=67108864,V(t),null;case 10:return Ta(t.type),V(t),null;case 19:if(Go(t),r=t.memoizedState,r===null)return V(t),null;if(a=!!(t.flags&128),o=r.rendering,o===null){if(a)bl(r,!1);else{if(Y!==0||e!==null&&e.flags&128)for(e=t.child;e!==null;){if(o=Ko(e),o!==null){for(t.flags|=128,bl(r,!1),e=o.updateQueue,t.updateQueue=e,yl(t,e),t.subtreeFlags=0,e=n,n=t.child;n!==null;)Hi(n,e),n=n.sibling;return Wo(t,Uo.current&1|2),P&&aa(t,r.treeForkCount),t.child}e=e.sibling}r.tail!==null&&Xe()>_d&&(t.flags|=128,a=!0,bl(r,!1),t.lanes=4194304)}}else{if(!a){if(e=Ko(o),e!==null){if(t.flags|=128,a=!0,e=e.updateQueue,t.updateQueue=e,yl(t,e),bl(r,!0),r.tail===null&&r.tailMode!==`collapsed`&&r.tailMode!==`visible`&&!o.alternate&&!P)return V(t),null}else 2*Xe()-r.renderingStartTime>_d&&n!==536870912&&(t.flags|=128,a=!0,bl(r,!1),t.lanes=4194304)}r.isBackwards?(o.sibling=t.child,t.child=o):(e=r.last,e===null?t.child=o:e.sibling=o,r.last=o)}if(r.tail!==null){e=r.tail;a:{for(n=e;n!==null;){if(n.alternate!==null){n=!1;break a}n=n.sibling}n=!0}return r.rendering=e,r.tail=e.sibling,r.renderingStartTime=Xe(),e.sibling=null,o=Uo.current,o=a?o&1|2:o&1,r.tailMode===`visible`||r.tailMode===`collapsed`||!n||P?Wo(t,o):(n=o,O(Io,t),O(Uo,n),Lo===null&&(Lo=t)),P&&aa(t,r.treeForkCount),e}return V(t),null;case 22:case 23:return Ho(t),Fo(),r=t.memoizedState!==null,e===null?r&&(t.flags|=8192):e.memoizedState!==null!==r&&(t.flags|=8192),r?n&536870912&&!(t.flags&128)&&(V(t),t.subtreeFlags&6&&(t.flags|=8192)):V(t),n=t.updateQueue,n!==null&&yl(t,n.retryQueue),n=null,e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(n=e.memoizedState.cachePool.pool),r=null,t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(r=t.memoizedState.cachePool.pool),r!==n&&(t.flags|=2048),e!==null&&ke(Xa),null;case 24:return n=null,e!==null&&(n=e.memoizedState.cache),t.memoizedState.cache!==n&&(t.flags|=2048),Ta(F),V(t),null;case 25:return null;case 30:return t.flags|=33554432,V(t),null}throw Error(i(156,t.tag))}function Sl(e,t){switch(ca(t),t.tag){case 1:return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 3:return Ta(F),Fe(),e=t.flags,e&65536&&!(e&128)?(t.flags=e&-65537|128,t):null;case 26:case 27:case 5:return Le(t),null;case 31:if(t.memoizedState!==null){if(Ho(t),t.alternate===null)throw Error(i(340));va()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 13:if(Ho(t),e=t.memoizedState,e!==null&&e.dehydrated!==null){if(t.alternate===null)throw Error(i(340));va()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 19:return Go(t),e=t.flags,e&65536?(t.flags=e&-65537|128,e=t.memoizedState,e!==null&&(e.rendering=null,e.tail=null),t.flags|=4,t):null;case 4:return Fe(),null;case 10:return Ta(t.type),null;case 22:case 23:return Ho(t),Fo(),e!==null&&ke(Xa),e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 24:return Ta(F),null;case 25:return null;default:return null}}function Cl(e,t){switch(ca(t),t.tag){case 3:Ta(F),Fe();break;case 26:case 27:case 5:Le(t);break;case 4:Fe();break;case 31:t.memoizedState!==null&&Ho(t);break;case 13:Ho(t);break;case 19:Go(t);break;case 10:Ta(t.type);break;case 22:case 23:Ho(t),Fo(),e!==null&&ke(Xa);break;case 24:Ta(F)}}function wl(e,t){try{var n=t.updateQueue,r=n===null?null:n.lastEffect;if(r!==null){var i=r.next;n=i;do{if((n.tag&e)===e){r=void 0;var a=n.create,o=n.inst;r=a(),o.destroy=r}n=n.next}while(n!==i)}}catch(e){Z(t,t.return,e)}}function Tl(e,t,n){try{var r=t.updateQueue,i=r===null?null:r.lastEffect;if(i!==null){var a=i.next;r=a;do{if((r.tag&e)===e){var o=r.inst,s=o.destroy;if(s!==void 0){o.destroy=void 0,i=t;var c=n,l=s;try{l()}catch(e){Z(i,c,e)}}}r=r.next}while(r!==a)}}catch(e){Z(t,t.return,e)}}function El(e){var t=e.updateQueue;if(t!==null){var n=e.stateNode;try{Ao(t,n)}catch(t){Z(e,e.return,t)}}}function Dl(e,t,n){n.props=Tc(e.type,e.memoizedProps),n.state=e.memoizedState;try{n.componentWillUnmount()}catch(n){Z(e,t,n)}}function Ol(e,t){try{var n=e.ref;if(n!==null){switch(e.tag){case 26:case 27:case 5:var r=e.stateNode;break;case 30:var i=e.stateNode,a=wi(e.memoizedProps,i);(i.ref===null||i.ref.name!==a)&&(i.ref=Pp(a)),r=i.ref;break;case 7:if(e.stateNode===null){var o=new Fp(e);h(e.child,!1,Qp,o,void 0,void 0),e.stateNode=o}r=e.stateNode;break;default:r=e.stateNode}typeof n==`function`?e.refCleanup=n(r):n.current=r}}catch(n){Z(e,t,n)}}function kl(e,t){var n=e.ref,r=e.refCleanup;if(n!==null){if(typeof r==`function`)try{r()}catch(n){Z(e,t,n)}finally{e.refCleanup=null,e=e.alternate,e!=null&&(e.refCleanup=null)}else if(typeof n==`function`)try{n(null)}catch(n){Z(e,t,n)}else n.current=null}}function Al(e,t){if((e.tag===5||e.tag===27||e.tag===6)&&e.alternate===null&&t!==null)for(var n=0;n<t.length;n++)em(e.stateNode,t[n])}function jl(e){for(var t=e.return;t!==null&&(Pl(t)&&em(e.stateNode,t.stateNode),!Nl(t));)t=t.return}function Ml(e){for(var t=e.return;t!==null&&(Pl(t)&&tm(e.stateNode,t.stateNode),!Nl(t));)t=t.return}function Nl(e){return e.tag===5||e.tag===3||e.tag===27}function Pl(e){return e&&e.tag===7&&e.stateNode!==null}function Fl(e){var t=e.type,n=e.memoizedProps,r=e.stateNode;try{a:switch(t){case`button`:case`input`:case`select`:case`textarea`:n.autoFocus&&r.focus();break a;case`img`:n.src?r.src=n.src:n.srcSet&&(r.srcset=n.srcSet)}}catch(t){Z(e,e.return,t)}}function Il(e,t,n){try{var r=e.stateNode;ip(r,e.type,n,t),r[Nt]=t}catch(t){Z(e,e.return,t)}}function Ll(e){return e.tag===5||e.tag===3||e.tag===26||e.tag===27&&Sp(e.type)||e.tag===4}function Rl(e){a:for(;;){for(;e.sibling===null;){if(e.return===null||Ll(e.return))return null;e=e.return}for(e.sibling.return=e.return,e=e.sibling;e.tag!==5&&e.tag!==6&&e.tag!==18;){if(e.tag===27&&Sp(e.type)||e.flags&2||e.child===null||e.tag===4)continue a;e.child.return=e,e=e.child}if(!(e.flags&2))return e.stateNode}}function zl(e,t,n,r){var i=e.tag;if(i===5||i===6)i=e.stateNode,t?(n.nodeType===9?n.body:n.nodeName===`HTML`?n.ownerDocument.body:n).insertBefore(i,t):(t=n.nodeType===9?n.body:n.nodeName===`HTML`?n.ownerDocument.body:n,t.appendChild(i),n=n._reactRootContainer,n!=null||t.onclick!==null||(t.onclick=Dn)),Al(e,r),A=!0;else if(i!==4&&(i===27&&(Al(e,r),r=null,Sp(e.type)&&(n=e.stateNode,t=null)),e=e.child,e!==null))for(zl(e,t,n,r),e=e.sibling;e!==null;)zl(e,t,n,r),e=e.sibling}function Bl(e,t,n,r){var i=e.tag;if(i===5||i===6)i=e.stateNode,t?n.insertBefore(i,t):n.appendChild(i),Al(e,r),A=!0;else if(i!==4&&(i===27&&(Al(e,r),r=null,Sp(e.type)&&(n=e.stateNode)),e=e.child,e!==null))for(Bl(e,t,n,r),e=e.sibling;e!==null;)Bl(e,t,n,r),e=e.sibling}function Vl(e){var t=e.stateNode,n=e.memoizedProps;try{for(var r=e.type,i=t.attributes;i.length;)t.removeAttributeNode(i[0]);np(t,r,n),t[Mt]=e,t[Nt]=n}catch(t){Z(e,e.return,t)}}var Hl=!1,Ul=null;function Wl(e){(e.tag===30||e.subtreeFlags&33554432)&&(Hl=!0)}var Gl=null;function Kl(){var e=Gl;return Gl=null,e}var ql=0;function Jl(e,t,n,r,i){return ql=0,Yl(e.child,t,n,r,i)}function Yl(e,t,n,r,i){for(var a=!1;e!==null;){if(e.tag===5){var o=e.stateNode;if(r!==null){var s=Op(o);r.push(s),s.view&&(a=!0)}else a||Op(o).view&&(a=!0);Hl=!0,Tp(o,ql===0?t:t+`_`+ql,n),ql++}else(e.tag!==22||e.memoizedState===null)&&(e.tag===30&&i||Yl(e.child,t,n,r,i)&&(a=!0));e=e.sibling}return a}function Xl(e,t){for(;e!==null;)e.tag===5?Ep(e.stateNode,e.memoizedProps):(e.tag!==22||e.memoizedState===null)&&(e.tag===30&&t||Xl(e.child,t)),e=e.sibling}function Zl(e){if(e.subtreeFlags&18874368)for(e=e.child;e!==null;){if((e.tag!==22||e.memoizedState===null)&&(Zl(e),e.tag===30&&e.flags&18874368&&e.stateNode.paired)){var t=e.memoizedProps;if(t.name==null||t.name===`auto`)throw Error(i(544));var n=t.name;t=Ei(t.default,t.share),t!==`none`&&(Jl(e,n,t,null,!1)||Xl(e.child,!1))}e=e.sibling}}function Ql(e,t){if(e.tag===30){var n=e.stateNode,r=e.memoizedProps,i=wi(r,n),a=Ei(r.default,n.paired?r.share:r.enter);a===`none`?Zl(e):Jl(e,i,a,null,!1)?(Zl(e),n.paired||t||Nd(e,r.onEnter)):Xl(e.child,!1)}else if(e.subtreeFlags&33554432)for(e=e.child;e!==null;)Ql(e,t),e=e.sibling;else Zl(e)}function $l(e){if(Ul!==null&&Ul.size!==0){var t=Ul;if(e.subtreeFlags&18874368)for(e=e.child;e!==null;){if(e.tag!==22||e.memoizedState===null){if(e.tag===30&&e.flags&18874368){var n=e.memoizedProps,r=n.name;if(r!=null&&r!==`auto`){var i=t.get(r);if(i!==void 0){var a=Ei(n.default,n.share);if(a!==`none`&&(Jl(e,r,a,null,!1)?(a=e.stateNode,i.paired=a,a.paired=i,Nd(e,n.onShare)):Xl(e.child,!1)),t.delete(r),t.size===0)break}}}$l(e)}e=e.sibling}}}function eu(e){if(e.tag===30){var t=e.memoizedProps,n=wi(t,e.stateNode),r=Ul===null?void 0:Ul.get(n),i=Ei(t.default,r===void 0?t.exit:t.share);i!==`none`&&(Jl(e,n,i,null,!1)?r===void 0?Nd(e,t.onExit):(i=e.stateNode,r.paired=i,i.paired=r,Ul.delete(n),Nd(e,t.onShare)):Xl(e.child,!1)),Ul!==null&&$l(e)}else if(e.subtreeFlags&33554432)for(e=e.child;e!==null;)eu(e),e=e.sibling;else Ul!==null&&$l(e)}function tu(e){for(e=e.child;e!==null;){if(e.tag===30){var t=e.memoizedProps,n=wi(t,e.stateNode);t=Ei(t.default,t.update),e.flags&=-5,t!==`none`&&Jl(e,n,t,e.memoizedState=[],!1)}else e.subtreeFlags&33554432&&tu(e);e=e.sibling}}function nu(e){if(e.subtreeFlags&18874368)for(e=e.child;e!==null;){if(e.tag!==22||e.memoizedState===null){if(e.tag===30&&e.flags&18874368){var t=e.stateNode;t.paired!==null&&(t.paired=null,Xl(e.child,!1))}nu(e)}e=e.sibling}}function ru(e){if(e.tag===30)e.stateNode.paired=null,Xl(e.child,!1),nu(e);else if(e.subtreeFlags&33554432)for(e=e.child;e!==null;)ru(e),e=e.sibling;else nu(e)}function iu(e){for(e=e.child;e!==null;)e.tag===30?Xl(e.child,!1):e.subtreeFlags&33554432&&iu(e),e=e.sibling}function au(e,t,n,r,i,a,o){for(var s=!1;t!==null;){if(t.tag===5){var c=t.stateNode;if(a!==null&&ql<a.length){var l=a[ql],u=Op(c);(l.view||u.view)&&(s=!0);var d;if(d=!(e.flags&4)){if(u.clip)d=!0;else{d=l.rect;var f=u.rect;d=d.y!==f.y||d.x!==f.x||d.height!==f.height||d.width!==f.width}}d&&(e.flags|=4),u.abs?u=!l.abs:(l=l.rect,u=u.rect,u=l.height!==u.height||l.width!==u.width),u&&(e.flags|=32)}else e.flags|=32;e.flags&4&&Tp(c,ql===0?n:n+`_`+ql,i),s&&e.flags&4||(Gl===null&&(Gl=[]),Gl.push(c,ql===0?r:r+`_`+ql,t.memoizedProps)),ql++}else(t.tag!==22||t.memoizedState===null)&&(t.tag===30&&o?e.flags|=t.flags&32:au(e,t.child,n,r,i,a,o)&&(s=!0));t=t.sibling}return s}function ou(e,t){for(e=e.child;e!==null;){if(e.tag===30){var n=e.memoizedProps,r=e.stateNode,i=wi(n,r),a=Ei(n.default,n.update);if(t){r=r.clones;var o=r===null?null:r.map(kp)}else o=e.memoizedState,e.memoizedState=null;r=e;var s=e.child;ql=0,i=au(r,s,i,i,a,o,!1),e.flags&4&&i&&(t||Nd(e,n.onUpdate))}else e.subtreeFlags&33554432&&ou(e,t);e=e.sibling}}var su=!1,H=!1,cu=!1,lu=!1,uu=typeof WeakSet==`function`?WeakSet:Set,du=null,fu=!1,pu=!1,mu=!1,hu=!1;function gu(e,t,n){if(e=e.containerInfo,sp=gh,e=ei(e),ti(e)){if(`selectionStart`in e)var r={start:e.selectionStart,end:e.selectionEnd};else a:{r=(r=e.ownerDocument)&&r.defaultView||window;var i=r.getSelection&&r.getSelection();if(i&&i.rangeCount!==0){r=i.anchorNode;var a=i.anchorOffset,o=i.focusNode;i=i.focusOffset;try{r.nodeType,o.nodeType}catch{r=null;break a}var s=0,c=-1,l=-1,u=0,d=0,f=e,p=null;b:for(;;){for(var m;f!==r||a!==0&&f.nodeType!==3||(c=s+a),f!==o||i!==0&&f.nodeType!==3||(l=s+i),f.nodeType===3&&(s+=f.nodeValue.length),(m=f.firstChild)!==null;)p=f,f=m;for(;;){if(f===e)break b;if(p===r&&++u===a&&(c=s),p===o&&++d===i&&(l=s),(m=f.nextSibling)!==null)break;f=p,p=f.parentNode}f=m}r=c===-1||l===-1?null:{start:c,end:l}}else r=null}r||={start:0,end:0}}else r=null;for(cp={focusedElem:e,selectionRange:r},gh=!1,n=(n&335544064)===n,du=t,t=n?9270:1024;du!==null;){if(e=du,n&&(r=e.deletions,r!==null))for(a=0;a<r.length;a++)n&&eu(r[a]);if(e.alternate===null&&e.flags&2)n&&Wl(e),_u(n);else{if(e.tag===22){if(r=e.alternate,e.memoizedState!==null){r!==null&&r.memoizedState===null&&n&&eu(r),_u(n);continue}if(r!==null&&r.memoizedState!==null){n&&Wl(e),_u(n);continue}}r=e.child,(e.subtreeFlags&t)!==0&&r!==null?(r.return=e,du=r):(n&&tu(e),_u(n))}}Ul=null}function _u(e){for(;du!==null;){var t=du,n=e,r=t.alternate,a=t.flags;switch(t.tag){case 0:case 11:case 15:break;case 1:if(a&1024&&r!==null){n=void 0,a=r.memoizedProps,r=r.memoizedState;var o=t.stateNode;try{var s=Tc(t.type,a);n=o.getSnapshotBeforeUpdate(s,r),o.__reactInternalSnapshotBeforeUpdate=n}catch(e){Z(t,t.return,e)}}break;case 3:if(a&1024){if(r=t.stateNode.containerInfo,n=r.nodeType,n===9)nm(r);else if(n===1)switch(r.nodeName){case`HEAD`:case`HTML`:case`BODY`:nm(r);break;default:r.textContent=``}}break;case 5:case 26:case 27:case 6:case 4:case 17:break;case 30:n&&r!==null&&(n=wi(r.memoizedProps,r.stateNode),a=t.memoizedProps,a=Ei(a.default,a.update),a!==`none`&&Jl(r,n,a,r.memoizedState=[],!0));break;default:if(a&1024)throw Error(i(163))}if(r=t.sibling,r!==null){r.return=t.return,du=r;break}du=t.return}}function vu(e,t,n){var r=n.flags;switch(n.tag){case 0:case 11:case 15:Lu(e,n),r&4&&wl(5,n);break;case 1:if(Lu(e,n),r&4){if(e=n.stateNode,t===null)try{e.componentDidMount()}catch(e){Z(n,n.return,e)}else{var i=Tc(n.type,t.memoizedProps);t=t.memoizedState;try{e.componentDidUpdate(i,t,e.__reactInternalSnapshotBeforeUpdate)}catch(e){Z(n,n.return,e)}}}r&64&&El(n),r&512&&Ol(n,n.return);break;case 3:if(Lu(e,n),r&64&&(e=n.updateQueue,e!==null)){if(t=null,n.child!==null)switch(n.child.tag){case 27:case 5:t=n.child.stateNode;break;case 1:t=n.child.stateNode}try{Ao(e,t)}catch(e){Z(n,n.return,e)}}break;case 27:t===null&&r&4&&Vl(n);case 26:case 5:Lu(e,n),t===null&&r&4&&Fl(n),r&512&&Ol(n,n.return);break;case 12:Lu(e,n);break;case 31:Lu(e,n),r&4&&Eu(e,n);break;case 13:Lu(e,n),r&4&&Du(e,n),r&64&&(e=n.memoizedState,e!==null&&(e=e.dehydrated,e!==null&&(n=_f.bind(null,n),cm(e,n))));break;case 22:if(r=n.memoizedState!==null||su,!r){var a=t!==null&&t.memoizedState!==null||H;t=su,i=H,su=r,(H=a)&&!i?(r=2,n.subtreeFlags&8772&&(r|=1),zu(e,n,r)):Lu(e,n),su=t,H=i}break;case 30:Lu(e,n),r&512&&Ol(n,n.return);break;case 7:r&512&&Ol(n,n.return);default:Lu(e,n)}}function yu(e,t){for(e=e.child;e!==null;)bu(e,t),e=e.sibling}function bu(e,t){switch(e.tag){case 5:case 26:try{var n=e.stateNode;if(t){var r=n.style;typeof r.setProperty==`function`?r.setProperty(`display`,`none`,`important`):r.display=`none`}else{var i=e.stateNode,a=e.memoizedProps.style,o=a!=null&&a.hasOwnProperty(`display`)?a.display:null;i.style.display=o==null||typeof o==`boolean`?``:(``+o).trim()}}catch(t){Z(e,e.return,t)}xu(e,t);break;case 6:try{e.stateNode.nodeValue=t?``:e.memoizedProps,A=!0}catch(t){Z(e,e.return,t)}break;case 18:try{var s=e.stateNode;t?wp(s,!0):wp(e.stateNode,!1)}catch(t){Z(e,e.return,t)}break;case 22:case 23:e.memoizedState===null&&yu(e,t);break;default:yu(e,t)}}function xu(e,t){if(e.subtreeFlags&67108864)for(e=e.child;e!==null;){a:{var n=e,r=t;switch(n.tag){case 4:bu(n,r);break a;case 22:n.memoizedState===null&&xu(n,r);break a;default:xu(n,r)}}e=e.sibling}}function Su(e){var t=e.alternate;t!==null&&(e.alternate=null,Su(t)),e.child=null,e.deletions=null,e.sibling=null,e.tag===5&&(t=e.stateNode,t!==null&&Vt(t)),e.stateNode=null,e.return=null,e.dependencies=null,e.memoizedProps=null,e.memoizedState=null,e.pendingProps=null,e.stateNode=null,e.updateQueue=null}var U=null,Cu=!1;function wu(e,t,n){for(n=n.child;n!==null;)Tu(e,t,n),n=n.sibling}function Tu(e,t,n){if(ot&&typeof ot.onCommitFiberUnmount==`function`)try{ot.onCommitFiberUnmount(at,n)}catch{}switch(n.tag){case 26:H||kl(n,t),wu(e,t,n),n.memoizedState?n.memoizedState.count--:n.stateNode&&!H&&(n=n.stateNode,n.parentNode.removeChild(n));break;case 27:H||kl(n,t),Ml(n);var r=U,i=Cu;Sp(n.type)&&(U=n.stateNode,Cu=!1),wu(e,t,n),gm(n.stateNode,n.type,n.memoizedProps),U=r,Cu=i;break;case 5:H||kl(n,t),Ml(n);case 6:if(n.tag===6&&Ml(n),r=U,i=Cu,U=null,wu(e,t,n),U=r,Cu=i,U!==null){if(Cu)try{(U.nodeType===9?U.body:U.nodeName===`HTML`?U.ownerDocument.body:U).removeChild(n.stateNode),A=!0}catch(e){Z(n,t,e)}else try{U.removeChild(n.stateNode),A=!0}catch(e){Z(n,t,e)}}break;case 18:U!==null&&(Cu?(e=U,Cp(e.nodeType===9?e.body:e.nodeName===`HTML`?e.ownerDocument.body:e,n.stateNode),Hh(e)):Cp(U,n.stateNode));break;case 4:r=U,i=Cu,U=n.stateNode.containerInfo,Cu=!0,wu(e,t,n),U=r,Cu=i;break;case 0:case 11:case 14:case 15:Tl(2,n,t),H||Tl(4,n,t),wu(e,t,n);break;case 1:H||(kl(n,t),r=n.stateNode,typeof r.componentWillUnmount==`function`&&Dl(n,t,r)),wu(e,t,n);break;case 21:wu(e,t,n);break;case 22:H=(r=H)||n.memoizedState!==null,wu(e,t,n),H=r;break;case 30:kl(n,t),wu(e,t,n);break;case 7:H||kl(n,t),wu(e,t,n);break;default:wu(e,t,n)}}function Eu(e,t){if(t.memoizedState===null&&(e=t.alternate,e!==null&&(e=e.memoizedState,e!==null))){e=e.dehydrated;try{Hh(e)}catch(e){Z(t,t.return,e)}}}function Du(e,t){if(t.memoizedState===null&&(e=t.alternate,e!==null&&(e=e.memoizedState,e!==null&&(e=e.dehydrated,e!==null))))try{Hh(e)}catch(e){Z(t,t.return,e)}}function Ou(e){switch(e.tag){case 31:case 13:case 19:var t=e.stateNode;return t===null&&(t=e.stateNode=new uu),t;case 22:return e=e.stateNode,t=e._retryCache,t===null&&(t=e._retryCache=new uu),t;default:throw Error(i(435,e.tag))}}function ku(e,t){var n=Ou(e);t.forEach(function(t){if(!n.has(t)){n.add(t);var r=vf.bind(null,e,t);t.then(r,r)}})}function Au(e,t,n){var r=t.deletions;if(r!==null)for(var a=0;a<r.length;a++){var o=r[a],s=e,c=t,l=c;a:for(;l!==null;){switch(l.tag){case 27:if(Sp(l.type)){U=l.stateNode,Cu=!1;break a}break;case 5:U=l.stateNode,Cu=!1;break a;case 3:case 4:U=l.stateNode.containerInfo,Cu=!0;break a}l=l.return}if(U===null)throw Error(i(160));Tu(s,c,o),U=null,Cu=!1,s=o.alternate,s!==null&&(s.return=null),o.return=null}if(t.subtreeFlags&13886)for(t=t.child;t!==null;)Mu(t,e,n),t=t.sibling}var ju=null;function Mu(e,t,n){var r=e.alternate,a=e.flags;switch(e.tag){case 0:case 11:case 14:case 15:if(a&4&&(r=e.updateQueue,r=r===null?null:r.events,r!==null))for(var o=0;o<r.length;o++){var s=r[o];s.ref.impl=s.nextImpl}Au(t,e,n),Nu(e),a&4&&(Tl(3,e,e.return),wl(3,e),Tl(5,e,e.return));break;case 1:Au(t,e,n),Nu(e),a&512&&(H||r===null||kl(r,r.return)),a&64&&su&&(e=e.updateQueue,e!==null&&(t=e.callbacks,t!==null&&(n=e.shared.hiddenCallbacks,e.shared.hiddenCallbacks=n===null?t:n.concat(t))));break;case 26:if(o=ju,Au(t,e,n),Nu(e),a&512&&(H||r===null||kl(r,r.return)),a&4){if(a=r===null?null:r.memoizedState,n=e.memoizedState,r===null){if(n===null){if(e.stateNode===null){if(su)e.stateNode=fp(e.type,e.memoizedProps,t.containerInfo,e);else{a:{t=e.type,n=e.memoizedProps,a=o.ownerDocument||o;b:switch(t){case`title`:r=a.getElementsByTagName(`title`)[0],(!r||r[zt]||r[Mt]||r.namespaceURI===`http://www.w3.org/2000/svg`||r.hasAttribute(`itemprop`))&&(r=a.createElement(t),a.head.insertBefore(r,a.querySelector(`head > title`))),np(r,t,n),r[Mt]=e,k(r),t=r;break a;case`link`:if(o=Gm(`link`,`href`,a).get(t+(n.href||``))){for(s=0;s<o.length;s++)if(r=o[s],r.getAttribute(`href`)===(n.href==null||n.href===``?null:n.href)&&r.getAttribute(`rel`)===(n.rel==null?null:n.rel)&&r.getAttribute(`title`)===(n.title==null?null:n.title)&&r.getAttribute(`crossorigin`)===(n.crossOrigin==null?null:n.crossOrigin)){o.splice(s,1);break b}}r=a.createElement(t),np(r,t,n),a.head.appendChild(r);break;case`meta`:if(o=Gm(`meta`,`content`,a).get(t+(n.content||``))){for(s=0;s<o.length;s++)if(r=o[s],r.getAttribute(`content`)===(n.content==null?null:``+n.content)&&r.getAttribute(`name`)===(n.name==null?null:n.name)&&r.getAttribute(`property`)===(n.property==null?null:n.property)&&r.getAttribute(`http-equiv`)===(n.httpEquiv==null?null:n.httpEquiv)&&r.getAttribute(`charset`)===(n.charSet==null?null:n.charSet)){o.splice(s,1);break b}}r=a.createElement(t),np(r,t,n),a.head.appendChild(r);break;default:throw Error(i(468,t))}r[Mt]=e,k(r),t=r}e.stateNode=t}}else su||Km(o,e.type,e.stateNode)}else e.stateNode=Bm(o,n,e.memoizedProps)}else a===n?n===null&&e.stateNode!==null&&Il(e,e.memoizedProps,r.memoizedProps):(a===null?(t=r.stateNode,t===null||H||t.parentNode.removeChild(t)):a.count--,n===null?su||Km(o,e.type,e.stateNode):Bm(o,n,e.memoizedProps))}break;case 27:Au(t,e,n),Nu(e),a&512&&(H||r===null||kl(r,r.return)),r!==null&&a&4&&Il(e,e.memoizedProps,r.memoizedProps);break;case 5:if(o=cu,cu=!1,Au(t,e,n),cu=o,Nu(e),a&512&&(H||r===null||kl(r,r.return)),e.flags&32){t=e.stateNode;try{yn(t,``),A=!0}catch(t){Z(e,e.return,t)}}a&4&&e.stateNode!=null&&(t=e.memoizedProps,Il(e,t,r===null?t:r.memoizedProps)),a&1024&&(lu=!0);break;case 6:if(Au(t,e,n),Nu(e),a&4){if(e.stateNode===null)throw Error(i(162));t=e.memoizedProps,n=e.stateNode;try{n.nodeValue=t,A=!0}catch(t){Z(e,e.return,t)}}break;case 3:if(A=!1,Wm=null,o=ju,ju=bm(t.containerInfo),Au(t,e,n),ju=o,Nu(e),a&4&&r!==null&&r.memoizedState.isDehydrated)try{Hh(t.containerInfo)}catch(t){Z(e,e.return,t)}lu&&(lu=!1,Pu(e)),A=!1;break;case 4:a=cu,cu=su,r=tn(),o=ju,ju=bm(e.stateNode.containerInfo),Au(t,e,n),Nu(e),ju=o,A&&pu&&(mu=!0),A=r,cu=a;break;case 12:Au(t,e,n),Nu(e);break;case 31:Au(t,e,n),Nu(e),a&4&&(t=e.updateQueue,t!==null&&(e.updateQueue=null,ku(e,t)));break;case 13:Au(t,e,n),Nu(e),e.child.flags&8192&&e.memoizedState!==null!=(r!==null&&r.memoizedState!==null)&&(hd=Xe()),a&4&&(t=e.updateQueue,t!==null&&(e.updateQueue=null,ku(e,t)));break;case 22:o=e.memoizedState!==null,s=r!==null&&r.memoizedState!==null;var c=su,l=H,u=cu;su=c||o,cu=u||o,H=l||s,Au(t,e,n),H=l,cu=u,su=c,Nu(e),a&8192&&(t=e.stateNode,t._visibility=o?t._visibility&-2:t._visibility|1,!o||r===null||s||su||H||(t=s||H,n=su,r=H,su=o||su,H=t,Ru(e,2),su=n,H=r),!o&&cu||yu(e,o)),a&4&&(t=e.updateQueue,t!==null&&(n=t.retryQueue,n!==null&&(t.retryQueue=null,ku(e,n))));break;case 19:Au(t,e,n),Nu(e),a&4&&(t=e.updateQueue,t!==null&&(e.updateQueue=null,ku(e,t)));break;case 30:a&512&&(H||r===null||kl(r,r.return)),a=tn(),o=pu,s=(n&335544064)===n,c=e.memoizedProps,pu=s&&Ei(c.default,c.update)!==`none`,Au(t,e,n),Nu(e),s&&r!==null&&A&&(e.flags|=4),pu=o,A=a;break;case 21:break;case 7:a&512&&(H||r===null||kl(r,r.return)),r&&r.stateNode!==null&&(r.stateNode._fragmentFiber=e);default:Au(t,e,n),Nu(e)}}function Nu(e){var t=e.flags;if(t&2){try{for(var n,r=e.return;r!==null;){if(Ll(r)){n=r;break}r=r.return}r=null;for(var a=e.return;a!==null;){if(Pl(a)){var o=a.stateNode;r===null?r=[o]:r.push(o)}if(Nl(a))break;a=a.return}var s=r;if(n==null)throw Error(i(160));switch(n.tag){case 27:var c=n.stateNode;Bl(e,Rl(e),c,s);break;case 5:var l=n.stateNode;n.flags&32&&(yn(l,``),n.flags&=-33),Bl(e,Rl(e),l,s);break;case 3:case 4:var u=n.stateNode.containerInfo;zl(e,Rl(e),u,s);break;default:throw Error(i(161))}}catch(t){Z(e,e.return,t)}e.flags&=-3}t&4096&&(e.flags&=-4097)}function Pu(e){if(e.subtreeFlags&1024)for(e=e.child;e!==null;){var t=e;Pu(t),t.tag===5&&t.flags&1024&&(t=t.stateNode,gh=!0,t.reset(),gh=!1),e=e.sibling}}function Fu(e,t){if(t.subtreeFlags&9270)for(t=t.child;t!==null;)Iu(t,e),t=t.sibling;else ou(t,!1)}function Iu(e,t){var n=e.alternate;if(n===null)Ql(e,!1);else switch(e.tag){case 3:if(hu=fu=!1,Kl(),Fu(t,e),!fu&&!mu){if(e=Gl,e!==null)for(var r=0;r<e.length;r+=3){n=e[r];var i=e[r+1];Ep(n,e[r+2]),n=n.ownerDocument.documentElement,n!==null&&n.animate({opacity:[0,0],pointerEvents:[`none`,`none`]},{duration:0,fill:`forwards`,pseudoElement:`::view-transition-group(`+i+`)`})}e=t.containerInfo,e=e.nodeType===9?e.documentElement:e.ownerDocument.documentElement,e!==null&&e.style.viewTransitionName===``&&(e.style.viewTransitionName=`none`,e.animate({opacity:[0,0],pointerEvents:[`none`,`none`]},{duration:0,fill:`forwards`,pseudoElement:`::view-transition-group(root)`}),e.animate({width:[0,0],height:[0,0]},{duration:0,fill:`forwards`,pseudoElement:`::view-transition`})),hu=!0}Gl=null;break;case 5:Fu(t,e);break;case 4:r=fu,fu=!1,Fu(t,e),fu&&(mu=!0),fu=r;break;case 22:e.memoizedState===null&&(n.memoizedState===null?Fu(t,e):Ql(e,!1));break;case 30:r=fu,i=Kl(),fu=!1,Fu(t,e),fu&&(e.flags|=4);var a=e.memoizedProps,o=e.stateNode;t=wi(a,o),o=wi(n.memoizedProps,o);var s=Ei(a.default,a.update);s===`none`?t=!1:(a=n.memoizedState,n.memoizedState=null,n=e.child,ql=0,t=au(e,n,t,o,s,a,!0),ql!==(a===null?0:a.length)&&(e.flags|=32)),e.flags&4&&t?(Nd(e,e.memoizedProps.onUpdate),Gl=i):i!==null&&(i.push.apply(i,Gl),Gl=i),fu=e.flags&32?!0:r;break;default:Fu(t,e)}}function Lu(e,t){if(t.subtreeFlags&8772)for(t=t.child;t!==null;)vu(e,t.alternate,t),t=t.sibling}function Ru(e,t){for(e=e.child;e!==null;){var n=e,r=t;switch(n.tag){case 0:case 11:case 14:case 15:Tl(4,n,n.return),Ru(n,r);break;case 1:kl(n,n.return);var i=n.stateNode;typeof i.componentWillUnmount==`function`&&Dl(n,n.return,i),Ru(n,r);break;case 27:r&2&&gm(n.stateNode,n.type,n.memoizedProps);case 5:kl(n,n.return),n.tag!==5&&n.tag!==27||Ml(n),Ru(n,r);break;case 6:Ml(n);break;case 26:kl(n,n.return),i=n.stateNode,n.memoizedState!==null||i===null||H||i.parentNode.removeChild(i),Ru(n,r);break;case 22:n.memoizedState===null&&Ru(n,r);break;case 30:kl(n,n.return),Ru(n,r);break;case 7:kl(n,n.return);default:Ru(n,r)}e=e.sibling}}function zu(e,t,n){for(n=t.subtreeFlags&8772?n:n&-2,t=t.child;t!==null;){var r=t.alternate,i=e,a=t,o=a.flags,s=!!(n&1);switch(a.tag){case 0:case 11:case 15:zu(i,a,n),wl(4,a);break;case 1:if(zu(i,a,n),r=a,i=r.stateNode,typeof i.componentDidMount==`function`)try{i.componentDidMount()}catch(e){Z(r,r.return,e)}if(r=a,i=r.updateQueue,i!==null){var c=r.stateNode;try{var l=i.shared.hiddenCallbacks;if(l!==null)for(i.shared.hiddenCallbacks=null,i=0;i<l.length;i++)ko(l[i],c)}catch(e){Z(r,r.return,e)}}s&&o&64&&El(a),Ol(a,a.return);break;case 27:n&2&&Vl(a);case 5:a.tag!==5&&a.tag!==27||jl(a),zu(i,a,n),s&&r===null&&o&4&&Fl(a),Ol(a,a.return);break;case 6:jl(a);break;case 26:c=a.stateNode,a.memoizedState!==null||c===null||su||Km(bm(c.ownerDocument),a.type,c),zu(i,a,n),s&&r===null&&o&4&&Fl(a),Ol(a,a.return);break;case 12:zu(i,a,n);break;case 31:zu(i,a,n),s&&o&4&&Eu(i,a);break;case 13:zu(i,a,n),s&&o&4&&Du(i,a);break;case 22:a.memoizedState===null&&zu(i,a,n),Ol(a,a.return);break;case 30:zu(i,a,n),Ol(a,a.return);break;case 7:Ol(a,a.return);default:zu(i,a,n)}t=t.sibling}}function Bu(e,t){var n=null;e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(n=e.memoizedState.cachePool.pool),e=null,t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(e=t.memoizedState.cachePool.pool),e!==n&&(e!=null&&e.refCount++,n!=null&&Ra(n))}function Vu(e,t){e=null,t.alternate!==null&&(e=t.alternate.memoizedState.cache),t=t.memoizedState.cache,t!==e&&(t.refCount++,e!=null&&Ra(e))}function Hu(e,t,n,r){var i=(n&335544064)===n;if(t.subtreeFlags&(i?10262:10256))for(t=t.child;t!==null;)Uu(e,t,n,r),t=t.sibling;else i&&iu(t)}function Uu(e,t,n,r){var i=(n&335544064)===n;i&&t.alternate===null&&t.return!==null&&t.return.alternate!==null&&ru(t);var a=t.flags;switch(t.tag){case 0:case 11:case 15:Hu(e,t,n,r),a&2048&&wl(9,t);break;case 1:Hu(e,t,n,r);break;case 3:Hu(e,t,n,r),i&&hu&&(e=e.containerInfo,e=e.nodeType===9?e.body:e.nodeName===`HTML`?e.ownerDocument.body:e,e.style.viewTransitionName===`root`&&(e.style.viewTransitionName=``),e=e.ownerDocument.documentElement,e!==null&&e.style.viewTransitionName===`none`&&(e.style.viewTransitionName=``)),a&2048&&(a=null,t.alternate!==null&&(a=t.alternate.memoizedState.cache),t=t.memoizedState.cache,t!==a&&(t.refCount++,a!=null&&Ra(a)));break;case 12:if(a&2048){Hu(e,t,n,r),a=t.stateNode;try{var o=t.memoizedProps,s=o.id,c=o.onPostCommit;typeof c==`function`&&c(s,t.alternate===null?`mount`:`update`,a.passiveEffectDuration,-0)}catch(e){Z(t,t.return,e)}}else Hu(e,t,n,r);break;case 31:Hu(e,t,n,r);break;case 13:Hu(e,t,n,r);break;case 23:break;case 22:o=t.stateNode,s=t.alternate,t.memoizedState===null?(i&&s!==null&&s.memoizedState!==null&&ru(t),o._visibility&2?Hu(e,t,n,r):(o._visibility|=2,Wu(e,t,n,r,!!(t.subtreeFlags&10256)||!1))):(i&&s!==null&&s.memoizedState===null&&ru(s),o._visibility&2?Hu(e,t,n,r):Gu(e,t)),a&2048&&Bu(s,t);break;case 24:Hu(e,t,n,r),a&2048&&Vu(t.alternate,t);break;case 30:i&&(a=t.alternate,a!==null&&(Xl(a.child,!0),Xl(t.child,!0))),Hu(e,t,n,r);break;default:Hu(e,t,n,r)}}function Wu(e,t,n,r,i){for(i&&=!!(t.subtreeFlags&10256)||!1,t=t.child;t!==null;){var a=e,o=t,s=n,c=r,l=o.flags;switch(o.tag){case 0:case 11:case 15:Wu(a,o,s,c,i),wl(8,o);break;case 23:break;case 22:var u=o.stateNode;o.memoizedState===null?(u._visibility|=2,Wu(a,o,s,c,i)):u._visibility&2?Wu(a,o,s,c,i):Gu(a,o),i&&l&2048&&Bu(o.alternate,o);break;case 24:Wu(a,o,s,c,i),i&&l&2048&&Vu(o.alternate,o);break;default:Wu(a,o,s,c,i)}t=t.sibling}}function Gu(e,t){if(t.subtreeFlags&10256)for(t=t.child;t!==null;){var n=e,r=t,i=r.flags;switch(r.tag){case 22:Gu(n,r),i&2048&&Bu(r.alternate,r);break;case 24:Gu(n,r),i&2048&&Vu(r.alternate,r);break;default:Gu(n,r)}t=t.sibling}}var Ku=8192;function qu(e,t,n){if(e.subtreeFlags&Ku)for(e=e.child;e!==null;)Ju(e,t,n),e=e.sibling}function Ju(e,t,n){switch(e.tag){case 26:qu(e,t,n),e.flags&Ku&&(e.memoizedState===null?(e=e.stateNode,(t&335544128)===t&&Zm(n,e)):Qm(n,ju,e.memoizedState,e.memoizedProps));break;case 5:qu(e,t,n),e.flags&Ku&&(e=e.stateNode,(t&335544128)===t&&Zm(n,e));break;case 3:case 4:var r=ju;ju=bm(e.stateNode.containerInfo),qu(e,t,n),ju=r;break;case 22:e.memoizedState===null&&(r=e.alternate,r!==null&&r.memoizedState!==null?(r=Ku,Ku=16777216,qu(e,t,n),Ku=r):qu(e,t,n));break;case 30:if((e.flags&Ku)!==0&&(r=e.memoizedProps.name,r!=null&&r!==`auto`)){var i=e.stateNode;i.paired=null,Ul===null&&(Ul=new Map),Ul.set(r,i)}qu(e,t,n);break;default:qu(e,t,n)}}function Yu(e){var t=e.alternate;if(t!==null&&(e=t.child,e!==null)){t.child=null;do t=e.sibling,e.sibling=null,e=t;while(e!==null)}}function Xu(e){var t=e.deletions;if(e.flags&16){if(t!==null)for(var n=0;n<t.length;n++){var r=t[n];du=r,$u(r,e)}Yu(e)}if(e.subtreeFlags&10256)for(e=e.child;e!==null;)Zu(e),e=e.sibling}function Zu(e){switch(e.tag){case 0:case 11:case 15:Xu(e),e.flags&2048&&Tl(9,e,e.return);break;case 3:Xu(e);break;case 12:Xu(e);break;case 22:var t=e.stateNode;e.memoizedState!==null&&t._visibility&2&&(e.return===null||e.return.tag!==13)?(t._visibility&=-3,Qu(e)):Xu(e);break;default:Xu(e)}}function Qu(e){var t=e.deletions;if(e.flags&16){if(t!==null)for(var n=0;n<t.length;n++){var r=t[n];du=r,$u(r,e)}Yu(e)}for(e=e.child;e!==null;){switch(t=e,t.tag){case 0:case 11:case 15:Tl(8,t,t.return),Qu(t);break;case 22:n=t.stateNode,n._visibility&2&&(n._visibility&=-3,Qu(t));break;default:Qu(t)}e=e.sibling}}function $u(e,t){for(;du!==null;){var n=du;switch(n.tag){case 0:case 11:case 15:Tl(8,n,t);break;case 23:case 22:if(n.memoizedState!==null&&n.memoizedState.cachePool!==null){var r=n.memoizedState.cachePool.pool;r!=null&&r.refCount++}break;case 24:Ra(n.memoizedState.cache)}if(r=n.child,r!==null)r.return=n,du=r;else a:for(n=e;du!==null;){r=du;var i=r.sibling,a=r.return;if(Su(r),r===n){du=null;break a}if(i!==null){i.return=a,du=i;break a}du=a}}}var ed={getCacheForType:function(e){var t=ja(F),n=t.data.get(e);return n===void 0&&(n=e(),t.data.set(e,n)),n},cacheSignal:function(){return ja(F).controller.signal}},td=typeof WeakMap==`function`?WeakMap:Map,W=0,G=null,K=null,q=0,J=0,nd=null,rd=!1,id=!1,ad=!1,od=0,Y=0,sd=0,cd=0,ld=0,ud=0,dd=0,fd=null,pd=null,md=!1,hd=0,gd=0,_d=1/0,vd=null,yd=null,X=0,bd=null,xd=null,Sd=0,Cd=0,wd=null,Td=null,Ed=null,Dd=null,Od=null,kd=0,Ad=null;function jd(){return W&2&&q!==0?q&-q:E.T===null?kt():Pf()}function Md(){if(ud===0){if(!(q&536870912)||P){var e=pt;pt<<=1,!(pt&3932160)&&(pt=262144),ud=e}else ud=536870912}return e=Io.current,e!==null&&(e.flags|=32),ud}function Nd(e,t){if(t!=null){var n=e.stateNode,r=n.ref;r===null&&(r=n.ref=Pp(wi(e.memoizedProps,n))),Dd===null&&(Dd=[]),Dd.push(t.bind(null,r))}}function Pd(e,t,n){(e===G&&(J===2||J===9)||e.cancelPendingCommit!==null)&&(Vd(e,0),Rd(e,q,ud,!1)),St(e,n),(!(W&2)||e!==G)&&(e===G&&(!(W&2)&&(cd|=n),Y===4&&Rd(e,q,ud,!1)),Ef(e))}function Fd(e,t,n){if(W&6)throw Error(i(327));var r=!n&&!(t&127)&&(t&e.expiredLanes)===0||_t(e,t),a=r?Yd(e,t):qd(e,t,!0),o=r;do{if(a===0){id&&!r&&Rd(e,t,0,!1);break}if(n=e.current.alternate,o&&!Ld(n)){a=qd(e,t,!1),o=!1;continue}if(a===2){if(o=t,e.errorRecoveryDisabledLanes&o)var s=0;else s=e.pendingLanes&-536870913,s=s===0?s&536870912?536870912:0:s;if(s!==0){t=s;a:{var c=e;a=fd;var l=c.current.memoizedState.isDehydrated;if(l&&(Vd(c,s).flags|=256),s=qd(c,s,!1),s!==2&&s!==6){if(ad&&!l){c.errorRecoveryDisabledLanes|=o,cd|=o,a=4;break a}o=pd,pd=a,o!==null&&(pd===null?pd=o:pd.push.apply(pd,o))}a=s}if(o=!1,a!==2)continue}}if(a===1){Vd(e,0),Rd(e,t,0,!0);break}a:{switch(r=e,o=a,o){case 0:case 1:throw Error(i(345));case 4:if((t&4194048)!==t&&(t&62914560)!==t)break;case 6:Rd(r,t,ud,!rd);break a;case 2:pd=null;break;case 3:case 5:break;default:throw Error(i(329))}if((t&62914560)===t&&(a=hd+300-Xe(),10<a)){if(Rd(r,t,ud,!rd),gt(r,0,!0)!==0)break a;Sd=t,r.timeoutHandle=gp(Id.bind(null,r,n,pd,vd,md,t,ud,cd,dd,rd,o,`Throttled`,-0,0),a);break a}Id(r,n,pd,vd,md,t,ud,cd,dd,rd,o,null,-0,0)}break}while(1);Ef(e)}function Id(e,t,n,r,i,a,o,s,c,l,u,d,f,p){e.timeoutHandle=-1;var m=t.subtreeFlags,h=(a&335544064)===a;if(d=null,(h||m&8192||(m&16785408)==16785408)&&(d={stylesheets:null,count:0,imgCount:0,imgBytes:0,suspenseyImages:[],waitingForImages:!0,waitingForViewTransition:!1,unsuspend:Dn},Ul=null,Ju(t,a,d),h&&(m=d,h=e.containerInfo,h=(h.nodeType===9?h:h.ownerDocument).__reactViewTransition,h!=null&&(m.count++,m.waitingForViewTransition=!0,m=nh.bind(m),h.finished.then(m,m))),m=(a&62914560)===a?hd-Xe():(a&4194048)===a?gd-Xe():0,m=eh(d,m),m!==null)){Sd=a,e.cancelPendingCommit=m(nf.bind(null,e,t,a,n,r,i,o,s,c,l,u,d,null,f,p)),Rd(e,a,o,!l);return}nf(e,t,a,n,r,i,o,s,c,l,u,d)}function Ld(e){for(var t=e;;){var n=t.tag;if((n===0||n===11||n===15)&&t.flags&16384&&(n=t.updateQueue,n!==null&&(n=n.stores,n!==null)))for(var r=0;r<n.length;r++){var i=n[r],a=i.getSnapshot;i=i.value;try{if(!Jr(a(),i))return!1}catch{return!1}}if(n=t.child,t.subtreeFlags&16384&&n!==null)n.return=t,t=n;else{if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return!0;t=t.return}t.sibling.return=t.return,t=t.sibling}}return!0}function Rd(e,t,n,r){t=vt(e,t),t&=~ld,t&=~cd,e.suspendedLanes|=t,e.pingedLanes&=~t,r&&(e.warmLanes|=t),r=e.expirationTimes;for(var i=t;0<i;){var a=31-ct(i),o=1<<a;r[a]=-1,i&=~o}n!==0&&wt(e,n,t)}function zd(){return W&6?!0:(Df(0,!1),!1)}function Bd(){if(K!==null){if(J===0)var e=K.return;else e=K,Ca=Sa=null,cs(e),uo=null,fo=0,e=K;for(;e!==null;)Cl(e.alternate,e),e=e.return;K=null}}function Vd(e,t){var n=e.timeoutHandle;return n!==-1&&(e.timeoutHandle=-1,_p(n)),n=e.cancelPendingCommit,n!==null&&(e.cancelPendingCommit=null,n()),Sd=0,Bd(),G=e,K=n=Vi(e.current,null),q=t,J=0,nd=null,rd=!1,id=_t(e,t),ad=!1,dd=ud=ld=cd=sd=Y=0,pd=fd=null,md=!1,od=vt(e,t),ji(),n}function Hd(e,t){I=null,E.H=_c,t===eo||t===no?(t=co(),J=3):t===to?(t=co(),J=4):J=t===Fc?8:typeof t==`object`&&t&&typeof t.then==`function`?6:1,nd=t,K===null&&(Y=1,kc(e,Yi(t,e.current)))}function Ud(){var e=Io.current;return e===null?!0:(q&4194048)===q?Lo===null:(q&62914560)===q||q&536870912?e===Lo:!1}function Wd(){var e=E.H;return E.H=_c,e===null?_c:e}function Gd(){var e=E.A;return E.A=ed,e}function Kd(){Y=4,rd||(q&4194048)!==q&&Io.current!==null||(id=!0),!(sd&134217727)&&!(cd&134217727)||G===null||Rd(G,q,ud,!1)}function qd(e,t,n){var r=W;W|=2;var i=Wd(),a=Gd();(G!==e||q!==t)&&(vd=null,Vd(e,t)),t=!1;var o=Y;a:do try{if(J!==0&&K!==null){var s=K,c=nd;switch(J){case 8:Bd(),o=6;break a;case 3:case 2:case 9:case 6:Io.current===null&&(t=!0);var l=J;if(J=0,nd=null,$d(e,s,c,l),n&&id){o=0;break a}break;default:l=J,J=0,nd=null,$d(e,s,c,l)}}Jd(),o=Y;break}catch(t){Hd(e,t)}while(1);return t&&e.shellSuspendCounter++,Ca=Sa=null,W=r,E.H=i,E.A=a,K===null&&(G=null,q=0,ji()),o}function Jd(){for(;K!==null;)Zd(K)}function Yd(e,t){var n=W;W|=2;var r=Wd(),a=Gd();G!==e||q!==t?(vd=null,_d=Xe()+500,Vd(e,t)):id=_t(e,t);a:do try{if(J!==0&&K!==null){t=K;var o=nd;b:switch(J){case 1:J=0,nd=null,$d(e,t,o,1);break;case 2:case 9:if(io(o)){J=0,nd=null,Qd(t);break}t=function(){J!==2&&J!==9||G!==e||(J=7),Ef(e)},o.then(t,t);break a;case 3:J=7;break a;case 4:J=5;break a;case 7:io(o)?(J=0,nd=null,Qd(t)):(J=0,nd=null,$d(e,t,o,7));break;case 5:var s=null;switch(K.tag){case 26:s=K.memoizedState;case 5:case 27:var c=K;if(s?Ym(s):c.stateNode.complete){J=0,nd=null;var l=c.sibling;if(l!==null)K=l;else{var u=c.return;u===null?K=null:(K=u,ef(u))}break b}}J=0,nd=null,$d(e,t,o,5);break;case 6:J=0,nd=null,$d(e,t,o,6);break;case 8:Bd(),Y=6;break a;default:throw Error(i(462))}}Xd();break}catch(t){Hd(e,t)}while(1);return Ca=Sa=null,E.H=r,E.A=a,W=n,K===null?(G=null,q=0,ji(),Y):0}function Xd(){for(;K!==null&&!Je();)Zd(K)}function Zd(e){var t=hl(e.alternate,e,od);e.memoizedProps=e.pendingProps,t===null?ef(e):K=t}function Qd(e){var t=e,n=t.alternate;switch(t.tag){case 15:case 0:t=Yc(n,t,t.pendingProps,t.type,void 0,q);break;case 11:t=Yc(n,t,t.pendingProps,t.type.render,t.ref,q);break;case 5:cs(t);var r=t;r===ua&&(P?(ga(r),r.tag===5&&r.stateNode!=null&&(N=r.stateNode)):(ga(r),P=!0));default:Cl(n,t),t=K=Hi(t,od),t=hl(n,t,od)}e.memoizedProps=e.pendingProps,t===null?ef(e):K=t}function $d(e,t,n,r){Ca=Sa=null,cs(t),uo=null,fo=0;var i=t.return;try{if(Pc(e,i,t,n,q)){Y=1,kc(e,Yi(n,e.current)),K=null;return}}catch(t){if(i!==null)throw K=i,t;Y=1,kc(e,Yi(n,e.current)),K=null;return}t.flags&32768?(P||r===1?e=!0:id||q&536870912?e=!1:(rd=e=!0,(r===2||r===9||r===3||r===6)&&(r=Io.current,r!==null&&r.tag===13&&(r.flags|=16384))),tf(t,e)):ef(t)}function ef(e){var t=e;do{if(t.flags&32768){tf(t,rd);return}e=t.return;var n=xl(t.alternate,t,od);if(n!==null){K=n;return}if(t=t.sibling,t!==null){K=t;return}K=t=e}while(t!==null);Y===0&&(Y=5)}function tf(e,t){do{var n=Sl(e.alternate,e);if(n!==null){n.flags&=32767,K=n;return}if(n=e.return,n!==null&&(n.flags|=32768,n.subtreeFlags=0,n.deletions=null),!t&&(e=e.sibling,e!==null)){K=e;return}K=e=n}while(e!==null);Y=6,K=null}function nf(e,t,n,r,a,o,s,c,l,u,d,f){e.cancelPendingCommit=null;do df();while(X!==0);if(W&6)throw Error(i(327));if(t!==null){if(t===e.current)throw Error(i(177));e===G&&(K=G=null,q=0),xd=t,bd=e,Sd=n,wd=a,Td=r,rf(e,t,n,s,c,l,f)}}function rf(e,t,n,r,i,a,o){var s=t.lanes|t.childLanes;if(Cd=s,s|=Ai,Ct(e,n,s,r,i,a),Dd=null,(n&335544064)===n?(Od=Va(e),r=10262):(Od=null,r=10256),(t.subtreeFlags&r)!==0||(t.flags&r)!==0?(e.callbackNode=null,e.callbackPriority=0,yf(et,function(){return ff(),null})):(e.callbackNode=null,e.callbackPriority=0),Hl=!1,r=!!(t.flags&13878),t.subtreeFlags&13878||r){r=E.T,E.T=null,i=D.p,D.p=2,a=W,W|=4;try{gu(e,t,n)}finally{W=a,D.p=i,E.T=r}}X=1,Hl?Ed=Mp(o,e.containerInfo,Od,sf,cf,of,lf,ff,af,null,null):(sf(),cf(),lf())}function af(e){if(X!==0){var t=bd.onRecoverableError;t(e,{componentStack:null})}}function of(){X===3&&(X=0,Iu(xd,bd),X=4)}function sf(){if(X===1){X=0;var e=bd,t=xd,n=Sd,r=!!(t.flags&13878);if(t.subtreeFlags&13878||r){r=E.T,E.T=null;var i=D.p;D.p=2;var a=W;W|=4;try{pu=mu=!1,Mu(t,e,n),n=cp;var o=ei(e.containerInfo),s=n.focusedElem,c=n.selectionRange;if(o!==s&&s&&s.ownerDocument&&$r(s.ownerDocument.documentElement,s)){if(c!==null&&ti(s)){var l=c.start,u=c.end;if(u===void 0&&(u=l),`selectionStart`in s)s.selectionStart=l,s.selectionEnd=Math.min(u,s.value.length);else{var d=s.ownerDocument||document,f=d&&d.defaultView||window;if(f.getSelection){var p=f.getSelection(),m=s.textContent.length,h=Math.min(c.start,m),g=c.end===void 0?h:Math.min(c.end,m);!p.extend&&h>g&&(o=g,g=h,h=o);var _=Qr(s,h),v=Qr(s,g);if(_&&v&&(p.rangeCount!==1||p.anchorNode!==_.node||p.anchorOffset!==_.offset||p.focusNode!==v.node||p.focusOffset!==v.offset)){var y=d.createRange();y.setStart(_.node,_.offset),p.removeAllRanges(),h>g?(p.addRange(y),p.extend(v.node,v.offset)):(y.setEnd(v.node,v.offset),p.addRange(y))}}}}for(d=[],p=s;p=p.parentNode;)p.nodeType===1&&d.push({element:p,left:p.scrollLeft,top:p.scrollTop});for(typeof s.focus==`function`&&s.focus(),s=0;s<d.length;s++){var b=d[s];b.element.scrollLeft=b.left,b.element.scrollTop=b.top}}gh=!!sp,cp=sp=null}finally{W=a,D.p=i,E.T=r}}e.current=t,X=2}}function cf(){if(X===2){X=0;var e=bd,t=xd,n=!!(t.flags&8772);if(t.subtreeFlags&8772||n){n=E.T,E.T=null;var r=D.p;D.p=2;var i=W;W|=4;try{vu(e,t.alternate,t)}finally{W=i,D.p=r,E.T=n}}X=3}}function lf(){if(X===4||X===3){X=0;var e=Ed;Ed=null,Ye();var t=bd,n=xd,r=Sd,i=Td,a=(r&335544064)===r?10262:10256;if((n.subtreeFlags&a)!==0||(n.flags&a)!==0?X=5:(X=0,xd=bd=null,uf(t,t.pendingLanes)),a=t.pendingLanes,a===0&&(yd=null),Ot(r),n=n.stateNode,ot&&typeof ot.onCommitFiberRoot==`function`)try{ot.onCommitFiberRoot(at,n,void 0,(n.current.flags&128)==128)}catch{}if(i!==null){n=E.T,a=D.p,D.p=2,E.T=null;try{for(var o=t.onRecoverableError,s=0;s<i.length;s++){var c=i[s];o(c.value,{componentStack:c.stack})}}finally{E.T=n,D.p=a}}if(i=Dd,o=Od,Od=null,i!==null&&(Dd=null,o===null&&(o=[]),e!==null))for(c=0;c<i.length;c++)n=(0,i[c])(o),n!==void 0&&e.finished.finally(n);Sd&3&&df(),Ef(t),a=t.pendingLanes,r&261930&&a&42?t===Ad?kd++:(kd=0,Ad=t):(kd=0,Ad=null),Df(0,!1)}}function uf(e,t){(e.pooledCacheLanes&=t)===0&&(t=e.pooledCache,t!=null&&(e.pooledCache=null,Ra(t)))}function df(){return Ed!==null&&(Ed.skipTransition(),Ed=null),sf(),cf(),lf(),ff()}function ff(){if(X!==5)return!1;var e=bd,t=Cd;Cd=0;var n=Ot(Sd),r=E.T,a=D.p;try{D.p=32>n?32:n,E.T=null,n=wd,wd=null;var o=bd,s=Sd;if(X=0,xd=bd=null,Sd=0,W&6)throw Error(i(331));var c=W;if(W|=4,Zu(o.current),Uu(o,o.current,s,n),W=c,Df(0,!1),ot&&typeof ot.onPostCommitFiberRoot==`function`)try{ot.onPostCommitFiberRoot(at,o)}catch{}return!0}finally{D.p=a,E.T=r,uf(e,t)}}function pf(e,t,n){t=Yi(n,t),t=jc(e.stateNode,t,2),e=Co(e,t,2),e!==null&&(St(e,2),Ef(e))}function Z(e,t,n){if(e.tag===3)pf(e,e,n);else for(;t!==null;){if(t.tag===3){pf(t,e,n);break}if(t.tag===1){var r=t.stateNode;if(typeof t.type.getDerivedStateFromError==`function`||typeof r.componentDidCatch==`function`&&(yd===null||!yd.has(r))){e=Yi(n,e),n=Mc(2),r=Co(t,n,2),r!==null&&(Nc(n,r,t,e),St(r,2),Ef(r));break}}t=t.return}}function mf(e,t,n){var r=e.pingCache;if(r===null){r=e.pingCache=new td;var i=new Set;r.set(t,i)}else i=r.get(t),i===void 0&&(i=new Set,r.set(t,i));i.has(n)||(ad=!0,i.add(n),e=hf.bind(null,e,t,n),t.then(e,e))}function hf(e,t,n){var r=e.pingCache;r!==null&&r.delete(t),e.pingedLanes|=e.suspendedLanes&n,e.warmLanes&=~n,G===e&&(q&n)===n&&(Y===4||Y===3&&(q&62914560)===q&&300>Xe()-hd?W&2?ld|=n:Vd(e,0):ld|=n,dd===q&&(dd=0)),Ef(e)}function gf(e,t){t===0&&(t=bt()),e=Pi(e,t),e!==null&&(St(e,t),Ef(e))}function _f(e){var t=e.memoizedState,n=0;t!==null&&(n=t.retryLane),gf(e,n)}function vf(e,t){var n=0;switch(e.tag){case 31:case 13:var r=e.stateNode,a=e.memoizedState;a!==null&&(n=a.retryLane);break;case 19:r=e.stateNode;break;case 22:r=e.stateNode._retryCache;break;default:throw Error(i(314))}r!==null&&r.delete(t),gf(e,n)}function yf(e,t){return Ke(e,t)}var bf=null,xf=null,Sf=!1,Cf=!1,wf=!1,Tf=0;function Ef(e){e!==xf&&e.next===null&&(xf===null?bf=xf=e:xf=xf.next=e),Cf=!0,Sf||(Sf=!0,Nf())}function Df(e,t){if(!wf&&Cf){wf=!0;do for(var n=!1,r=bf;r!==null;){if(!t){if(e!==0){var i=r.pendingLanes;if(i===0)var a=0;else{var o=r.suspendedLanes,s=r.pingedLanes;a=(1<<31-ct(42|e)+1)-1,a&=i&~(o&~s),a=a&201326741?a&201326741|1:a?a|2:0}a!==0&&(n=!0,Mf(r,a))}else a=q,a=gt(r,r===G?a:0,r.cancelPendingCommit!==null||r.timeoutHandle!==-1),!(a&3)||_t(r,a)||(n=!0,Mf(r,a))}r=r.next}while(n);wf=!1}}function Of(){kf()}function kf(){Cf=Sf=!1;var e=0;Tf!==0&&hp()&&(e=Tf);for(var t=Xe(),n=null,r=bf;r!==null;){var i=r.next,a=Af(r,t);a===0?(r.next=null,n===null?bf=i:n.next=i,i===null&&(xf=n)):(n=r,(e!==0||a&3)&&(Cf=!0)),r=i}X!==0&&X!==5||Df(e,!1),Tf!==0&&(Tf=0)}function Af(e,t){for(var n=e.suspendedLanes,r=e.pingedLanes,i=e.expirationTimes,a=e.pendingLanes&-62914561;0<a;){var o=31-ct(a),s=1<<o,c=i[o];c===-1?((s&n)===0||(s&r)!==0)&&(i[o]=yt(s,t)):c<=t&&(e.expiredLanes|=s),a&=~s}if(t=G,n=q,n=gt(e,e===t?n:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),r=e.callbackNode,n===0||e===t&&(J===2||J===9)||e.cancelPendingCommit!==null)return r!==null&&r!==null&&qe(r),e.callbackNode=null,e.callbackPriority=0;if(!(n&3)||_t(e,n)){if(t=n&-n,t===e.callbackPriority)return t;switch(r!==null&&qe(r),Ot(n)){case 2:case 8:n=$e;break;case 32:n=et;break;case 268435456:n=nt;break;default:n=et}return r=jf.bind(null,e),n=Ke(n,r),e.callbackPriority=t,e.callbackNode=n,t}return r!==null&&r!==null&&qe(r),e.callbackPriority=2,e.callbackNode=null,2}function jf(e,t){if(X!==0&&X!==5)return e.callbackNode=null,e.callbackPriority=0,null;var n=e.callbackNode;if(df()&&e.callbackNode!==n)return null;var r=q;return r=gt(e,e===G?r:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),r===0?null:(Fd(e,r,t),Af(e,Xe()),e.callbackNode!=null&&e.callbackNode===n?jf.bind(null,e):null)}function Mf(e,t){if(df())return null;Fd(e,t,!0)}function Nf(){bp(function(){W&6?Ke(Qe,Of):kf()})}function Pf(){if(Tf===0){var e=Wa;e===0&&(e=ft,ft<<=1,!(ft&261888)&&(ft=256)),Tf=e}return Tf}function Ff(e){return e==null||typeof e==`symbol`||typeof e==`boolean`?null:typeof e==`function`?e:En(e)}function If(e,t,n,r,i){if(t===`submit`&&n&&n.stateNode===i){var a=Ff((i[Nt]||null).action),o=r.submitter;o&&(t=(t=o[Nt]||null)?Ff(t.formAction):o.getAttribute(`formAction`),t!==null&&(a=t,o=null));var s=new qn(`action`,`action`,null,r,i);e.push({event:s,listeners:[{instance:null,listener:function(){if(r.defaultPrevented){if(Tf!==0){var e=new FormData(i,o);rc(n,{pending:!0,data:e,method:i.method,action:a},null,e)}}else typeof a==`function`&&(s.preventDefault(),e=new FormData(i,o),rc(n,{pending:!0,data:e,method:i.method,action:a},a,e))},currentTarget:i}]})}}for(var Lf=0;Lf<xi.length;Lf++){var Rf=xi[Lf];Si(Rf.toLowerCase(),`on`+(Rf[0].toUpperCase()+Rf.slice(1)))}Si(pi,`onAnimationEnd`),Si(mi,`onAnimationIteration`),Si(hi,`onAnimationStart`),Si(`dblclick`,`onDoubleClick`),Si(`focusin`,`onFocus`),Si(`focusout`,`onBlur`),Si(gi,`onTransitionRun`),Si(_i,`onTransitionStart`),Si(vi,`onTransitionCancel`),Si(yi,`onTransitionEnd`),Xt(`onMouseEnter`,[`mouseout`,`mouseover`]),Xt(`onMouseLeave`,[`mouseout`,`mouseover`]),Xt(`onPointerEnter`,[`pointerout`,`pointerover`]),Xt(`onPointerLeave`,[`pointerout`,`pointerover`]),Yt(`onChange`,`change click focusin focusout input keydown keyup selectionchange`.split(` `)),Yt(`onSelect`,`focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange`.split(` `)),Yt(`onBeforeInput`,[`compositionend`,`keypress`,`textInput`,`paste`]),Yt(`onCompositionEnd`,`compositionend focusout keydown keypress keyup mousedown`.split(` `)),Yt(`onCompositionStart`,`compositionstart focusout keydown keypress keyup mousedown`.split(` `)),Yt(`onCompositionUpdate`,`compositionupdate focusout keydown keypress keyup mousedown`.split(` `));var zf=`abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting`.split(` `),Bf=new Set(`beforetoggle cancel close invalid load scroll scrollend toggle`.split(` `).concat(zf));function Vf(e,t){t=!!(t&4);for(var n=0;n<e.length;n++){var r=e[n],i=r.event;r=r.listeners;a:{var a=void 0;if(t)for(var o=r.length-1;0<=o;o--){var s=r[o],c=s.instance,l=s.currentTarget;if(s=s.listener,c!==a&&i.isPropagationStopped())break a;a=s,i.currentTarget=l;try{a(i)}catch(e){Di(e)}i.currentTarget=null,a=c}else for(o=0;o<r.length;o++){if(s=r[o],c=s.instance,l=s.currentTarget,s=s.listener,c!==a&&i.isPropagationStopped())break a;a=s,i.currentTarget=l;try{a(i)}catch(e){Di(e)}i.currentTarget=null,a=c}}}}function Q(e,t){var n=t[Ft];n===void 0&&(n=t[Ft]=new Set);var r=e+`__bubble`;n.has(r)||(Gf(t,e,2,!1),n.add(r))}function Hf(e,t,n){var r=0;t&&(r|=4),Gf(n,e,r,t)}var Uf=`_reactListening`+Math.random().toString(36).slice(2);function Wf(e){if(!e[Uf]){e[Uf]=!0,qt.forEach(function(t){t!==`selectionchange`&&(Bf.has(t)||Hf(t,!1,e),Hf(t,!0,e))});var t=e.nodeType===9?e:e.ownerDocument;t===null||t[Uf]||(t[Uf]=!0,Hf(`selectionchange`,!1,t))}}function Gf(e,t,n,r){switch(Ch(t)){case 2:var i=_h;break;case 8:i=vh;break;default:i=yh}n=i.bind(null,t,n,e),i=void 0,!In||t!==`touchstart`&&t!==`touchmove`&&t!==`wheel`||(i=!0),r?i===void 0?e.addEventListener(t,n,!0):e.addEventListener(t,n,{capture:!0,passive:i}):i===void 0?e.addEventListener(t,n,!1):e.addEventListener(t,n,{passive:i})}function Kf(e,t,n,r,i){var a=r;if(!(t&1)&&!(t&2)&&r!==null)a:for(;;){if(r===null)return;var s=r.tag;if(s===3||s===4){var c=r.stateNode.containerInfo;if(c===i)break;if(s===4)for(s=r.return;s!==null;){var l=s.tag;if((l===3||l===4)&&s.stateNode.containerInfo===i)return;s=s.return}for(;c!==null;){if(s=Ht(c),s===null)return;if(l=s.tag,l===5||l===6||l===26||l===27){r=a=s;continue a}c=c.parentNode}}r=r.return}Nn(function(){var r=a,i=kn(n),s=[];a:{var c=bi.get(e);if(c!==void 0){var l=qn,u=e;switch(e){case`keypress`:if(Hn(n)===0)break a;case`keydown`:case`keyup`:l=ur;break;case`focusin`:u=`focus`,l=nr;break;case`focusout`:u=`blur`,l=nr;break;case`beforeblur`:case`afterblur`:l=nr;break;case`click`:if(n.button===2)break a;case`auxclick`:case`dblclick`:case`mousedown`:case`mousemove`:case`mouseup`:case`mouseout`:case`mouseover`:case`contextmenu`:l=er;break;case`drag`:case`dragend`:case`dragenter`:case`dragexit`:case`dragleave`:case`dragover`:case`dragstart`:case`drop`:l=tr;break;case`touchcancel`:case`touchend`:case`touchmove`:case`touchstart`:l=pr;break;case pi:case mi:case hi:l=rr;break;case yi:l=mr;break;case`scroll`:case`scrollend`:l=Yn;break;case`wheel`:l=hr;break;case`copy`:case`cut`:case`paste`:l=ir;break;case`gotpointercapture`:case`lostpointercapture`:case`pointercancel`:case`pointerdown`:case`pointermove`:case`pointerout`:case`pointerover`:case`pointerup`:l=dr;break;case`submit`:l=fr;break;case`toggle`:case`beforetoggle`:l=gr}var d=!!(t&4),f=!d&&(e===`scroll`||e===`scrollend`),p=d?c===null?null:c+`Capture`:c;d=[];for(var m=r,h;m!==null;){var g=m;if(h=g.stateNode,g=g.tag,g!==5&&g!==26&&g!==27||h===null||p===null||(g=Pn(m,p),g!=null&&d.push(qf(m,g,h))),f)break;m=m.return}0<d.length&&(c=new l(c,u,null,n,i),s.push({event:c,listeners:d}))}}if(!(t&7)){a:{if(l=e===`mouseover`||e===`pointerover`,c=e===`mouseout`||e===`pointerout`,l&&n!==On&&(u=n.relatedTarget||n.fromElement)&&(Ht(u)||u[Pt]))break a;(c||l)&&(u=i.window===i?i:(l=i.ownerDocument)?l.defaultView||l.parentWindow:window,c?(l=n.relatedTarget||n.toElement,c=r,l=l?Ht(l):null,l!==null&&(f=o(l),d=l.tag,l!==f||d!==5&&d!==27&&d!==6)&&(l=null)):(c=null,l=r),c!==l&&(d=er,g=`onMouseLeave`,p=`onMouseEnter`,m=`mouse`,(e===`pointerout`||e===`pointerover`)&&(d=dr,g=`onPointerLeave`,p=`onPointerEnter`,m=`pointer`),f=c==null?u:Wt(c),h=l==null?u:Wt(l),u=new d(g,m+`leave`,c,n,i),u.target=f,u.relatedTarget=h,g=null,Ht(i)===r&&(d=new d(p,m+`enter`,l,n,i),d.target=h,d.relatedTarget=f,g=d),f=g,d=c&&l?ie(c,l,Yf):null,c!==null&&Xf(s,u,c,d,!1),l!==null&&f!==null&&Xf(s,f,l,d,!0)))}a:{if(c=r?Wt(r):window,l=c.nodeName&&c.nodeName.toLowerCase(),l===`select`||l===`input`&&c.type===`file`)var _=Ir;else if(Ar(c)){if(Lr)_=Kr;else{_=Wr;var v=Ur}}else l=c.nodeName,!l||l.toLowerCase()!==`input`||c.type!==`checkbox`&&c.type!==`radio`?r&&Cn(r.elementType)&&(_=Ir):_=Gr;if(_&&=_(e,r)){jr(s,_,n,i);break a}v&&v(e,c,r)}switch(v=r?Wt(r):window,e){case`focusin`:(Ar(v)||v.contentEditable===`true`)&&(ri=v,ii=r,ai=null);break;case`focusout`:ai=ii=ri=null;break;case`mousedown`:oi=!0;break;case`contextmenu`:case`mouseup`:case`dragend`:oi=!1,si(s,n,i);break;case`selectionchange`:if(ni)break;case`keydown`:case`keyup`:si(s,n,i)}var y;if(vr)b:{switch(e){case`compositionstart`:var b=`onCompositionStart`;break b;case`compositionend`:b=`onCompositionEnd`;break b;case`compositionupdate`:b=`onCompositionUpdate`;break b}b=void 0}else Er?wr(e,n)&&(b=`onCompositionEnd`):e===`keydown`&&n.keyCode===229&&(b=`onCompositionStart`);b&&(xr&&n.locale!==`ko`&&(Er||b!==`onCompositionStart`?b===`onCompositionEnd`&&Er&&(y=Vn()):(Rn=i,zn=`value`in Rn?Rn.value:Rn.textContent,Er=!0)),v=Jf(r,b),0<v.length&&(b=new ar(b,e,null,n,i),s.push({event:b,listeners:v}),y?b.data=y:(y=Tr(n),y!==null&&(b.data=y)))),(y=br?Dr(e,n):Or(e,n))&&(b=Jf(r,`onBeforeInput`),0<b.length&&(v=new ar(`onBeforeInput`,`beforeinput`,null,n,i),s.push({event:v,listeners:b}),v.data=y)),If(s,e,r,n,i)}Vf(s,t)})}function qf(e,t,n){return{instance:e,listener:t,currentTarget:n}}function Jf(e,t){for(var n=t+`Capture`,r=[];e!==null;){var i=e,a=i.stateNode;if(i=i.tag,i!==5&&i!==26&&i!==27||a===null||(i=Pn(e,n),i!=null&&r.unshift(qf(e,i,a)),i=Pn(e,t),i!=null&&r.push(qf(e,i,a))),e.tag===3)return r;e=e.return}return[]}function Yf(e){if(e===null)return null;do e=e.return;while(e&&e.tag!==5&&e.tag!==27);return e||null}function Xf(e,t,n,r,i){for(var a=t._reactName,o=[];n!==null&&n!==r;){var s=n,c=s.alternate,l=s.stateNode;if(s=s.tag,c!==null&&c===r)break;s!==5&&s!==26&&s!==27||l===null||(c=l,i?(l=Pn(n,a),l!=null&&o.unshift(qf(n,l,c))):i||(l=Pn(n,a),l!=null&&o.push(qf(n,l,c)))),n=n.return}o.length!==0&&e.push({event:t,listeners:o})}var Zf=/\r\n?/g,Qf=/\u0000|\uFFFD/g;function $f(e){return(typeof e==`string`?e:``+e).replace(Zf,`
`).replace(Qf,``)}function ep(e,t){return t=$f(t),$f(e)===t}function $(e,t,n,r,a,o){switch(n){case`children`:if(typeof r==`string`)t===`body`||t===`textarea`&&r===``||yn(e,r);else if(typeof r==`number`||typeof r==`bigint`)t!==`body`&&yn(e,``+r);else return;break;case`className`:rn(e,`class`,r);break;case`tabIndex`:rn(e,`tabindex`,r);break;case`dir`:case`role`:case`viewBox`:case`width`:case`height`:rn(e,n,r);break;case`style`:Sn(e,r,o);return;case`data`:if(t!==`object`){rn(e,`data`,r);break}case`src`:case`href`:if(r===``&&(t!==`a`||n!==`href`)){e.removeAttribute(n);break}if(r==null||typeof r==`function`||typeof r==`symbol`||typeof r==`boolean`){e.removeAttribute(n);break}r=En(r),e.setAttribute(n,r);break;case`action`:case`formAction`:if(typeof r==`function`){e.setAttribute(n,`javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')`);break}if(typeof o==`function`&&(n===`formAction`?(t!==`input`&&$(e,t,`name`,a.name,a,null),$(e,t,`formEncType`,a.formEncType,a,null),$(e,t,`formMethod`,a.formMethod,a,null),$(e,t,`formTarget`,a.formTarget,a,null)):($(e,t,`encType`,a.encType,a,null),$(e,t,`method`,a.method,a,null),$(e,t,`target`,a.target,a,null))),r==null||typeof r==`symbol`||typeof r==`boolean`){e.removeAttribute(n);break}r=En(r),e.setAttribute(n,r);break;case`onClick`:r!=null&&(e.onclick=Dn);return;case`onScroll`:r!=null&&Q(`scroll`,e);return;case`onScrollEnd`:r!=null&&Q(`scrollend`,e);return;case`dangerouslySetInnerHTML`:if(r!=null){if(typeof r!=`object`||!(`__html`in r))throw Error(i(61));if(n=r.__html,n!=null){if(a.children!=null)throw Error(i(60));o?.__html!==n&&(e.innerHTML=n)}}break;case`multiple`:e.multiple=r&&typeof r!=`function`&&typeof r!=`symbol`;break;case`muted`:e.muted=r&&typeof r!=`function`&&typeof r!=`symbol`;break;case`suppressContentEditableWarning`:case`suppressHydrationWarning`:case`defaultValue`:case`defaultChecked`:case`innerHTML`:case`ref`:break;case`autoFocus`:break;case`xlinkHref`:if(r==null||typeof r==`function`||typeof r==`boolean`||typeof r==`symbol`){e.removeAttribute(`xlink:href`);break}n=En(r),e.setAttributeNS(`http://www.w3.org/1999/xlink`,`xlink:href`,n);break;case`contentEditable`:case`spellCheck`:case`draggable`:case`value`:case`autoReverse`:case`externalResourcesRequired`:case`focusable`:case`preserveAlpha`:r!=null&&typeof r!=`function`&&typeof r!=`symbol`?e.setAttribute(n,r):e.removeAttribute(n);break;case`inert`:case`allowFullScreen`:case`async`:case`autoPlay`:case`controls`:case`credentialless`:case`default`:case`defer`:case`disabled`:case`disablePictureInPicture`:case`disableRemotePlayback`:case`formNoValidate`:case`hidden`:case`loop`:case`noModule`:case`noValidate`:case`open`:case`playsInline`:case`readOnly`:case`required`:case`reversed`:case`scoped`:case`seamless`:case`itemScope`:r&&typeof r!=`function`&&typeof r!=`symbol`?e.setAttribute(n,``):e.removeAttribute(n);break;case`capture`:case`download`:!0===r?e.setAttribute(n,``):!1!==r&&r!=null&&typeof r!=`function`&&typeof r!=`symbol`?e.setAttribute(n,r):e.removeAttribute(n);break;case`cols`:case`rows`:case`size`:case`span`:r!=null&&typeof r!=`function`&&typeof r!=`symbol`&&!isNaN(r)&&1<=r?e.setAttribute(n,r):e.removeAttribute(n);break;case`rowSpan`:case`start`:r==null||typeof r==`function`||typeof r==`symbol`||isNaN(r)?e.removeAttribute(n):e.setAttribute(n,r);break;case`popover`:Q(`beforetoggle`,e),Q(`toggle`,e),nn(e,`popover`,r);break;case`xlinkActuate`:an(e,`http://www.w3.org/1999/xlink`,`xlink:actuate`,r);break;case`xlinkArcrole`:an(e,`http://www.w3.org/1999/xlink`,`xlink:arcrole`,r);break;case`xlinkRole`:an(e,`http://www.w3.org/1999/xlink`,`xlink:role`,r);break;case`xlinkShow`:an(e,`http://www.w3.org/1999/xlink`,`xlink:show`,r);break;case`xlinkTitle`:an(e,`http://www.w3.org/1999/xlink`,`xlink:title`,r);break;case`xlinkType`:an(e,`http://www.w3.org/1999/xlink`,`xlink:type`,r);break;case`xmlBase`:an(e,`http://www.w3.org/XML/1998/namespace`,`xml:base`,r);break;case`xmlLang`:an(e,`http://www.w3.org/XML/1998/namespace`,`xml:lang`,r);break;case`xmlSpace`:an(e,`http://www.w3.org/XML/1998/namespace`,`xml:space`,r);break;case`is`:nn(e,`is`,r);break;case`innerText`:case`textContent`:return;default:if(!(2<n.length)||n[0]!==`o`&&n[0]!==`O`||n[1]!==`n`&&n[1]!==`N`)n=wn.get(n)||n,nn(e,n,r);else return}A=!0}function tp(e,t,n,r,a,o){switch(n){case`style`:Sn(e,r,o);return;case`dangerouslySetInnerHTML`:if(r!=null){if(typeof r!=`object`||!(`__html`in r))throw Error(i(61));if(n=r.__html,n!=null){if(a.children!=null)throw Error(i(60));o?.__html!==n&&(e.innerHTML=n)}}break;case`children`:if(typeof r==`string`)yn(e,r);else if(typeof r==`number`||typeof r==`bigint`)yn(e,``+r);else return;break;case`onScroll`:r!=null&&Q(`scroll`,e);return;case`onScrollEnd`:r!=null&&Q(`scrollend`,e);return;case`onClick`:r!=null&&(e.onclick=Dn);return;case`suppressContentEditableWarning`:case`suppressHydrationWarning`:case`innerHTML`:case`ref`:return;case`innerText`:case`textContent`:return;default:if(!Jt.hasOwnProperty(n))a:{if(n[0]===`o`&&n[1]===`n`&&(a=n.endsWith(`Capture`),o=n.slice(2,a?n.length-7:void 0),t=e[Nt]||null,t=t==null?null:t[n],typeof t==`function`&&e.removeEventListener(o,t,a),typeof r==`function`)){typeof t!=`function`&&t!==null&&(n in e?e[n]=null:e.hasAttribute(n)&&e.removeAttribute(n)),e.addEventListener(o,r,a);break a}A=!0,n in e?e[n]=r:!0===r?e.setAttribute(n,``):nn(e,n,r)}return}A=!0}function np(e,t,n){switch(t){case`div`:case`span`:case`svg`:case`path`:case`a`:case`g`:case`p`:case`li`:break;case`img`:Q(`error`,e),Q(`load`,e);var r=!1,a=!1,o;for(o in n)if(n.hasOwnProperty(o)){var s=n[o];if(s!=null)switch(o){case`src`:r=!0;break;case`srcSet`:a=!0;break;case`children`:case`dangerouslySetInnerHTML`:throw Error(i(137,t));default:$(e,t,o,s,n,null)}}a&&$(e,t,`srcSet`,n.srcSet,n,null),r&&$(e,t,`src`,n.src,n,null);return;case`input`:Q(`invalid`,e);var c=o=s=a=null,l=null,u=null;for(r in n)if(n.hasOwnProperty(r)){var d=n[r];if(d!=null)switch(r){case`name`:a=d;break;case`type`:s=d;break;case`checked`:l=d;break;case`defaultChecked`:u=d;break;case`value`:o=d;break;case`defaultValue`:c=d;break;case`children`:case`dangerouslySetInnerHTML`:if(d!=null)throw Error(i(137,t));break;default:$(e,t,r,d,n,null)}}mn(e,o,c,l,u,s,a,!1);return;case`select`:for(a in Q(`invalid`,e),r=s=o=null,n)if(n.hasOwnProperty(a)&&(c=n[a],c!=null))switch(a){case`value`:o=c;break;case`defaultValue`:s=c;break;case`multiple`:r=c;default:$(e,t,a,c,n,null)}t=o,n=s,e.multiple=!!r,t==null?n!=null&&gn(e,!!r,n,!0):gn(e,!!r,t,!1);return;case`textarea`:for(s in Q(`invalid`,e),o=a=r=null,n)if(n.hasOwnProperty(s)&&(c=n[s],c!=null))switch(s){case`value`:r=c;break;case`defaultValue`:a=c;break;case`children`:o=c;break;case`dangerouslySetInnerHTML`:if(c!=null)throw Error(i(91));break;default:$(e,t,s,c,n,null)}vn(e,r,a,o);return;case`option`:for(l in n)if(n.hasOwnProperty(l)&&(r=n[l],r!=null))switch(l){case`selected`:e.selected=r&&typeof r!=`function`&&typeof r!=`symbol`;break;default:$(e,t,l,r,n,null)}return;case`dialog`:Q(`beforetoggle`,e),Q(`toggle`,e),Q(`cancel`,e),Q(`close`,e);break;case`iframe`:case`object`:Q(`load`,e);break;case`video`:case`audio`:for(r=0;r<zf.length;r++)Q(zf[r],e);break;case`image`:Q(`error`,e),Q(`load`,e);break;case`details`:Q(`toggle`,e);break;case`embed`:case`source`:case`link`:Q(`error`,e),Q(`load`,e);case`area`:case`base`:case`br`:case`col`:case`hr`:case`keygen`:case`meta`:case`param`:case`track`:case`wbr`:case`menuitem`:for(u in n)if(n.hasOwnProperty(u)&&(r=n[u],r!=null))switch(u){case`children`:case`dangerouslySetInnerHTML`:throw Error(i(137,t));default:$(e,t,u,r,n,null)}return;default:if(Cn(t)){for(d in n)n.hasOwnProperty(d)&&(r=n[d],r!==void 0&&tp(e,t,d,r,n,void 0));return}}for(c in n)n.hasOwnProperty(c)&&(r=n[c],r!=null&&$(e,t,c,r,n,null))}var rp={};function ip(e,t,n,r){switch(t){case`div`:case`span`:case`svg`:case`path`:case`a`:case`g`:case`p`:case`li`:break;case`input`:var a=null,o=null,s=null,c=null,l=null,u=null,d=null;for(m in n){var f=n[m];if(n.hasOwnProperty(m)&&f!=null)switch(m){case`checked`:break;case`value`:break;case`defaultValue`:l=f;default:r.hasOwnProperty(m)||$(e,t,m,null,r,f)}}for(var p in r){var m=r[p];if(f=n[p],r.hasOwnProperty(p)&&(m!=null||f!=null))switch(p){case`type`:m!==f&&(A=!0),o=m;break;case`name`:m!==f&&(A=!0),a=m;break;case`checked`:m!==f&&(A=!0),u=m;break;case`defaultChecked`:m!==f&&(A=!0),d=m;break;case`value`:m!==f&&(A=!0),s=m;break;case`defaultValue`:m!==f&&(A=!0),c=m;break;case`children`:case`dangerouslySetInnerHTML`:if(m!=null)throw Error(i(137,t));break;default:m!==f&&$(e,t,p,m,r,f)}}pn(e,s,c,l,u,d,o,a);return;case`select`:for(o in m=s=c=p=null,n)if(l=n[o],n.hasOwnProperty(o)&&l!=null)switch(o){case`value`:break;case`multiple`:m=l;default:r.hasOwnProperty(o)||$(e,t,o,null,r,l)}for(a in r)if(o=r[a],l=n[a],r.hasOwnProperty(a)&&(o!=null||l!=null))switch(a){case`value`:o!==l&&(A=!0),p=o;break;case`defaultValue`:o!==l&&(A=!0),c=o;break;case`multiple`:o!==l&&(A=!0),s=o;default:o!==l&&$(e,t,a,o,r,l)}t=c,n=s,r=m,p==null?!!r!=!!n&&(t==null?gn(e,!!n,n?[]:``,!1):gn(e,!!n,t,!0)):gn(e,!!n,p,!1);return;case`textarea`:for(c in m=p=null,n)if(a=n[c],n.hasOwnProperty(c)&&a!=null&&!r.hasOwnProperty(c))switch(c){case`value`:break;case`children`:break;default:$(e,t,c,null,r,a)}for(s in r)if(a=r[s],o=n[s],r.hasOwnProperty(s)&&(a!=null||o!=null))switch(s){case`value`:a!==o&&(A=!0),p=a;break;case`defaultValue`:a!==o&&(A=!0),m=a;break;case`children`:break;case`dangerouslySetInnerHTML`:if(a!=null)throw Error(i(91));break;default:a!==o&&$(e,t,s,a,r,o)}_n(e,p,m);return;case`option`:for(var h in n)if(p=n[h],n.hasOwnProperty(h)&&p!=null&&!r.hasOwnProperty(h))switch(h){case`selected`:e.selected=!1;break;default:$(e,t,h,null,r,p)}for(l in r)if(p=r[l],m=n[l],r.hasOwnProperty(l)&&p!==m&&(p!=null||m!=null))switch(l){case`selected`:p!==m&&(A=!0),e.selected=p&&typeof p!=`function`&&typeof p!=`symbol`;break;default:$(e,t,l,p,r,m)}return;case`img`:case`link`:case`area`:case`base`:case`br`:case`col`:case`embed`:case`hr`:case`keygen`:case`meta`:case`param`:case`source`:case`track`:case`wbr`:case`menuitem`:for(var g in n)p=n[g],n.hasOwnProperty(g)&&p!=null&&!r.hasOwnProperty(g)&&$(e,t,g,null,r,p);for(u in r)if(p=r[u],m=n[u],r.hasOwnProperty(u)&&p!==m&&(p!=null||m!=null))switch(u){case`children`:case`dangerouslySetInnerHTML`:if(p!=null)throw Error(i(137,t));break;default:$(e,t,u,p,r,m)}return;default:if(Cn(t)){for(var _ in n)p=n[_],n.hasOwnProperty(_)&&p!==void 0&&!r.hasOwnProperty(_)&&tp(e,t,_,void 0,r,p);for(d in r)p=r[d],m=n[d],!r.hasOwnProperty(d)||p===m||p===void 0&&m===void 0||tp(e,t,d,p,r,m);return}}for(var v in n)p=n[v],n.hasOwnProperty(v)&&p!=null&&!r.hasOwnProperty(v)&&$(e,t,v,null,r,p);for(f in r)p=r[f],m=n[f],!r.hasOwnProperty(f)||p===m||p==null&&m==null||$(e,t,f,p,r,m)}function ap(e){switch(e){case`css`:case`script`:case`font`:case`img`:case`image`:case`input`:case`link`:return!0;default:return!1}}function op(){if(typeof performance.getEntriesByType==`function`){for(var e=0,t=0,n=performance.getEntriesByType(`resource`),r=0;r<n.length;r++){var i=n[r],a=i.transferSize,o=i.initiatorType,s=i.duration;if(a&&s&&ap(o)){for(o=0,s=i.responseEnd,r+=1;r<n.length;r++){var c=n[r],l=c.startTime;if(l>s)break;var u=c.transferSize,d=c.initiatorType;u&&ap(d)&&(c=c.responseEnd,o+=u*(c<s?1:(s-l)/(c-l)))}if(--r,t+=8*(a+o)/(i.duration/1e3),e++,10<e)break}}if(0<e)return t/e/1e6}return navigator.connection&&(e=navigator.connection.downlink,typeof e==`number`)?e:5}var sp=null,cp=null;function lp(e){return e.nodeType===9?e:e.ownerDocument}function up(e){switch(e){case`http://www.w3.org/2000/svg`:return 1;case`http://www.w3.org/1998/Math/MathML`:return 2;default:return 0}}function dp(e,t){if(e===0)switch(t){case`svg`:return 1;case`math`:return 2;default:return 0}return e===1&&t===`foreignObject`?0:e}function fp(e,t,n,r){return n=lp(n).createElement(e),n[Mt]=r,n[Nt]=t,np(n,e,t),k(n),n}function pp(e,t){return e===`textarea`||e===`noscript`||typeof t.children==`string`||typeof t.children==`number`||typeof t.children==`bigint`||typeof t.dangerouslySetInnerHTML==`object`&&t.dangerouslySetInnerHTML!==null&&t.dangerouslySetInnerHTML.__html!=null}var mp=null;function hp(){var e=window.event;return e&&e.type===`popstate`?e!==mp&&(mp=e,!0):(mp=null,!1)}var gp=typeof setTimeout==`function`?setTimeout:void 0,_p=typeof clearTimeout==`function`?clearTimeout:void 0,vp=typeof Promise==`function`?Promise:void 0,yp=typeof requestAnimationFrame==`function`?requestAnimationFrame:gp,bp=typeof queueMicrotask==`function`?queueMicrotask:vp===void 0?gp:function(e){return vp.resolve(null).then(e).catch(xp)};function xp(e){setTimeout(function(){throw e})}function Sp(e){return e===`head`}function Cp(e,t){var n=t,r=0;do{var i=n.nextSibling;if(e.removeChild(n),i&&i.nodeType===8){if(n=i.data,n===`/$`||n===`/&`){if(r===0){e.removeChild(i),Hh(t);return}r--}else if(n===`$`||n===`$?`||n===`$~`||n===`$!`||n===`&`)r++;else if(n===`html`)_m(e.ownerDocument.documentElement);else if(n===`head`){n=e.ownerDocument.head,_m(n);for(var a=n.firstChild;a;){var o=a.nextSibling,s=a.nodeName;a[zt]||s===`SCRIPT`||s===`STYLE`||s===`LINK`&&a.rel.toLowerCase()===`stylesheet`||n.removeChild(a),a=o}}else n===`body`&&_m(e.ownerDocument.body)}n=i}while(n);Hh(t)}function wp(e,t){var n=e;e=0;do{var r=n.nextSibling;if(n.nodeType===1?t?(n._stashedDisplay=n.style.display,n.style.display=`none`):(n.style.display=n._stashedDisplay||``,n.getAttribute(`style`)===``&&n.removeAttribute(`style`)):n.nodeType===3&&(t?(n._stashedText=n.nodeValue,n.nodeValue=``):n.nodeValue=n._stashedText||``),r&&r.nodeType===8){if(n=r.data,n===`/$`){if(e===0)break;e--}else n!==`$`&&n!==`$?`&&n!==`$~`&&n!==`$!`||e++}n=r}while(n)}function Tp(e,t,n){if(t=CSS.escape(t)===t?t:`r-`+btoa(t).replace(/=/g,``),e.style.viewTransitionName=t,n!=null&&(e.style.viewTransitionClass=n),n=getComputedStyle(e),n.display===`inline`){if(t=e.getClientRects(),t.length===1)var r=1;else for(var i=r=0;i<t.length;i++){var a=t[i];0<a.width&&0<a.height&&r++}r===1&&(e=e.style,e.display=t.length===1?`inline-block`:`block`,e.marginTop=`-`+n.paddingTop,e.marginBottom=`-`+n.paddingBottom)}}function Ep(e,t){e=e.style,t=t.style;var n=t==null?null:t.hasOwnProperty(`viewTransitionName`)?t.viewTransitionName:t.hasOwnProperty(`view-transition-name`)?t[`view-transition-name`]:null;e.viewTransitionName=n==null||typeof n==`boolean`?``:(``+n).trim(),n=t==null?null:t.hasOwnProperty(`viewTransitionClass`)?t.viewTransitionClass:t.hasOwnProperty(`view-transition-class`)?t[`view-transition-class`]:null,e.viewTransitionClass=n==null||typeof n==`boolean`?``:(``+n).trim(),e.display===`inline-block`&&(t==null?e.display=e.margin=``:(n=t.display,e.display=n==null||typeof n==`boolean`?``:n,n=t.margin,n==null?(n=t.hasOwnProperty(`marginTop`)?t.marginTop:t[`margin-top`],e.marginTop=n==null||typeof n==`boolean`?``:n,t=t.hasOwnProperty(`marginBottom`)?t.marginBottom:t[`margin-bottom`],e.marginBottom=t==null||typeof t==`boolean`?``:t):e.margin=n))}function Dp(e,t,n){return n=n.ownerDocument.defaultView,{rect:e,abs:t.position===`absolute`||t.position===`fixed`,clip:t.clipPath!==`none`||t.overflow!==`visible`||t.filter!==`none`||t.mask!==`none`||t.mask!==`none`||t.borderRadius!==`0px`,view:0<=e.bottom&&0<=e.right&&e.top<=n.innerHeight&&e.left<=n.innerWidth}}function Op(e){return Dp(e.getBoundingClientRect(),getComputedStyle(e),e)}function kp(e){var t=e.getBoundingClientRect();t=new DOMRect(t.x+2e4,t.y+2e4,t.width,t.height);var n=getComputedStyle(e);return Dp(t,n,e)}function Ap(e){return e.documentElement.clientHeight}function jp(e){this.addEventListener(`load`,e),this.addEventListener(`error`,e)}function Mp(e,t,n,r,i,a,o,s,c){var l=t.nodeType===9?t:t.ownerDocument;try{var u=l.startViewTransition({update:function(){var t=l.defaultView,n=t.navigation&&t.navigation.transition,o=l.fonts.status;r();var s=[];if(o===`loaded`&&(Ap(l),l.fonts.status===`loading`&&s.push(l.fonts.ready)),o=s.length,e!==null)for(var c=e.suspenseyImages,u=0,d=0;d<c.length;d++){var f=c[d];if(!f.complete){var p=f.getBoundingClientRect();if(0<p.bottom&&0<p.right&&p.top<t.innerHeight&&p.left<t.innerWidth){if(u+=Xm(f),u>$m){s.length=o;break}f=new Promise(jp.bind(f)),s.push(f)}}}if(0<s.length)return t=Promise.race([Promise.all(s),new Promise(function(e){return setTimeout(e,500)})]).then(i,i),(n?Promise.allSettled([n.finished,t]):t).then(a,a);if(i(),n)return n.finished.then(a,a);a()},types:n});l.__reactViewTransition=u;var d=[];return u.ready.then(function(){for(var e=l.documentElement.getAnimations({subtree:!0}),t=0;t<e.length;t++){var n=e[t],r=n.effect,i=r.pseudoElement;if(i!=null&&i.startsWith(`::view-transition`)){d.push(n),n=r.getKeyframes();for(var a=i=void 0,s=!0,c=0;c<n.length;c++){var u=n[c],f=u.width;if(i===void 0)i=f;else if(i!==f){s=!1;break}if(f=u.height,a===void 0)a=f;else if(a!==f){s=!1;break}delete u.width,delete u.height,u.transform===`none`&&delete u.transform}s&&i!==void 0&&a!==void 0&&(r.setKeyframes(n),s=getComputedStyle(r.target,r.pseudoElement),s.width!==i||s.height!==a)&&(s=n[0],s.width=i,s.height=a,s=n[n.length-1],s.width=i,s.height=a,r.setKeyframes(n))}}o()},function(e){l.__reactViewTransition===u&&(l.__reactViewTransition=null);try{if(typeof e==`object`&&e)switch(e.name){case`InvalidStateError`:(e.message===`View transition was skipped because document visibility state is hidden.`||e.message===`Skipping view transition because document visibility state has become hidden.`||e.message===`Skipping view transition because viewport size changed.`||e.message===`Transition was aborted because of invalid state`)&&(e=null)}e!==null&&c(e)}finally{r(),i(),o()}}),u.finished.finally(function(){for(var e=0;e<d.length;e++)d[e].cancel();l.__reactViewTransition===u&&(l.__reactViewTransition=null),s()}),u}catch{return r(),i(),o(),null}}function Np(e,t){this._scope=document.documentElement,this._selector=`::view-transition-`+e+`(`+t+`)`}Np.prototype.animate=function(e,t){return t=typeof t==`number`?{duration:t}:S({},t),t.pseudoElement=this._selector,this._scope.animate(e,t)},Np.prototype.getAnimations=function(){for(var e=this._scope,t=this._selector,n=e.getAnimations({subtree:!0}),r=[],i=0;i<n.length;i++){var a=n[i].effect;a!==null&&a.target===e&&a.pseudoElement===t&&r.push(n[i])}return r},Np.prototype.getComputedStyle=function(){return getComputedStyle(this._scope,this._selector)};function Pp(e){return{name:e,group:new Np(`group`,e),imagePair:new Np(`image-pair`,e),old:new Np(`old`,e),new:new Np(`new`,e)}}function Fp(e){this._fragmentFiber=e,this._observers=this._eventListeners=null}Fp.prototype.addEventListener=function(e,t,n){var r=null,i=null;if(!(n!=null&&typeof n!=`boolean`&&(r=n.signal||null,r!==null&&r.aborted))){this._eventListeners===null&&(this._eventListeners=[]);var a=this._eventListeners;if(Bp(a,e,t,n)===-1){var o=this,s=t;n!=null&&typeof n!=`boolean`&&!0===n.once&&(s=function(r){o.removeEventListener(e,t,n),typeof t==`function`?t.call(this,r):t.handleEvent(r)}),r!==null&&(i=o.removeEventListener.bind(o,e,t,n),r.addEventListener(`abort`,i,{once:!0}),i=r.removeEventListener.bind(r,`abort`,i)),r=Rp(n),a.push({type:e,listener:t,optionsOrUseCapture:n,attachedListener:s,cleanup:i}),h(this._fragmentFiber.child,!1,Ip,e,s,r)}this._eventListeners=a}};function Ip(e,t,n,r){return b(e).addEventListener(t,n,r),!1}Fp.prototype.removeEventListener=function(e,t,n){var r=this._eventListeners;if(r!==null&&(t=Bp(r,e,t,n),t!==-1)){var i=r[t];n=i.attachedListener;var a=i.cleanup;i=Rp(i.optionsOrUseCapture),h(this._fragmentFiber.child,!1,Lp,e,n,i),r.splice(t,1),a!==null&&a()}};function Lp(e,t,n,r){return b(e).removeEventListener(t,n,r),!1}function Rp(e){return e!=null&&typeof e!=`boolean`&&(!0===e.once||e.signal instanceof AbortSignal)?{capture:e.capture,passive:e.passive}:e}function zp(e){return e==null?`c=0`:typeof e==`boolean`?`c=`+(e?`1`:`0`):`c=`+(e.capture?`1`:`0`)}function Bp(e,t,n,r){if(e.length===0)return-1;r=zp(r);for(var i=0;i<e.length;i++){var a=e[i];if(a.type===t&&a.listener===n&&zp(a.optionsOrUseCapture)===r)return i}return-1}Fp.prototype.dispatchEvent=function(e){var t=g(this._fragmentFiber);if(t===null)return!0;t=b(t);var n=this._eventListeners;if(n!==null&&0<n.length||!e.bubbles){var r=t.nodeType===9?t.createComment(``):document.createTextNode(``);if(n)for(var i=0;i<n.length;i++){var a=n[i];r.addEventListener(a.type,a.attachedListener,Rp(a.optionsOrUseCapture))}if(t.appendChild(r),e=r.dispatchEvent(e),n)for(i=0;i<n.length;i++)a=n[i],r.removeEventListener(a.type,a.attachedListener,Rp(a.optionsOrUseCapture));return t.removeChild(r),e}return t.dispatchEvent(e)},Fp.prototype.focus=function(e){h(this._fragmentFiber.child,!0,Vp,e,void 0,void 0)};function Vp(e,t){return e.tag!==6&&(e=b(e),pm(e,t))}Fp.prototype.focusLast=function(e){var t=[];h(this._fragmentFiber.child,!0,Hp,t,void 0,void 0);for(var n=t.length-1;0<=n&&!Vp(t[n],e);n--);};function Hp(e,t){return t.push(e),!1}Fp.prototype.blur=function(){var e=g(this._fragmentFiber);e!==null&&(e=b(e),e=lp(e).activeElement,e!==null&&h(this._fragmentFiber.child,!1,Up,e,void 0,void 0))};function Up(e,t){return e.tag!==6&&(e=b(e),e===t||e.contains(t)?(t.blur(),!0):!1)}Fp.prototype.observeUsing=function(e){this._observers===null&&(this._observers=new Set),this._observers.add(e),h(this._fragmentFiber.child,!1,Wp,e,void 0,void 0)};function Wp(e,t){return e.tag!==6&&(e=b(e),t.observe(e),!1)}Fp.prototype.unobserveUsing=function(e){var t=this._observers;if(t!==null&&t.has(e)){t.delete(e),h(this._fragmentFiber.child,!1,Gp,e,void 0,void 0);for(var n=t=0;n<Kp.length;n++){var r=Kp[n];r.fragmentInstance===this&&r.observer===e?e.unobserve(r.instance):Kp[t++]=r}Kp.length=t}};function Gp(e,t){return e.tag!==6&&(e=b(e),t.unobserve(e),!1)}var Kp=[],qp=!1;function Jp(e,t,n){Kp.push({fragmentInstance:e,observer:t,instance:n}),qp||(qp=!0,mm(function(){qp=!1;var e=Kp;Kp=[];for(var t=0;t<e.length;t++){var n=e[t];n.observer.unobserve(n.instance)}}))}Fp.prototype.getClientRects=function(){var e=[];return h(this._fragmentFiber.child,!1,Yp,e,void 0,void 0),e};function Yp(e,t){if(e.tag===6){e=e.stateNode;var n=e.ownerDocument.createRange();n.selectNodeContents(e),t.push.apply(t,n.getClientRects())}else e=b(e),t.push.apply(t,e.getClientRects());return!1}Fp.prototype.getRootNode=function(e){var t=g(this._fragmentFiber);return t===null?this:b(t).getRootNode(e)},Fp.prototype.compareDocumentPosition=function(e){var t=g(this._fragmentFiber);if(t===null)return Node.DOCUMENT_POSITION_DISCONNECTED;var n=[];h(this._fragmentFiber.child,!1,Hp,n,void 0,void 0);var r=b(t);if(n.length===0){if(n=r,_(this._fragmentFiber)){a:{for(t=this._fragmentFiber.return;t!==null;){if(t.tag===4){t=t.stateNode.containerInfo;break a}if(t.tag===3||t.tag===5||t.tag===27)break;t=t.return}t=null}t!=null&&(n=t)}t=this._fragmentFiber;var i=r=n.compareDocumentPosition(e);return n===e?i=Node.DOCUMENT_POSITION_CONTAINS:r&Node.DOCUMENT_POSITION_CONTAINED_BY&&(n=v(t)[1],n===null?i=Node.DOCUMENT_POSITION_PRECEDING:(e=b(n).compareDocumentPosition(e),i=e===0||e&Node.DOCUMENT_POSITION_FOLLOWING?Node.DOCUMENT_POSITION_FOLLOWING:Node.DOCUMENT_POSITION_PRECEDING)),i|=Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC}t=b(n[0]),i=b(n[n.length-1]);var a=_(this._fragmentFiber)?t.parentElement:r;if(a==null)return Node.DOCUMENT_POSITION_DISCONNECTED;r=a.compareDocumentPosition(t)&Node.DOCUMENT_POSITION_CONTAINED_BY,a=a.compareDocumentPosition(i)&Node.DOCUMENT_POSITION_CONTAINED_BY;var o=t.compareDocumentPosition(e),s=i.compareDocumentPosition(e),c=o&Node.DOCUMENT_POSITION_CONTAINED_BY||s&Node.DOCUMENT_POSITION_CONTAINED_BY;return s=r&&a&&o&Node.DOCUMENT_POSITION_FOLLOWING&&s&Node.DOCUMENT_POSITION_PRECEDING,t=r&&t===e||a&&i===e||c||s?Node.DOCUMENT_POSITION_CONTAINED_BY:!r&&t===e||!a&&i===e?Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC:o,t&Node.DOCUMENT_POSITION_DISCONNECTED||t&Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC||Xp(t,this._fragmentFiber,n[0],n[n.length-1],e)?t:Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC};function Xp(e,t,n,r,i){var a=Ht(i);if(e&Node.DOCUMENT_POSITION_CONTAINED_BY){if(n=!!a)a:{for(;a!==null;){if(a.tag===7&&(a===t||a.alternate===t)){n=!0;break a}a=a.return}n=!1}return n}if(e&Node.DOCUMENT_POSITION_CONTAINS){if(a===null)return a=i.ownerDocument,i===a||i===a.documentElement||i===a.body;a:{for(a=t,t=g(t);a!==null;){if(!(a.tag!==5&&a.tag!==3&&a.tag!==27||a!==t&&a.alternate!==t)){a=!0;break a}a=a.return}a=!1}return a}return e&Node.DOCUMENT_POSITION_PRECEDING?((t=!!a)&&!(t=a===n)&&(t=ie(n,a,x),t===null?t=!1:(h(t,!0,ne,a,n),a=ee,ee=null,t=a!==null)),t):e&Node.DOCUMENT_POSITION_FOLLOWING?((t=!!a)&&!(t=a===r)&&(t=ie(r,a,x),t===null?t=!1:(h(t,!0,re,a,r),a=ee,te=ee=null,t=a!==null)),t):!1}function Zp(e,t){var n=e.ownerDocument.createRange();n.selectNodeContents(e),e=n.getBoundingClientRect(),window.scrollTo(window.scrollX+e.left,t?window.scrollY+e.top:window.scrollY+e.bottom-window.innerHeight)}Fp.prototype.scrollIntoView=function(e){if(typeof e==`object`)throw Error(i(566));var t=[];h(this._fragmentFiber.child,!1,Hp,t,void 0,void 0);var n=!1!==e;if(t.length===0){var r=v(this._fragmentFiber);if(r=n?r[1]||r[0]||g(this._fragmentFiber):r[0]||r[1],r===null)return;if(r.tag===6){e=b(r),Zp(e,n);return}if(r=b(r),r.nodeType!==9){if(r.nodeType===11){n=`host`in r?r.host:null,n!==null&&n.scrollIntoView(e);return}r.scrollIntoView(e)}}for(r=n?t.length-1:0;r!==(n?-1:t.length);){var a=t[r];a.tag===6?(a=b(a),Zp(a,n)):b(a).scrollIntoView(e),r+=n?-1:1}};function Qp(e,t){return e=b(e),$p(e,t),!1}function $p(e,t){e.reactFragments??=new Set,e.reactFragments.add(t)}function em(e,t){var n=t._eventListeners;if(n!==null)for(var r=0;r<n.length;r++){var i=n[r];e.addEventListener(i.type,i.attachedListener,Rp(i.optionsOrUseCapture))}e.nodeType!==3&&(n=t._observers,n!==null&&n.forEach(function(n){for(var r=0,i=0;i<Kp.length;i++){var a=Kp[i];(a.fragmentInstance!==t||a.observer!==n||a.instance!==e)&&(Kp[r++]=a)}Kp.length=r,n.observe(e)}),$p(e,t))}function tm(e,t){var n=t._eventListeners;if(n!==null)for(var r=0;r<n.length;r++){var i=n[r];e.removeEventListener(i.type,i.attachedListener,Rp(i.optionsOrUseCapture))}e.nodeType!==3&&(n=t._observers,n!==null&&n.forEach(function(n){typeof n.rootMargin==`string`?Jp(t,n,e):n.unobserve(e)}),e.reactFragments!=null&&e.reactFragments.delete(t))}function nm(e){var t=e.firstChild;for(t&&t.nodeType===10&&(t=t.nextSibling);t;){var n=t;switch(t=t.nextSibling,n.nodeName){case`HTML`:case`HEAD`:case`BODY`:nm(n),Vt(n);continue;case`SCRIPT`:case`STYLE`:continue;case`LINK`:if(n.rel.toLowerCase()===`stylesheet`)continue}e.removeChild(n)}}function rm(e,t,n,r){for(;e.nodeType===1;){var i=n;if(e.nodeName.toLowerCase()!==t.toLowerCase()){if(!r&&(e.nodeName!==`INPUT`||e.type!==`hidden`))break}else if(!r){if(t===`input`&&e.type===`hidden`){var a=i.name==null?null:``+i.name;if(i.type===`hidden`&&e.getAttribute(`name`)===a)return e}else return e}else if(!e[zt])switch(t){case`meta`:if(!e.hasAttribute(`itemprop`))break;return e;case`link`:if(a=e.getAttribute(`rel`),a===`stylesheet`&&e.hasAttribute(`data-precedence`)||a!==i.rel||e.getAttribute(`href`)!==(i.href==null||i.href===``?null:i.href)||e.getAttribute(`crossorigin`)!==(i.crossOrigin==null?null:i.crossOrigin)||e.getAttribute(`title`)!==(i.title==null?null:i.title))break;return e;case`style`:if(e.hasAttribute(`data-precedence`))break;return e;case`script`:if(a=e.getAttribute(`src`),(a!==(i.src==null?null:i.src)||e.getAttribute(`type`)!==(i.type==null?null:i.type)||e.getAttribute(`crossorigin`)!==(i.crossOrigin==null?null:i.crossOrigin))&&a&&e.hasAttribute(`async`)&&!e.hasAttribute(`itemprop`))break;return e;default:return e}if(e=lm(e.nextSibling),e===null)break}return null}function im(e,t,n){if(t===``)return null;for(;e.nodeType!==3;)if((e.nodeType!==1||e.nodeName!==`INPUT`||e.type!==`hidden`)&&!n||(e=lm(e.nextSibling),e===null))return null;return e}function am(e,t){for(;e.nodeType!==8;)if((e.nodeType!==1||e.nodeName!==`INPUT`||e.type!==`hidden`)&&!t||(e=lm(e.nextSibling),e===null))return null;return e}function om(e){return e.data===`$?`||e.data===`$~`}function sm(e){return e.data===`$!`||e.data===`$?`&&e.ownerDocument.readyState!==`loading`}function cm(e,t){var n=e.ownerDocument;if(e.data===`$~`)e._reactRetry=t;else if(e.data!==`$?`||n.readyState!==`loading`)t();else{var r=function(){t(),n.removeEventListener(`DOMContentLoaded`,r)};n.addEventListener(`DOMContentLoaded`,r),e._reactRetry=r}}function lm(e){for(;e!=null;e=e.nextSibling){var t=e.nodeType;if(t===1||t===3)break;if(t===8){if(t=e.data,t===`$`||t===`$!`||t===`$?`||t===`$~`||t===`&`||t===`F!`||t===`F`)break;if(t===`/$`||t===`/&`)return null}}return e}var um=null;function dm(e){e=e.nextSibling;for(var t=0;e;){if(e.nodeType===8){var n=e.data;if(n===`/$`||n===`/&`){if(t===0)return lm(e.nextSibling);t--}else n!==`$`&&n!==`$!`&&n!==`$?`&&n!==`$~`&&n!==`&`||t++}e=e.nextSibling}return null}function fm(e){e=e.previousSibling;for(var t=0;e;){if(e.nodeType===8){var n=e.data;if(n===`$`||n===`$!`||n===`$?`||n===`$~`||n===`&`){if(t===0)return e;t--}else n!==`/$`&&n!==`/&`||t++}e=e.previousSibling}return null}function pm(e,t){function n(){r=!0}if(e.ownerDocument.activeElement===e)return!0;var r=!1;try{e.ownerDocument.addEventListener(`focus`,n,!0),(e.focus||HTMLElement.prototype.focus).call(e,t)}finally{e.ownerDocument.removeEventListener(`focus`,n,!0)}return r}function mm(e){yp(function(){yp(function(t){return e(t)})})}function hm(e,t,n){switch(t=lp(n),e){case`html`:if(e=t.documentElement,!e)throw Error(i(452));return e;case`head`:if(e=t.head,!e)throw Error(i(453));return e;case`body`:if(e=t.body,!e)throw Error(i(454));return e;default:throw Error(i(451))}}function gm(e,t,n){for(var r in n){var i=n[r];n.hasOwnProperty(r)&&i!=null&&$(e,t,r,null,rp,i)}n.dangerouslySetInnerHTML!=null&&(e.textContent=``),e.onclick===Dn&&(e.onclick=null),Vt(e)}function _m(e){for(var t=e.attributes;t.length;)e.removeAttributeNode(t[0]);Vt(e)}var vm=new Map,ym=new Set;function bm(e){if(typeof e.getRootNode==`function`){var t=e.getRootNode();if(t.nodeType===9||t.nodeType===11)return t}return e.nodeType===9?e:e.ownerDocument}var xm=D.d;D.d={f:Sm,r:Cm,D:Em,C:Dm,L:Om,m:km,X:jm,S:Am,M:Mm};function Sm(){var e=xm.f(),t=zd();return e||t}function Cm(e){var t=Ut(e);t!==null&&t.tag===5&&t.type===`form`?ac(t):xm.r(e)}var wm=typeof document>`u`?null:document;function Tm(e,t,n){var r=wm;if(r&&typeof t==`string`&&t){var i=fn(t);i=`link[rel="`+e+`"][href="`+i+`"]`,typeof n==`string`&&(i+=`[crossorigin="`+n+`"]`),ym.has(i)||(ym.add(i),e={rel:e,crossOrigin:n,href:t},r.querySelector(i)===null&&(t=r.createElement(`link`),np(t,`link`,e),k(t),r.head.appendChild(t)))}}function Em(e){xm.D(e),Tm(`dns-prefetch`,e,null)}function Dm(e,t){xm.C(e,t),Tm(`preconnect`,e,t)}function Om(e,t,n){xm.L(e,t,n);var r=wm;if(r&&e&&t){var i=`link[rel="preload"][as="`+fn(t)+`"]`;t===`image`&&n&&n.imageSrcSet?(i+=`[imagesrcset="`+fn(n.imageSrcSet)+`"]`,typeof n.imageSizes==`string`&&(i+=`[imagesizes="`+fn(n.imageSizes)+`"]`)):i+=`[href="`+fn(e)+`"]`;var a=i;switch(t){case`style`:a=Pm(e);break;case`script`:a=Rm(e)}if(!(vm.has(a)||(e=S({rel:`preload`,href:t===`image`&&n&&n.imageSrcSet?void 0:e,as:t},n),vm.set(a,e),r.querySelector(i)!==null||t===`style`&&r.querySelector(Fm(a))||t===`script`&&r.querySelector(zm(a))))){var o=r.createElement(`link`);np(o,`link`,e),t===`style`&&(o[Bt]=!0,o.onload=o.onerror=function(){Kt(o)}),k(o),r.head.appendChild(o)}}}function km(e,t){xm.m(e,t);var n=wm;if(n&&e){var r=t&&typeof t.as==`string`?t.as:`script`,i=`link[rel="modulepreload"][as="`+fn(r)+`"][href="`+fn(e)+`"]`,a=i;switch(r){case`audioworklet`:case`paintworklet`:case`serviceworker`:case`sharedworker`:case`worker`:case`script`:a=Rm(e)}if(!vm.has(a)&&(e=S({rel:`modulepreload`,href:e},t),vm.set(a,e),n.querySelector(i)===null)){switch(r){case`audioworklet`:case`paintworklet`:case`serviceworker`:case`sharedworker`:case`worker`:case`script`:if(n.querySelector(zm(a)))return}r=n.createElement(`link`),np(r,`link`,e),k(r),n.head.appendChild(r)}}}function Am(e,t,n){xm.S(e,t,n);var r=wm;if(r&&e){var i=Gt(r).hoistableStyles,a=Pm(e);t||=`default`;var o=i.get(a);if(!o){var s={loading:0,preload:null};if(o=r.querySelector(Fm(a)))s.loading=5;else{e=S({rel:`stylesheet`,href:e,"data-precedence":t},n),(n=vm.get(a))&&Hm(e,n);var c=o=r.createElement(`link`);k(c),np(c,`link`,e),c._p=new Promise(function(e,t){c.onload=e,c.onerror=t}),c.addEventListener(`load`,function(){s.loading|=1}),c.addEventListener(`error`,function(){s.loading|=2}),s.loading|=4,Vm(o,t,r)}o={type:`stylesheet`,instance:o,count:1,state:s},i.set(a,o)}}}function jm(e,t){xm.X(e,t);var n=wm;if(n&&e){var r=Gt(n).hoistableScripts,i=Rm(e),a=r.get(i);a||(a=n.querySelector(zm(i)),a||(e=S({src:e,async:!0},t),(t=vm.get(i))&&Um(e,t),a=n.createElement(`script`),k(a),np(a,`link`,e),n.head.appendChild(a)),a={type:`script`,instance:a,count:1,state:null},r.set(i,a))}}function Mm(e,t){xm.M(e,t);var n=wm;if(n&&e){var r=Gt(n).hoistableScripts,i=Rm(e),a=r.get(i);a||(a=n.querySelector(zm(i)),a||(e=S({src:e,async:!0,type:`module`},t),(t=vm.get(i))&&Um(e,t),a=n.createElement(`script`),k(a),np(a,`link`,e),n.head.appendChild(a)),a={type:`script`,instance:a,count:1,state:null},r.set(i,a))}}function Nm(e,t,n,r){var a=(a=Me.current)?bm(a):null;if(!a)throw Error(i(446));switch(e){case`meta`:case`title`:return null;case`style`:return typeof n.precedence==`string`&&typeof n.href==`string`?(n=Pm(n.href),t=Gt(a).hoistableStyles,r=t.get(n),r||(r={type:`style`,instance:null,count:0,state:null},t.set(n,r)),r):{type:`void`,instance:null,count:0,state:null};case`link`:if(n.rel===`stylesheet`&&typeof n.href==`string`&&typeof n.precedence==`string`){e=Pm(n.href);var o=Gt(a).hoistableStyles,s=o.get(e);if(s||(a=a.ownerDocument||a,s={type:`stylesheet`,instance:null,count:0,state:{loading:0,preload:null}},o.set(e,s),(o=a.querySelector(Fm(e)))?o._p||(s.instance=o,s.state.loading=5):(o=vm.get(e),o||(o={rel:`preload`,as:`style`,href:n.href,crossOrigin:n.crossOrigin,integrity:n.integrity,media:n.media,hrefLang:n.hrefLang,referrerPolicy:n.referrerPolicy},vm.set(e,o)),Lm(a,e,o,s.state))),t&&r===null)throw Error(i(528,``));return s}if(t&&r!==null)throw Error(i(529,``));return null;case`script`:return t=n.async,n=n.src,typeof n==`string`&&t&&typeof t!=`function`&&typeof t!=`symbol`?(n=Rm(n),t=Gt(a).hoistableScripts,r=t.get(n),r||(r={type:`script`,instance:null,count:0,state:null},t.set(n,r)),r):{type:`void`,instance:null,count:0,state:null};default:throw Error(i(444,e))}}function Pm(e){return`href="`+fn(e)+`"`}function Fm(e){return`link[rel="stylesheet"][`+e+`]`}function Im(e){return S({},e,{"data-precedence":e.precedence,precedence:null})}function Lm(e,t,n,r){if(t=e.querySelector(`link[rel="preload"][as="style"][`+t+`]`)){if(!0!==t[Bt]){r.loading=1;return}}else t=e.createElement(`link`),t[Bt]=!0,t.onload=t.onerror=Kt.bind(null,t),np(t,`link`,n),k(t),e.head.appendChild(t);r.preload=t,t.addEventListener(`load`,function(){return r.loading|=1}),t.addEventListener(`error`,function(){return r.loading|=2})}function Rm(e){return`[src="`+fn(e)+`"]`}function zm(e){return`script[async]`+e}function Bm(e,t,n){if(t.count++,t.instance===null)switch(t.type){case`style`:var r=e.querySelector(`style[data-href~="`+fn(n.href)+`"]`);if(r)return t.instance=r,k(r),r;var a=S({},n,{"data-href":n.href,"data-precedence":n.precedence,href:null,precedence:null});return r=(e.ownerDocument||e).createElement(`style`),k(r),np(r,`style`,a),Vm(r,n.precedence,e),t.instance=r;case`stylesheet`:a=Pm(n.href);var o=e.querySelector(Fm(a));if(o)return t.state.loading|=4,t.instance=o,k(o),o;r=Im(n),(a=vm.get(a))&&Hm(r,a),o=(e.ownerDocument||e).createElement(`link`),k(o);var s=o;return s._p=new Promise(function(e,t){s.onload=e,s.onerror=t}),np(o,`link`,r),t.state.loading|=4,Vm(o,n.precedence,e),t.instance=o;case`script`:return o=Rm(n.src),(a=e.querySelector(zm(o)))?(t.instance=a,k(a),a):(r=n,(a=vm.get(o))&&(r=S({},n),Um(r,a)),e=e.ownerDocument||e,a=e.createElement(`script`),k(a),np(a,`link`,r),e.head.appendChild(a),t.instance=a);case`void`:return null;default:throw Error(i(443,t.type))}else t.type===`stylesheet`&&!(t.state.loading&4)&&(r=t.instance,t.state.loading|=4,Vm(r,n.precedence,e));return t.instance}function Vm(e,t,n){for(var r=n.querySelectorAll(`link[rel="stylesheet"][data-precedence],style[data-precedence]`),i=r.length?r[r.length-1]:null,a=i,o=0;o<r.length;o++){var s=r[o];if(s.dataset.precedence===t)a=s;else if(a!==i)break}a?a.parentNode.insertBefore(e,a.nextSibling):(t=n.nodeType===9?n.head:n,t.insertBefore(e,t.firstChild))}function Hm(e,t){e.crossOrigin??=t.crossOrigin,e.referrerPolicy??=t.referrerPolicy,e.title??=t.title}function Um(e,t){e.crossOrigin??=t.crossOrigin,e.referrerPolicy??=t.referrerPolicy,e.integrity??=t.integrity}var Wm=null;function Gm(e,t,n){if(Wm===null){var r=new Map,i=Wm=new Map;i.set(n,r)}else i=Wm,r=i.get(n),r||(r=new Map,i.set(n,r));if(r.has(e))return r;for(r.set(e,null),n=n.getElementsByTagName(e),i=0;i<n.length;i++){var a=n[i];if(!(a[zt]||a[Mt]||e===`link`&&a.getAttribute(`rel`)===`stylesheet`)&&a.namespaceURI!==`http://www.w3.org/2000/svg`){var o=a.getAttribute(t)||``;o=e+o;var s=r.get(o);s?s.push(a):r.set(o,[a])}}return r}function Km(e,t,n){e=e.ownerDocument||e,e.head.insertBefore(n,t===`title`?e.querySelector(`head > title`):null)}function qm(e,t,n){if(n===1||t.itemProp!=null)return!1;switch(e){case`meta`:case`title`:return!0;case`style`:if(typeof t.precedence!=`string`||typeof t.href!=`string`||t.href===``)break;return!0;case`link`:if(typeof t.rel!=`string`||typeof t.href!=`string`||t.href===``||t.onLoad||t.onError)break;switch(t.rel){case`stylesheet`:return e=t.disabled,typeof t.precedence==`string`&&e==null;default:return!0}case`script`:if(t.async&&typeof t.async!=`function`&&typeof t.async!=`symbol`&&!t.onLoad&&!t.onError&&t.src&&typeof t.src==`string`)return!0}return!1}function Jm(e,t){return e===`img`&&t.src!=null&&t.src!==``&&t.onLoad==null&&t.loading!==`lazy`}function Ym(e){return!(e.type===`stylesheet`&&!(e.state.loading&3))}function Xm(e){return(e.width||100)*(e.height||100)*(typeof devicePixelRatio==`number`?devicePixelRatio:1)*.25}function Zm(e,t){typeof t.decode==`function`&&(e.imgCount++,t.complete||(e.imgBytes+=Xm(t),e.suspenseyImages.push(t)),e=rh.bind(e),t.decode().then(e,e))}function Qm(e,t,n,r){if(n.type===`stylesheet`&&(typeof r.media!=`string`||!1!==matchMedia(r.media).matches)&&!(n.state.loading&4)){if(n.instance===null){var i=Pm(r.href),a=t.querySelector(Fm(i));if(a){t=a._p,typeof t==`object`&&t&&typeof t.then==`function`&&(e.count++,e=nh.bind(e),t.then(e,e)),n.state.loading|=4,n.instance=a,k(a);return}a=t.ownerDocument||t,r=Im(r),(i=vm.get(i))&&Hm(r,i),a=a.createElement(`link`),k(a);var o=a;o._p=new Promise(function(e,t){o.onload=e,o.onerror=t}),np(a,`link`,r),n.instance=a}e.stylesheets===null&&(e.stylesheets=new Map),e.stylesheets.set(n,t),(t=n.state.preload)&&!(n.state.loading&3)&&(e.count++,n=nh.bind(e),t.addEventListener(`load`,n),t.addEventListener(`error`,n))}}var $m=0;function eh(e,t){return e.stylesheets&&e.count===0&&ah(e,e.stylesheets),0<e.count||0<e.imgCount?function(n){var r=setTimeout(function(){if(e.stylesheets&&ah(e,e.stylesheets),e.unsuspend){var t=e.unsuspend;e.unsuspend=null,t()}},6e4+t);0<e.imgBytes&&$m===0&&($m=62500*op());var i=setTimeout(function(){if(e.waitingForImages=!1,e.count===0&&(e.stylesheets&&ah(e,e.stylesheets),e.unsuspend)){var t=e.unsuspend;e.unsuspend=null,t()}},(e.imgBytes>$m?50:800)+t);return e.unsuspend=n,function(){e.unsuspend=null,clearTimeout(r),clearTimeout(i)}}:null}function th(e){if(e.count===0&&(e.imgCount===0||!e.waitingForImages)){if(e.stylesheets)ah(e,e.stylesheets);else if(e.unsuspend){var t=e.unsuspend;e.unsuspend=null,t()}}}function nh(){this.count--,th(this)}function rh(){this.imgCount--,th(this)}var ih=null;function ah(e,t){e.stylesheets=null,e.unsuspend!==null&&(e.count++,ih=new Map,t.forEach(oh,e),ih=null,nh.call(e))}function oh(e,t){if(!(t.state.loading&4)){var n=ih.get(e);if(n)var r=n.get(null);else{n=new Map,ih.set(e,n);for(var i=e.querySelectorAll(`link[data-precedence],style[data-precedence]`),a=0;a<i.length;a++){var o=i[a];(o.nodeName===`LINK`||o.getAttribute(`media`)!==`not all`)&&(n.set(o.dataset.precedence,o),r=o)}r&&n.set(null,r)}i=t.instance,o=i.getAttribute(`data-precedence`),a=n.get(o)||r,a===r&&n.set(null,i),n.set(o,i),this.count++,r=nh.bind(this),i.addEventListener(`load`,r),i.addEventListener(`error`,r),a?a.parentNode.insertBefore(i,a.nextSibling):(e=e.nodeType===9?e.head:e,e.insertBefore(i,e.firstChild)),t.state.loading|=4}}var sh={$$typeof:T,Provider:null,Consumer:null,_currentValue:Te,_currentValue2:Te,_threadCount:0};function ch(e,t,n,r,i,a,o,s,c){this.tag=1,this.containerInfo=e,this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.next=this.pendingContext=this.context=this.cancelPendingCommit=null,this.callbackPriority=0,this.expirationTimes=xt(-1),this.entangledLanes=this.shellSuspendCounter=this.errorRecoveryDisabledLanes=this.expiredLanes=this.warmLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=xt(0),this.hiddenUpdates=xt(null),this.identifierPrefix=r,this.onUncaughtError=i,this.onCaughtError=a,this.onRecoverableError=o,this.pooledCache=null,this.pooledCacheLanes=0,this.formState=c,this.transitionTypes=null,this.incompleteTransitions=new Map}function lh(e,t,n,r,i,a,o,s,c,l,u,d){return e=new ch(e,t,n,o,c,l,u,d,s),t=1,!0===a&&(t|=24),a=zi(3,null,null,t),e.current=a,a.stateNode=e,t=La(),t.refCount++,e.pooledCache=t,t.refCount++,a.memoizedState={element:r,isDehydrated:n,cache:t},bo(a),e}function uh(e){return e?(e=Li,e):Li}function dh(e,t,n,r,i,a){i=uh(i),r.context===null?r.context=i:r.pendingContext=i,r=So(t),r.payload={element:n},a=a===void 0?null:a,a!==null&&(r.callback=a),n=Co(e,r,t),n!==null&&(Pd(n,e,t),wo(n,e,t))}function fh(e,t){if(e=e.memoizedState,e!==null&&e.dehydrated!==null){var n=e.retryLane;e.retryLane=n!==0&&n<t?n:t}}function ph(e,t){fh(e,t),(e=e.alternate)&&fh(e,t)}function mh(e){if(e.tag===13||e.tag===31){var t=Pi(e,67108864);t!==null&&Pd(t,e,67108864),ph(e,67108864)}}function hh(e){if(e.tag===13||e.tag===31){var t=jd();t=Dt(t);var n=Pi(e,t);n!==null&&Pd(n,e,t),ph(e,t)}}var gh=!0;function _h(e,t,n,r){var i=E.T;E.T=null;var a=D.p;try{D.p=2,yh(e,t,n,r)}finally{D.p=a,E.T=i}}function vh(e,t,n,r){var i=E.T;E.T=null;var a=D.p;try{D.p=8,yh(e,t,n,r)}finally{D.p=a,E.T=i}}function yh(e,t,n,r){if(gh){var i=bh(r);if(i===null)Kf(e,t,r,xh,n),Mh(e,r);else if(Ph(i,e,t,n,r))r.stopPropagation();else if(Mh(e,r),t&4&&-1<jh.indexOf(e)){for(;i!==null;){var a=Ut(i);if(a!==null)switch(a.tag){case 3:if(a=a.stateNode,a.current.memoizedState.isDehydrated){var o=ht(a.pendingLanes);if(o!==0){var s=a;for(s.pendingLanes|=2,s.entangledLanes|=2;o;){var c=1<<31-ct(o);s.entanglements[1]|=c,o&=~c}Ef(a),!(W&6)&&(_d=Xe()+500,Df(0,!1))}}break;case 31:case 13:s=Pi(a,2),s!==null&&Pd(s,a,2),zd(),ph(a,2)}if(a=bh(r),a===null&&Kf(e,t,r,xh,n),a===i)break;i=a}i!==null&&r.stopPropagation()}else Kf(e,t,r,null,n)}}function bh(e){return e=kn(e),Sh(e)}var xh=null;function Sh(e){if(xh=null,e=Ht(e),e!==null){var t=o(e);if(t===null)e=null;else{var n=t.tag;if(n===13){if(e=s(t),e!==null)return e;e=null}else if(n===31){if(e=c(t),e!==null)return e;e=null}else if(n===3){if(t.stateNode.current.memoizedState.isDehydrated)return t.tag===3?t.stateNode.containerInfo:null;e=null}else t!==e&&(e=null)}}return xh=e,null}function Ch(e){switch(e){case`beforetoggle`:case`cancel`:case`click`:case`close`:case`contextmenu`:case`copy`:case`cut`:case`auxclick`:case`dblclick`:case`dragend`:case`dragstart`:case`drop`:case`focusin`:case`focusout`:case`input`:case`invalid`:case`keydown`:case`keypress`:case`keyup`:case`mousedown`:case`mouseup`:case`paste`:case`pause`:case`play`:case`pointercancel`:case`pointerdown`:case`pointerup`:case`ratechange`:case`reset`:case`seeked`:case`submit`:case`toggle`:case`touchcancel`:case`touchend`:case`touchstart`:case`volumechange`:case`change`:case`selectionchange`:case`textInput`:case`compositionstart`:case`compositionend`:case`compositionupdate`:case`beforeblur`:case`afterblur`:case`beforeinput`:case`blur`:case`fullscreenchange`:case`fullscreenerror`:case`focus`:case`hashchange`:case`popstate`:case`select`:case`selectstart`:return 2;case`drag`:case`dragenter`:case`dragexit`:case`dragleave`:case`dragover`:case`mousemove`:case`mouseout`:case`mouseover`:case`pointermove`:case`pointerout`:case`pointerover`:case`resize`:case`scroll`:case`touchmove`:case`wheel`:case`mouseenter`:case`mouseleave`:case`pointerenter`:case`pointerleave`:return 8;case`message`:switch(Ze()){case Qe:return 2;case $e:return 8;case et:case tt:return 32;case nt:return 268435456;default:return 32}default:return 32}}var wh=!1,Th=null,Eh=null,Dh=null,Oh=new Map,kh=new Map,Ah=[],jh=`mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset`.split(` `);function Mh(e,t){switch(e){case`focusin`:case`focusout`:Th=null;break;case`dragenter`:case`dragleave`:Eh=null;break;case`mouseover`:case`mouseout`:Dh=null;break;case`pointerover`:case`pointerout`:Oh.delete(t.pointerId);break;case`gotpointercapture`:case`lostpointercapture`:kh.delete(t.pointerId)}}function Nh(e,t,n,r,i,a){return e===null||e.nativeEvent!==a?(e={blockedOn:t,domEventName:n,eventSystemFlags:r,nativeEvent:a,targetContainers:[i]},t!==null&&(t=Ut(t),t!==null&&mh(t)),e):(e.eventSystemFlags|=r,t=e.targetContainers,i!==null&&t.indexOf(i)===-1&&t.push(i),e)}function Ph(e,t,n,r,i){switch(t){case`focusin`:return Th=Nh(Th,e,t,n,r,i),!0;case`dragenter`:return Eh=Nh(Eh,e,t,n,r,i),!0;case`mouseover`:return Dh=Nh(Dh,e,t,n,r,i),!0;case`pointerover`:var a=i.pointerId;return Oh.set(a,Nh(Oh.get(a)||null,e,t,n,r,i)),!0;case`gotpointercapture`:return a=i.pointerId,kh.set(a,Nh(kh.get(a)||null,e,t,n,r,i)),!0}return!1}function Fh(e){var t=Ht(e.target);if(t!==null){var n=o(t);if(n!==null){if(t=n.tag,t===13){if(t=s(n),t!==null){e.blockedOn=t,At(e.priority,function(){hh(n)});return}}else if(t===31){if(t=c(n),t!==null){e.blockedOn=t,At(e.priority,function(){hh(n)});return}}else if(t===3&&n.stateNode.current.memoizedState.isDehydrated){e.blockedOn=n.tag===3?n.stateNode.containerInfo:null;return}}}e.blockedOn=null}function Ih(e){if(e.blockedOn!==null)return!1;for(var t=e.targetContainers;0<t.length;){var n=bh(e.nativeEvent);if(n===null){n=e.nativeEvent;var r=new n.constructor(n.type,n);On=r,n.target.dispatchEvent(r),On=null}else return t=Ut(n),t!==null&&mh(t),e.blockedOn=n,!1;t.shift()}return!0}function Lh(e,t,n){Ih(e)&&n.delete(t)}function Rh(){wh=!1,Th!==null&&Ih(Th)&&(Th=null),Eh!==null&&Ih(Eh)&&(Eh=null),Dh!==null&&Ih(Dh)&&(Dh=null),Oh.forEach(Lh),kh.forEach(Lh)}function zh(e,n){e.blockedOn===n&&(e.blockedOn=null,wh||(wh=!0,t.unstable_scheduleCallback(t.unstable_NormalPriority,Rh)))}var Bh=null;function Vh(e){Bh!==e&&(Bh=e,t.unstable_scheduleCallback(t.unstable_NormalPriority,function(){Bh===e&&(Bh=null);for(var t=0;t<e.length;t+=3){var n=e[t],r=e[t+1],i=e[t+2];if(typeof r!=`function`){if(Sh(r||n)===null)continue;break}var a=Ut(n);a!==null&&(e.splice(t,3),t-=3,rc(a,{pending:!0,data:i,method:n.method,action:r},r,i))}}))}function Hh(e){function t(t){return zh(t,e)}Th!==null&&zh(Th,e),Eh!==null&&zh(Eh,e),Dh!==null&&zh(Dh,e),Oh.forEach(t),kh.forEach(t);for(var n=0;n<Ah.length;n++){var r=Ah[n];r.blockedOn===e&&(r.blockedOn=null)}for(;0<Ah.length&&(n=Ah[0],n.blockedOn===null);)Fh(n),n.blockedOn===null&&Ah.shift();if(n=(e.ownerDocument||e).$$reactFormReplay,n!=null)for(r=0;r<n.length;r+=3){var i=n[r],a=n[r+1],o=i[Nt]||null;if(typeof a==`function`)o||Vh(n);else if(o){var s=null;if(a&&a.hasAttribute(`formAction`)){if(i=a,o=a[Nt]||null)s=o.formAction;else if(Sh(i)!==null)continue}else s=o.action;typeof s==`function`?n[r+1]=s:(n.splice(r,3),r-=3),Vh(n)}}}function Uh(){function e(e){e.canIntercept&&e.info===`react-transition`&&e.intercept({handler:function(){return new Promise(function(e){return i=e})},focusReset:`manual`,scroll:`manual`})}function t(){i!==null&&(i(),i=null),r||setTimeout(n,20)}function n(){if(!r&&!navigation.transition){var e=navigation.currentEntry;e&&e.url!=null&&navigation.navigate(e.url,{state:e.getState(),info:`react-transition`,history:`replace`})}}if(typeof navigation==`object`){var r=!1,i=null;return navigation.addEventListener(`navigate`,e),navigation.addEventListener(`navigatesuccess`,t),navigation.addEventListener(`navigateerror`,t),setTimeout(n,100),function(){r=!0,navigation.removeEventListener(`navigate`,e),navigation.removeEventListener(`navigatesuccess`,t),navigation.removeEventListener(`navigateerror`,t),i!==null&&(i(),i=null)}}}function Wh(e){this._internalRoot=e}Gh.prototype.render=Wh.prototype.render=function(e){var t=this._internalRoot;if(t===null)throw Error(i(409));var n=t.current;dh(n,jd(),e,t,null,null)},Gh.prototype.unmount=Wh.prototype.unmount=function(){var e=this._internalRoot;if(e!==null){this._internalRoot=null;var t=e.containerInfo;dh(e.current,2,null,e,null,null),zd(),t[Pt]=null}};function Gh(e){this._internalRoot=e}Gh.prototype.unstable_scheduleHydration=function(e){if(e){var t=kt();e={blockedOn:null,target:e,priority:t};for(var n=0;n<Ah.length&&t!==0&&t<Ah[n].priority;n++);Ah.splice(n,0,e),n===0&&Fh(e)}};var Kh=n.version;if(Kh!==`19.3.0`)throw Error(i(527,Kh,`19.3.0`));D.findDOMNode=function(e){var t=e._reactInternals;if(t===void 0)throw typeof e.render==`function`?Error(i(188)):(e=Object.keys(e).join(`,`),Error(i(268,e)));return e=d(t),e=e===null?null:p(e),e=e===null?null:e.stateNode,e};var qh={bundleType:0,version:`19.3.0`,rendererPackageName:`react-dom`,currentDispatcherRef:E,reconcilerVersion:`19.3.0`};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<`u`){var Jh=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!Jh.isDisabled&&Jh.supportsFiber)try{at=Jh.inject(qh),ot=Jh}catch{}}e.createRoot=function(e,t){if(!a(e))throw Error(i(299));var n=!1,r=``,o=Ec,s=Dc,c=Oc;return t!=null&&(!0===t.unstable_strictMode&&(n=!0),t.identifierPrefix!==void 0&&(r=t.identifierPrefix),t.onUncaughtError!==void 0&&(o=t.onUncaughtError),t.onCaughtError!==void 0&&(s=t.onCaughtError),t.onRecoverableError!==void 0&&(c=t.onRecoverableError)),t=lh(e,1,!1,null,null,n,r,null,o,s,c,Uh),e[Pt]=t.current,Wf(e),new Wh(t)}})),g=o(((e,t)=>{function n(){if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<`u`&&typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE==`function`)try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(n)}catch(e){console.error(e)}}n(),t.exports=h()})),_=c(u(),1),v=g(),y=`modulepreload`,b=function(e,t){return new URL(e,t).href},ee={},te=function(e,t,n){let r=Promise.resolve();if(t&&t.length>0){let e=document.getElementsByTagName(`link`),i=document.querySelector(`meta[property=csp-nonce]`),a=i?.nonce||i?.getAttribute(`nonce`);function o(e){return Promise.all(e.map(e=>Promise.resolve(e).then(e=>({status:`fulfilled`,value:e}),e=>({status:`rejected`,reason:e}))))}function s(e){return import.meta.resolve?import.meta.resolve(e):new URL(e,import.meta.url).href}r=o(t.map(t=>{if(t=b(t,n),t=s(t),t in ee)return;ee[t]=!0;let r=t.endsWith(`.css`);for(let n=e.length-1;n>=0;n--){let i=e[n];if(i.href===t&&(!r||i.rel===`stylesheet`))return}let i=document.createElement(`link`);if(i.rel=r?`stylesheet`:y,r||(i.as=`script`),i.crossOrigin=``,i.href=t,a&&i.setAttribute(`nonce`,a),document.head.appendChild(i),r)return new Promise((e,n)=>{i.addEventListener(`load`,e),i.addEventListener(`error`,()=>n(Error(`Unable to preload CSS for ${t}`)))})}).filter(e=>e!==void 0))}function i(e){let t=new Event(`vite:preloadError`,{cancelable:!0});if(t.payload=e,window.dispatchEvent(t),!t.defaultPrevented)throw e}return r.then(t=>{for(let e of t||[])e.status===`rejected`&&i(e.reason);return e().catch(i)})},ne=/^(?:[a-z][a-z0-9+.-]*:|[\\/]{2})/i,re=/^[\\/]{2}/;function x(e,t){return t+e.replace(/\\/g,`/`)}var ie=`popstate`;function S(e){return typeof e==`object`&&!!e&&`pathname`in e&&`search`in e&&`hash`in e&&`state`in e&&`key`in e}function ae(e={}){function t(e,t){let{pathname:n=`/`,search:r=``,hash:i=``}=T(e.location.hash.substring(1));return!n.startsWith(`/`)&&!n.startsWith(`.`)&&(n=`/`+n),ce(``,{pathname:n,search:r,hash:i},t.state&&t.state.usr||null,t.state&&t.state.key||`default`)}function n(e,t){let n=e.document.querySelector(`base`),r=``;if(n&&n.getAttribute(`href`)){let t=e.location.href,n=t.indexOf(`#`);r=n===-1?t:t.slice(0,n)}return r+`#`+(typeof t==`string`?t:le(t))}function r(e,t){w(e.pathname.charAt(0)===`/`,`relative pathnames are not supported in hash history.push(${JSON.stringify(t)})`)}return ue(t,n,r,e)}function C(e,t){if(e===!1||e==null)throw Error(t)}function w(e,t){if(!e){typeof console<`u`&&console.warn(t);try{throw Error(t)}catch{}}}function oe(){return Math.random().toString(36).substring(2,10)}function se(e,t){return{usr:e.state,key:e.key,idx:t,masked:e.mask?{pathname:e.pathname,search:e.search,hash:e.hash}:void 0}}function ce(e,t,n=null,r,i){return{pathname:typeof e==`string`?e:e.pathname,search:``,hash:``,...typeof t==`string`?T(t):t,state:n,key:t&&t.key||r||oe(),mask:i}}function le({pathname:e=`/`,search:t=``,hash:n=``}){return t&&t!==`?`&&(e+=t.charAt(0)===`?`?t:`?`+t),n&&n!==`#`&&(e+=n.charAt(0)===`#`?n:`#`+n),e}function T(e){let t={};if(e){let n=e.indexOf(`#`);n>=0&&(t.hash=e.substring(n),e=e.substring(0,n));let r=e.indexOf(`?`);r>=0&&(t.search=e.substring(r),e=e.substring(0,r)),e&&(t.pathname=e)}return t}function ue(e,t,n,r={}){let{window:i=document.defaultView,v5Compat:a=!1}=r,o=i.history,s=`POP`,c=null,l=u();l??(l=0,o.replaceState({...o.state,idx:l},``));function u(){return(o.state||{idx:null}).idx}function d(){s=`POP`;let e=u(),t=e==null?null:e-l;l=e,c&&c({action:s,location:h.location,delta:t})}function f(e,t){s=`PUSH`;let r=S(e)?e:ce(h.location,e,t);n&&n(r,e),l=u()+1;let d=se(r,l),f=h.createHref(r.mask||r);try{o.pushState(d,``,f)}catch(e){if(e instanceof DOMException&&e.name===`DataCloneError`)throw e;i.location.assign(f)}a&&c&&c({action:s,location:h.location,delta:1})}function p(e,t){s=`REPLACE`;let r=S(e)?e:ce(h.location,e,t);n&&n(r,e),l=u();let i=se(r,l),d=h.createHref(r.mask||r);o.replaceState(i,``,d),a&&c&&c({action:s,location:h.location,delta:0})}function m(e){return de(i,e)}let h={get action(){return s},get location(){return e(i,o)},listen(e){if(c)throw Error(`A history only accepts one active listener`);return i.addEventListener(ie,d),c=e,()=>{i.removeEventListener(ie,d),c=null}},createHref(e){return t(i,e)},createURL:m,encodeLocation(e){let t=m(e);return{pathname:t.pathname,search:t.search,hash:t.hash}},push:f,replace:p,go(e){return o.go(e)}};return h}function de(e,t,n=!1){let r=`http://localhost`;e&&(r=e.location.origin===`null`?e.location.href:e.location.origin),C(r,`No window.location.(origin|href) available to create URL`);let i=typeof t==`string`?t:le(t);return i=i.replace(/ $/,`%20`),!n&&re.test(i)&&(i=r+i),new URL(i,r)}function fe(e,t,n=`/`){return pe(e,t,n,!1)}function pe(e,t,n,r,i){let a=O((typeof t==`string`?T(t):t).pathname||`/`,n);if(a==null)return null;let o=i??me(e),s=null,c=ke(a);for(let e=0;s==null&&e<o.length;++e)s=Te(o[e],c,r);return s}function me(e){let t=he(e);return _e(t),t}function he(e,t=[],n=[],r=``,i=!1){let a=(e,a,o=i,s)=>{let c={relativePath:s===void 0?e.path||``:s,caseSensitive:e.caseSensitive===!0,childrenIndex:a,route:e};if(c.relativePath.startsWith(`/`)){if(!c.relativePath.startsWith(r)&&o)return;C(c.relativePath.startsWith(r),`Absolute route path "${c.relativePath}" nested under path "${r}" is not valid. An absolute child route path must start with the combined path of all its parent routes.`),c.relativePath=c.relativePath.slice(r.length)}let l=Le([r,c.relativePath]),u=n.concat(c);e.children&&e.children.length>0&&(C(e.index!==!0,`Index routes must not have child routes. Please remove all child routes from route path "${l}".`),he(e.children,t,u,l,o)),(e.path!=null||e.index)&&t.push({path:l,score:E(l,e.index),routesMeta:u.map((e,t)=>{let[n,r]=Oe(e.relativePath,e.caseSensitive,t===u.length-1);return{...e,matcher:n,compiledParams:r}})})};return e.forEach((e,t)=>{if(e.path===``||!e.path?.includes(`?`))a(e,t);else for(let n of ge(e.path))a(e,t,!0,n)}),t}function ge(e){let t=e.split(`/`);if(t.length===0)return[];let[n,...r]=t,i=n.endsWith(`?`),a=n.replace(/\?$/,``);if(r.length===0)return i?[a,``]:[a];let o=ge(r.join(`/`)),s=[];return s.push(...o.map(e=>e===``?a:[a,e].join(`/`))),i&&s.push(...o),s.map(t=>e.startsWith(`/`)&&t===``?`/`:t)}function _e(e){e.sort((e,t)=>e.score===t.score?D(e.routesMeta.map(e=>e.childrenIndex),t.routesMeta.map(e=>e.childrenIndex)):t.score-e.score)}var ve=/^:[\w-]+$/,ye=3,be=2,xe=1,Se=10,Ce=-2,we=e=>e===`*`;function E(e,t){let n=e.split(`/`),r=n.length;return n.some(we)&&(r+=Ce),t&&(r+=be),n.filter(e=>!we(e)).reduce((e,t)=>e+(ve.test(t)?ye:t===``?xe:Se),r)}function D(e,t){return e.length===t.length&&e.slice(0,-1).every((e,n)=>e===t[n])?e[e.length-1]-t[t.length-1]:0}function Te(e,t,n=!1){let{routesMeta:r}=e,i={},a=`/`,o=[];for(let e=0;e<r.length;++e){let s=r[e],c=e===r.length-1,l=a===`/`?t:t.slice(a.length)||`/`,u={path:s.relativePath,caseSensitive:s.caseSensitive,end:c},d=s.matcher&&s.compiledParams?De(u,l,s.matcher,s.compiledParams):Ee(u,l),f=s.route;if(!d&&c&&n&&!r[r.length-1].route.index&&(d=Ee({path:s.relativePath,caseSensitive:s.caseSensitive,end:!1},l)),!d)return null;Object.assign(i,d.params),o.push({params:i,pathname:Le([a,d.pathname]),pathnameBase:ze(Le([a,d.pathnameBase])),route:f}),d.pathnameBase!==`/`&&(a=Le([a,d.pathnameBase]))}return o}function Ee(e,t){typeof e==`string`&&(e={path:e,caseSensitive:!1,end:!0});let[n,r]=Oe(e.path,e.caseSensitive,e.end);return De(e,t,n,r)}function De(e,t,n,r){let i=t.match(n);if(!i)return null;let a=i[0],o=Re(a,1),s=i.slice(1);return{params:r.reduce((e,{paramName:t,isOptional:n},r)=>{if(t===`*`){let e=s[r]||``;o=Re(a.slice(0,a.length-e.length),1)}let i=s[r];return e[t]=n&&!i?void 0:(i||``).replace(/%2F/g,`/`),e},{}),pathname:a,pathnameBase:o,pattern:e}}function Oe(e,t=!1,n=!0){w(e===`*`||!e.endsWith(`*`)||e.endsWith(`/*`),`Route path "${e}" will be treated as if it were "${e.replace(/\*$/,`/*`)}" because the \`*\` character must always follow a \`/\` in the pattern. To get rid of this warning, please change the route path to "${e.replace(/\*$/,`/*`)}".`);let r=[],i=`^`+e.replace(/\/*\*?$/,``).replace(/^\/*/,`/`).replace(/[\\.*+^${}|()[\]]/g,`\\$&`).replace(/\/:([\w-]+)(\?)?/g,(e,t,n,i,a)=>{if(r.push({paramName:t,isOptional:n!=null}),n){let t=a.charAt(i+e.length);return t&&t!==`/`?`/([^\\/]*)`:`(?:/([^\\/]*))?`}return`/([^\\/]+)`}).replace(/\/([\w-]+)\?(\/|$)/g,`(/$1)?$2`);return e.endsWith(`*`)?(r.push({paramName:`*`}),i+=e===`*`||e===`/*`?`(.*)$`:`(?:\\/(.+)|\\/*)$`):n?i+=`\\/*$`:e!==``&&e!==`/`&&(i+=`(?:(?=\\/|$))`),[new RegExp(i,t?void 0:`i`),r]}function ke(e){try{return e.split(`/`).map(e=>decodeURIComponent(e).replace(/\//g,`%2F`)).join(`/`)}catch(t){return w(!1,`The URL path "${e}" could not be decoded because it is a malformed URL segment. This is probably due to a bad percent encoding (${t}).`),e}}function O(e,t){if(t===`/`)return e;if(!e.toLowerCase().startsWith(t.toLowerCase()))return null;let n=t.endsWith(`/`)?t.length-1:t.length,r=e.charAt(n);return r&&r!==`/`?null:e.slice(n)||`/`}function Ae(e,t=`/`){let{pathname:n,search:r=``,hash:i=``}=typeof e==`string`?T(e):e,a;return n?(n=Ie(n),a=n.startsWith(`/`)||n.startsWith(`\\`)?je(n.substring(1),`/`):je(n,t)):a=t,{pathname:a,search:Be(r),hash:Ve(i)}}function je(e,t){let n=Re(t).split(`/`);return e.split(`/`).forEach(e=>{e===`..`?n.length>1&&n.pop():e!==`.`&&n.push(e)}),n.length>1?n.join(`/`):`/`}function Me(e,t,n,r){return`Cannot include a '${e}' character in a manually specified \`to.${t}\` field [${JSON.stringify(r)}].  Please separate it out to the \`to.${n}\` field. Alternatively you may provide the full path as a string in <Link to="..."> and the router will parse it for you.`}function Ne(e){return e.filter((e,t)=>t===0||e.route.path&&e.route.path.length>0)}function Pe(e){let t=Ne(e);return t.map((e,n)=>n===t.length-1?e.pathname:e.pathnameBase)}function Fe(e,t,n,r=!1){let i;typeof e==`string`?i=T(e):(i={...e},C(!i.pathname||!i.pathname.includes(`?`),Me(`?`,`pathname`,`search`,i)),C(!i.pathname||!i.pathname.includes(`#`),Me(`#`,`pathname`,`hash`,i)),C(!i.search||!i.search.includes(`#`),Me(`#`,`search`,`hash`,i)));let a=e===``||i.pathname===``,o=a?`/`:i.pathname,s;if(o==null)s=n;else{let e=t.length-1;if(!r&&o.startsWith(`..`)){let t=o.split(`/`);for(;t[0]===`..`;)t.shift(),--e;i.pathname=t.join(`/`)}s=e>=0?t[e]:`/`}let c=Ae(i,s),l=o&&o!==`/`&&o.endsWith(`/`),u=(a||o===`.`)&&n.endsWith(`/`);return!c.pathname.endsWith(`/`)&&(l||u)&&(c.pathname+=`/`),c}var Ie=e=>e.replace(/[\\/]{2,}/g,`/`),Le=e=>Ie(e.join(`/`));function Re(e,t=0){let n=e.length;for(;n>t&&e.charCodeAt(n-1)===47;)n--;return n===e.length?e:e.slice(0,n)}var ze=e=>Re(e).replace(/^\/*/,`/`),Be=e=>!e||e===`?`?``:e.startsWith(`?`)?e:`?`+e,Ve=e=>!e||e===`#`?``:e.startsWith(`#`)?e:`#`+e,He=class{constructor(e,t,n,r=!1){this.status=e,this.statusText=t||``,this.internal=r,n instanceof Error?(this.data=n.toString(),this.error=n):this.data=n}};function Ue(e){return e!=null&&typeof e.status==`number`&&typeof e.statusText==`string`&&typeof e.internal==`boolean`&&`data`in e}function We(e){return Le(e.map(e=>e.route.path).filter(Boolean))||`/`}var Ge=typeof window<`u`&&window.document!==void 0&&window.document.createElement!==void 0;function Ke(e,t){let n=e;if(typeof n!=`string`||!ne.test(n))return{absoluteURL:void 0,isExternal:!1,to:n};let r=n,i=!1;if(Ge)try{let e=new URL(window.location.href),r=re.test(n)?new URL(x(n,e.protocol)):new URL(n),a=O(r.pathname,t);r.origin===e.origin&&a!=null?n=a+r.search+r.hash:i=!0}catch{w(!1,`<Link to="${n}"> contains an invalid URL which will probably break when clicked - please update to a valid URL path.`)}return{absoluteURL:r,isExternal:i,to:n}}Object.getOwnPropertyNames(Object.prototype).sort().join(`\0`);var qe=new URL(`http://localhost`);function Je(e){if(e.createURL)return e.createURL(`/`);try{return new URL(e.createHref(`/`),qe)}catch{return qe}}function Ye(e,t){return e.origin===t.origin&&(e.origin!==`null`||e.protocol===t.protocol&&e.host===t.host)}function Xe(e,t){if(e.startsWith(`//`))return!0;let n=t.protocol.toLowerCase();return e.toLowerCase().startsWith(n)?t.host===``||e.slice(n.length).startsWith(`//`):!1}function Ze(e,t,n,r){let i=null;try{i=e==null?null:new URL(e,n)}catch{}let a=new URL(t,n),o=i!=null&&!Ye(i,n),s=!Ye(a,n);if(r===`reject`){if(o||s)throw Error(`External navigation is not allowed`)}else if(s&&(i==null||!Xe(e,i)||!Ye(i,a)))throw Error(`External navigation is not allowed`)}var Qe=[`POST`,`PUT`,`PATCH`,`DELETE`];new Set(Qe);var $e=[`GET`,...Qe];new Set($e);var et=[`about:`,`blob:`,`chrome:`,`chrome-untrusted:`,`content:`,`data:`,`devtools:`,`file:`,`filesystem:`,`javascript:`];function tt(e){try{return et.includes(new URL(e).protocol)}catch{return!1}}var nt=_.createContext(null);nt.displayName=`DataRouter`;var rt=_.createContext(null);rt.displayName=`DataRouterState`;var it=_.createContext(!1);function at(){return _.useContext(it)}var ot=_.createContext({isTransitioning:!1});ot.displayName=`ViewTransition`;var st=_.createContext(new Map);st.displayName=`Fetchers`;var ct=_.createContext(null);ct.displayName=`Await`;var lt=_.createContext(null);lt.displayName=`Navigation`;var ut=_.createContext(null);ut.displayName=`Location`;var dt=_.createContext({outlet:null,matches:[],isDataRoute:!1});dt.displayName=`Route`;var ft=_.createContext(null);ft.displayName=`RouteError`;var pt=`REACT_ROUTER_ERROR`,mt=`REDIRECT`,ht=`ROUTE_ERROR_RESPONSE`;function gt(e){if(e.startsWith(`${pt}:${mt}:{`))try{let t=JSON.parse(e.slice(28));if(typeof t==`object`&&t&&typeof t.status==`number`&&typeof t.statusText==`string`&&typeof t.location==`string`&&typeof t.reloadDocument==`boolean`&&typeof t.replace==`boolean`)return t}catch{}}function _t(e){if(e.startsWith(`${pt}:${ht}:{`))try{let t=JSON.parse(e.slice(40));if(typeof t==`object`&&t&&typeof t.status==`number`&&typeof t.statusText==`string`)return new He(t.status,t.statusText,t.data)}catch{}}function vt(e,{relative:t}={}){C(yt(),`useHref() may be used only in the context of a <Router> component.`);let{basename:n,navigator:r}=_.useContext(lt),{hash:i,pathname:a,search:o}=Tt(e,{relative:t}),s=a;return n!==`/`&&(s=a===`/`?n:Le([n,a])),r.createHref({pathname:s,search:o,hash:i})}function yt(){return _.useContext(ut)!=null}function bt(){return C(yt(),`useLocation() may be used only in the context of a <Router> component.`),_.useContext(ut).location}var xt=`You should call navigate() in a React.useEffect(), not when your component is first rendered.`;function St(e){_.useContext(lt).static||_.useLayoutEffect(e)}function Ct(){let{isDataRoute:e}=_.useContext(dt);return e?Ht():wt()}function wt(){C(yt(),`useNavigate() may be used only in the context of a <Router> component.`);let e=_.useContext(nt),{basename:t,navigator:n}=_.useContext(lt),{matches:r}=_.useContext(dt),{pathname:i}=bt(),a=JSON.stringify(Pe(r)),o=_.useRef(!1);return St(()=>{o.current=!0}),_.useCallback((r,s={})=>{if(w(o.current,xt),!o.current)return;if(typeof r==`number`){n.go(r);return}let c=Fe(r,JSON.parse(a),i,s.relative===`path`);e==null&&t!==`/`&&(c.pathname=c.pathname===`/`?t:Le([t,c.pathname])),Ze(typeof r==`string`?r:le(r),n.createHref(c),Je(n),`reject`),(s.replace?n.replace:n.push)(c,s.state,s)},[t,n,a,i,e])}_.createContext(null);function Tt(e,{relative:t}={}){let{matches:n}=_.useContext(dt),{pathname:r}=bt(),i=JSON.stringify(Pe(n));return _.useMemo(()=>Fe(e,JSON.parse(i),r,t===`path`),[e,i,r,t])}function Et(e,t){return Dt(e,t)}function Dt(e,t,n){C(yt(),`useRoutes() may be used only in the context of a <Router> component.`);let{navigator:r}=_.useContext(lt),{matches:i}=_.useContext(dt),a=i[i.length-1],o=a?a.params:{},s=a?a.pathname:`/`,c=a?a.pathnameBase:`/`,l=a&&a.route;{let e=l&&l.path||``;Wt(s,!l||e.endsWith(`*`)||e.endsWith(`*?`),`You rendered descendant <Routes> (or called \`useRoutes()\`) at "${s}" (under <Route path="${e}">) but the parent route path has no trailing "*". This means if you navigate deeper, the parent won't match anymore and therefore the child routes will never render.

Please change the parent <Route path="${e}"> to <Route path="${e===`/`?`*`:`${e}/*`}">.`)}let u=bt(),d;if(t){let e=typeof t==`string`?T(t):t;C(c===`/`||e.pathname?.startsWith(c),`When overriding the location using \`<Routes location>\` or \`useRoutes(routes, location)\`, the location pathname must begin with the portion of the URL pathname that was matched by all parent routes. The current pathname base is "${c}" but pathname "${e.pathname}" was given in the \`location\` prop.`),d=e}else d=u;let f=d.pathname||`/`,p=f;if(c!==`/`){let e=c.replace(/^\//,``).split(`/`);p=`/`+f.replace(/^\//,``).split(`/`).slice(e.length).join(`/`)}let m=n&&n.state.matches.length?n.state.matches.map(e=>Object.assign(e,{route:n.manifest[e.route.id]||e.route})):fe(e,{pathname:p});w(l||m!=null,`No routes matched location "${d.pathname}${d.search}${d.hash}" `),w(m==null||m[m.length-1].route.element!==void 0||m[m.length-1].route.Component!==void 0||m[m.length-1].route.lazy!==void 0,`Matched leaf route at location "${d.pathname}${d.search}${d.hash}" does not have an element or Component. This means it will render an <Outlet /> with a null value by default resulting in an "empty" page.`);let h=Pt(m&&m.map(e=>Object.assign({},e,{params:Object.assign({},o,e.params),pathname:Le([c,r.encodeLocation?r.encodeLocation(e.pathname.replace(/%/g,`%25`).replace(/\?/g,`%3F`).replace(/#/g,`%23`)).pathname:e.pathname]),pathnameBase:e.pathnameBase===`/`?c:Le([c,r.encodeLocation?r.encodeLocation(e.pathnameBase.replace(/%/g,`%25`).replace(/\?/g,`%3F`).replace(/#/g,`%23`)).pathname:e.pathnameBase])})),i,n);return t&&h?_.createElement(ut.Provider,{value:{location:{pathname:`/`,search:``,hash:``,state:null,key:`default`,mask:void 0,...d},navigationType:`POP`}},h):h}function Ot(){let e=Vt(),t=Ue(e)?`${e.status} ${e.statusText}`:e instanceof Error?e.message:JSON.stringify(e),n=e instanceof Error?e.stack:null,r=`rgba(200,200,200, 0.5)`,i={padding:`0.5rem`,backgroundColor:r},a={padding:`2px 4px`,backgroundColor:r},o=null;return console.error(`Error handled by React Router default ErrorBoundary:`,e),o=_.createElement(_.Fragment,null,_.createElement(`p`,null,`💿 Hey developer 👋`),_.createElement(`p`,null,`You can provide a way better UX than this when your app throws errors by providing your own `,_.createElement(`code`,{style:a},`ErrorBoundary`),` or`,` `,_.createElement(`code`,{style:a},`errorElement`),` prop on your route.`)),_.createElement(_.Fragment,null,_.createElement(`h2`,null,`Unexpected Application Error!`),_.createElement(`h3`,{style:{fontStyle:`italic`}},t),n?_.createElement(`pre`,{style:i},n):null,o)}var kt=_.createElement(Ot,null),At=class extends _.Component{constructor(e){super(e),this.state={location:e.location,revalidation:e.revalidation,error:e.error}}static getDerivedStateFromError(e){return{error:e}}static getDerivedStateFromProps(e,t){return t.location!==e.location||t.revalidation!==`idle`&&e.revalidation===`idle`?{error:e.error,location:e.location,revalidation:e.revalidation}:{error:e.error===void 0?t.error:e.error,location:t.location,revalidation:e.revalidation||t.revalidation}}componentDidCatch(e,t){this.props.onError?this.props.onError(e,t):console.error(`React Router caught the following error during render`,e)}render(){let e=this.state.error;if(this.context&&typeof e==`object`&&e&&`digest`in e&&typeof e.digest==`string`){let t=_t(e.digest);t&&(e=t)}let t=e===void 0?this.props.children:_.createElement(dt.Provider,{value:this.props.routeContext},_.createElement(ft.Provider,{value:e,children:this.props.component}));return this.context?_.createElement(Mt,{error:e},t):t}};At.contextType=it;var jt=new WeakMap;function Mt({children:e,error:t}){let{basename:n,navigator:r}=_.useContext(lt);if(typeof t==`object`&&t&&`digest`in t&&typeof t.digest==`string`){let e=gt(t.digest);if(e){let i=jt.get(t);if(i)throw i;let a=Ke(e.location,n),o=a.absoluteURL||a.to;if(Ze(e.location,o,Je(r),`allow-explicit`),tt(o))throw Error(`Invalid redirect location`);if(Ge&&!jt.get(t)){if(a.isExternal||e.reloadDocument)window.location.href=o;else{let n=Promise.resolve().then(()=>window.__reactRouterDataRouter.navigate(a.to,{replace:e.replace}));throw jt.set(t,n),n}}return _.createElement(`meta`,{httpEquiv:`refresh`,content:`0;url=${o}`})}}return e}function Nt({routeContext:e,match:t,children:n}){let r=_.useContext(nt);return r&&r.static&&r.staticContext&&(t.route.errorElement||t.route.ErrorBoundary)&&(r.staticContext._deepestRenderedBoundaryId=t.route.id),_.createElement(dt.Provider,{value:e},n)}function Pt(e,t=[],n){let r=n?.state;if(e==null){if(!r)return null;if(r.errors)e=r.matches;else if(t.length===0&&!r.initialized&&r.matches.length>0)e=r.matches;else return null}let i=e,a=r?.errors;if(a!=null){let e=i.findIndex(e=>e.route.id&&a?.[e.route.id]!==void 0);C(e>=0,`Could not find a matching route for errors on route IDs: ${Object.keys(a).join(`,`)}`),i=i.slice(0,Math.min(i.length,e+1))}let o=!1,s=-1;if(n&&r){o=r.renderFallback;for(let e=0;e<i.length;e++){let t=i[e];if((t.route.HydrateFallback||t.route.hydrateFallbackElement)&&(s=e),t.route.id){let{loaderData:e,errors:a}=r,c=t.route.loader&&!e.hasOwnProperty(t.route.id)&&(!a||a[t.route.id]===void 0);if(t.route.lazy||c){n.isStatic&&(o=!0),i=s>=0?i.slice(0,s+1):[i[0]];break}}}}let c=n?.onError,l=r&&c?(e,t)=>{c(e,{location:r.location,params:r.matches?.[0]?.params??{},pattern:We(r.matches),errorInfo:t})}:void 0;return i.reduceRight((e,n,c)=>{let u,d=!1,f=null,p=null;r&&(u=a&&n.route.id?a[n.route.id]:void 0,f=n.route.errorElement||kt,o&&(s<0&&c===0?(Wt(`route-fallback`,!1,"No `HydrateFallback` element provided to render during initial hydration"),d=!0,p=null):s===c&&(d=!0,p=n.route.hydrateFallbackElement||null)));let m=t.concat(i.slice(0,c+1)),h=()=>{let t;return t=u?f:d?p:n.route.Component?_.createElement(n.route.Component,null):n.route.element?n.route.element:e,_.createElement(Nt,{match:n,routeContext:{outlet:e,matches:m,isDataRoute:r!=null},children:t})};return r&&(n.route.ErrorBoundary||n.route.errorElement||c===0)?_.createElement(At,{location:r.location,revalidation:r.revalidation,component:f,error:u,children:h(),routeContext:{outlet:null,matches:m,isDataRoute:!0},onError:l}):h()},null)}function Ft(e){return`${e} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`}function It(e){let t=_.useContext(nt);return C(t,Ft(e)),t}function Lt(e){let t=_.useContext(rt);return C(t,Ft(e)),t}function Rt(e){let t=_.useContext(dt);return C(t,Ft(e)),t}function zt(e){let t=Rt(e),n=t.matches[t.matches.length-1];return C(n.route.id,`${e} can only be used on routes that contain a unique "id"`),n.route.id}function Bt(){return zt(`useRouteId`)}function Vt(){let e=_.useContext(ft),t=Lt(`useRouteError`),n=zt(`useRouteError`);return e===void 0?t.errors?.[n]:e}function Ht(){let{router:e}=It(`useNavigate`),t=zt(`useNavigate`),n=_.useRef(!1);return St(()=>{n.current=!0}),_.useCallback(async(r,i={})=>{w(n.current,xt),n.current&&(typeof r==`number`?await e.navigate(r):await e.navigate(r,{fromRouteId:t,...i}))},[e,t])}var Ut={};function Wt(e,t,n){!t&&!Ut[e]&&(Ut[e]=!0,w(!1,n))}_.memo(Gt);function Gt({routes:e,manifest:t,future:n,state:r,isStatic:i,onError:a}){return Dt(e,void 0,{manifest:t,state:r,isStatic:i,onError:a,future:n})}function k(e){C(!1,`A <Route> is only ever to be used as the child of <Routes> element, never rendered directly. Please wrap your <Route> in a <Routes>.`)}function Kt({basename:e=`/`,children:t=null,location:n,navigationType:r=`POP`,navigator:i,static:a=!1,useTransitions:o}){C(!yt(),`You cannot render a <Router> inside another <Router>. You should never have more than one in your app.`);let s=e.replace(/^\/*/,`/`),c=_.useMemo(()=>({basename:s,navigator:i,static:a,useTransitions:o,future:{}}),[s,i,a,o]);typeof n==`string`&&(n=T(n));let{pathname:l=`/`,search:u=``,hash:d=``,state:f=null,key:p=`default`,mask:m}=n,h=_.useMemo(()=>{let e=O(l,s);return e==null?null:{location:{pathname:e,search:u,hash:d,state:f,key:p,mask:m},navigationType:r}},[s,l,u,d,f,p,r,m]);return w(h!=null,`<Router basename="${s}"> is not able to match the URL "${l}${u}${d}" because it does not start with the basename, so the <Router> won't render anything.`),h==null?null:_.createElement(lt.Provider,{value:c},_.createElement(ut.Provider,{children:t,value:h}))}function qt({children:e,location:t}){return Et(Jt(e),t)}_.Component;function Jt(e,t=[]){let n=[];return _.Children.forEach(e,(e,r)=>{if(!_.isValidElement(e))return;let i=[...t,r];if(e.type===_.Fragment){n.push.apply(n,Jt(e.props.children,i));return}C(e.type===k,`[${typeof e.type==`string`?e.type:e.type.name}] is not a <Route> component. All component children of <Routes> must be a <Route> or <React.Fragment>`),C(!e.props.index||!e.props.children,`An index route cannot have child routes.`);let a={id:e.props.id||i.join(`-`),caseSensitive:e.props.caseSensitive,element:e.props.element,Component:e.props.Component,index:e.props.index,path:e.props.path,middleware:e.props.middleware,loader:e.props.loader,action:e.props.action,hydrateFallbackElement:e.props.hydrateFallbackElement,HydrateFallback:e.props.HydrateFallback,errorElement:e.props.errorElement,ErrorBoundary:e.props.ErrorBoundary,hasErrorBoundary:e.props.hasErrorBoundary===!0||e.props.ErrorBoundary!=null||e.props.errorElement!=null,shouldRevalidate:e.props.shouldRevalidate,handle:e.props.handle,lazy:e.props.lazy};e.props.children&&(a.children=Jt(e.props.children,i)),n.push(a)}),n}var Yt=`get`,Xt=`application/x-www-form-urlencoded`;function Zt(e){return typeof HTMLElement<`u`&&e instanceof HTMLElement}function Qt(e){return Zt(e)&&e.tagName.toLowerCase()===`button`}function $t(e){return Zt(e)&&e.tagName.toLowerCase()===`form`}function en(e){return Zt(e)&&e.tagName.toLowerCase()===`input`}function A(e){return!!(e.metaKey||e.altKey||e.ctrlKey||e.shiftKey)}function tn(e,t){return e.button===0&&(!t||t===`_self`)&&!A(e)}var nn=null;function rn(){if(nn===null)try{new FormData(document.createElement(`form`),0),nn=!1}catch{nn=!0}return nn}var an=new Set([`application/x-www-form-urlencoded`,`multipart/form-data`,`text/plain`]);function on(e){return e!=null&&!an.has(e)?(w(!1,`"${e}" is not a valid \`encType\` for \`<Form>\`/\`<fetcher.Form>\` and will default to "${Xt}"`),null):e}function sn(e,t){let n,r,i,a,o;if($t(e)){let o=e.getAttribute(`action`);r=o?O(o,t):null,n=e.getAttribute(`method`)||Yt,i=on(e.getAttribute(`enctype`))||Xt,a=new FormData(e)}else if(Qt(e)||en(e)&&(e.type===`submit`||e.type===`image`)){let o=e.form;if(o==null)throw Error(`Cannot submit a <button> or <input type="submit"> without a <form>`);let s=e.getAttribute(`formaction`)||o.getAttribute(`action`);if(r=s?O(s,t):null,n=e.getAttribute(`formmethod`)||o.getAttribute(`method`)||Yt,i=on(e.getAttribute(`formenctype`))||on(o.getAttribute(`enctype`))||Xt,a=new FormData(o,e),!rn()){let{name:t,type:n,value:r}=e;if(n===`image`){let e=t?`${t}.`:``;a.append(`${e}x`,`0`),a.append(`${e}y`,`0`)}else t&&a.append(t,r)}}else if(Zt(e))throw Error(`Cannot submit element that is not <form>, <button>, or <input type="submit|image">`);else n=Yt,r=null,i=Xt,o=e;return a&&i===`text/plain`&&(o=a,a=void 0),{action:r,method:n.toLowerCase(),encType:i,formData:a,body:o}}Object.getOwnPropertyNames(Object.prototype).sort().join(`\0`);function cn(e,t){if(e===!1||e==null)throw Error(t)}function ln(e,t,n,r){let i=typeof e==`string`?new URL(e,typeof window>`u`?`server://singlefetch/`:window.location.origin):e;return i.pathname=n?i.pathname.endsWith(`/`)?`${i.pathname}_.${r}`:`${i.pathname}.${r}`:i.pathname===`/`?`_root.${r}`:t&&O(i.pathname,t)===`/`?`${Re(t)}/_root.${r}`:`${Re(i.pathname)}.${r}`,i}async function un(e,t){if(e.id in t)return t[e.id];try{let n=await te(()=>import(e.module),[],import.meta.url);return t[e.id]=n,n}catch(t){return console.error(`Error loading route module \`${e.module}\`, reloading page...`),console.error(t),window.__reactRouterContext&&window.__reactRouterContext.isSpaMode,window.location.reload(),new Promise(()=>{})}}function dn(e){return e!=null&&typeof e.page==`string`}function fn(e){return e==null?!1:e.href==null?e.rel===`preload`&&typeof e.imageSrcSet==`string`&&typeof e.imageSizes==`string`:typeof e.rel==`string`&&typeof e.href==`string`}async function pn(e,t,n){return vn((await Promise.all(e.map(async e=>{let r=t.routes[e.route.id];if(r){let e=await un(r,n);return e.links?e.links():[]}return[]}))).flat(1).filter(fn).filter(e=>e.rel===`stylesheet`||e.rel===`preload`).map(e=>e.rel===`stylesheet`?{...e,rel:`prefetch`,as:`style`}:{...e,rel:`prefetch`}))}function mn(e,t,n,r,i,a){let o=(e,t)=>!n[t]||e.route.id!==n[t].route.id,s=(e,t)=>n[t].pathname!==e.pathname||n[t].route.path?.endsWith(`*`)&&n[t].params[`*`]!==e.params[`*`];return a===`assets`?t.filter((e,t)=>o(e,t)||s(e,t)):a===`data`?t.filter((t,a)=>{let c=r.routes[t.route.id];if(!c||!c.hasLoader)return!1;if(o(t,a)||s(t,a))return!0;if(t.route.shouldRevalidate){let r=t.route.shouldRevalidate({currentUrl:new URL(i.pathname+i.search+i.hash,window.origin),currentParams:n[0]?.params||{},nextUrl:new URL(e,window.origin),nextParams:t.params,defaultShouldRevalidate:!0});if(typeof r==`boolean`)return r}return!0}):[]}function hn(e,t,{includeHydrateFallback:n}={}){return gn(e.map(e=>{let r=t.routes[e.route.id];if(!r)return[];let i=[r.module];return r.clientActionModule&&(i=i.concat(r.clientActionModule)),r.clientLoaderModule&&(i=i.concat(r.clientLoaderModule)),n&&r.hydrateFallbackModule&&(i=i.concat(r.hydrateFallbackModule)),r.imports&&(i=i.concat(r.imports)),i}).flat(1))}function gn(e){return[...new Set(e)]}function _n(e){let t={},n=Object.keys(e).sort();for(let r of n)t[r]=e[r];return t}function vn(e,t){let n=new Set,r=new Set(t);return e.reduce((e,i)=>{if(t&&!dn(i)&&i.as===`script`&&i.href&&r.has(i.href))return e;let a=JSON.stringify(_n(i));return n.has(a)||(n.add(a),e.push({key:a,link:i})),e},[])}function yn(){let e=_.useContext(nt);return cn(e,`You must render this element inside a <DataRouterContext.Provider> element`),e}function bn(){let e=_.useContext(rt);return cn(e,`You must render this element inside a <DataRouterStateContext.Provider> element`),e}var xn=_.createContext(void 0);xn.displayName=`FrameworkContext`;function Sn(){let e=_.useContext(xn);return cn(e,`You must render this element inside a <HydratedRouter> element`),e}function Cn(e,t){let n=_.useContext(xn),[r,i]=_.useState(!1),[a,o]=_.useState(!1),{onFocus:s,onBlur:c,onMouseEnter:l,onMouseLeave:u,onTouchStart:d}=t,f=_.useRef(null);_.useEffect(()=>{if(e===`render`&&o(!0),e===`viewport`){let e=new IntersectionObserver(e=>{e.forEach(e=>{o(e.isIntersecting)})},{threshold:.5});return f.current&&e.observe(f.current),()=>{e.disconnect()}}},[e]),_.useEffect(()=>{if(r){let e=setTimeout(()=>{o(!0)},100);return()=>{clearTimeout(e)}}},[r]);let p=()=>{i(!0)},m=()=>{i(!1),o(!1)};return n?e===`intent`?[a,f,{onFocus:wn(s,p),onBlur:wn(c,m),onMouseEnter:wn(l,p),onMouseLeave:wn(u,m),onTouchStart:wn(d,p)}]:[a,f,{}]:[!1,f,{}]}function wn(e,t){return n=>{e&&e(n),n.defaultPrevented||t(n)}}function Tn({page:e,...t}){let n=at(),{nonce:r}=Sn(),{router:i}=yn(),a=_.useMemo(()=>fe(i.routes,e,i.basename),[i.routes,e,i.basename]);return a?(t.nonce==null&&r&&(t={...t,nonce:r}),n?_.createElement(Dn,{page:e,matches:a,...t}):_.createElement(On,{page:e,matches:a,...t})):null}function En(e){let{manifest:t,routeModules:n}=Sn(),[r,i]=_.useState([]);return _.useEffect(()=>{let r=!1;return pn(e,t,n).then(e=>{r||i(e)}),()=>{r=!0}},[e,t,n]),r}function Dn({page:e,matches:t,...n}){let r=bt(),{future:i}=Sn(),{basename:a}=yn(),o=_.useMemo(()=>{if(e===r.pathname+r.search+r.hash)return[];let n=ln(e,a,i.v8_trailingSlashAwareDataRequests,`rsc`),o=!1,s=[];for(let e of t)typeof e.route.shouldRevalidate==`function`?o=!0:s.push(e.route.id);return o&&s.length>0&&n.searchParams.set(`_routes`,s.join(`,`)),[n.pathname+n.search]},[a,i.v8_trailingSlashAwareDataRequests,e,r,t]);return _.createElement(_.Fragment,null,o.map(e=>_.createElement(`link`,{key:e,rel:`prefetch`,as:`fetch`,href:e,...n})))}function On({page:e,matches:t,...n}){let r=bt(),{future:i,manifest:a,routeModules:o}=Sn(),{basename:s}=yn(),{loaderData:c,matches:l}=bn(),u=_.useMemo(()=>mn(e,t,l,a,r,`data`),[e,t,l,a,r]),d=_.useMemo(()=>mn(e,t,l,a,r,`assets`),[e,t,l,a,r]),f=_.useMemo(()=>{if(e===r.pathname+r.search+r.hash)return[];let n=new Set,l=!1;if(t.forEach(e=>{let t=a.routes[e.route.id];t&&t.hasLoader&&(!u.some(t=>t.route.id===e.route.id)&&e.route.id in c&&o[e.route.id]?.shouldRevalidate||t.hasClientLoader?l=!0:n.add(e.route.id))}),n.size===0)return[];let d=ln(e,s,i.v8_trailingSlashAwareDataRequests,`data`);return l&&n.size>0&&d.searchParams.set(`_routes`,t.filter(e=>n.has(e.route.id)).map(e=>e.route.id).join(`,`)),[d.pathname+d.search]},[s,i.v8_trailingSlashAwareDataRequests,c,r,a,u,t,e,o]),p=_.useMemo(()=>hn(d,a),[d,a]),m=En(d);return _.createElement(_.Fragment,null,f.map(e=>_.createElement(`link`,{key:e,rel:`prefetch`,as:`fetch`,href:e,...n})),p.map(e=>_.createElement(`link`,{key:e,rel:`modulepreload`,href:e,...n})),m.map(({key:e,link:t})=>_.createElement(`link`,{key:e,nonce:n.nonce,...t,crossOrigin:t.crossOrigin??n.crossOrigin})))}function kn(...e){return t=>{e.forEach(e=>{typeof e==`function`?e(t):e!=null&&(e.current=t)})}}_.Component;var An=typeof window<`u`&&window.document!==void 0&&window.document.createElement!==void 0;try{An&&(window.__reactRouterVersion=`7.18.4`)}catch{}function jn({basename:e,children:t,useTransitions:n,window:r}){let i=_.useRef();i.current??=ae({window:r,v5Compat:!0});let a=i.current,[o,s]=_.useState({action:a.action,location:a.location}),c=_.useCallback(e=>{n===!1?s(e):_.startTransition(()=>s(e))},[n]);return _.useLayoutEffect(()=>a.listen(c),[a,c]),_.createElement(Kt,{basename:e,children:t,location:o.location,navigationType:o.action,navigator:a,useTransitions:n})}var j=_.forwardRef(function({onClick:e,discover:t=`render`,prefetch:n=`none`,relative:r,reloadDocument:i,replace:a,mask:o,state:s,target:c,to:l,preventScrollReset:u,viewTransition:d,defaultShouldRevalidate:f,...p},m){let{basename:h,navigator:g,useTransitions:v}=_.useContext(lt),y=typeof l==`string`&&ne.test(l),b=Ke(l,h);l=b.to;let ee=vt(l,{relative:r}),te=bt(),re=null;if(o){let e=Fe(o,[],te.mask?te.mask.pathname:`/`,!0);h!==`/`&&(e.pathname=e.pathname===`/`?h:Le([h,e.pathname])),re=g.createHref(e)}let[x,ie,S]=Cn(n,p),ae=In(l,{replace:a,mask:o,state:s,target:c,preventScrollReset:u,relative:r,viewTransition:d,defaultShouldRevalidate:f,useTransitions:v});function C(t){e&&e(t),t.defaultPrevented||ae(t)}let w=!(b.isExternal||i),oe=_.createElement(`a`,{...p,...S,href:(w?re:void 0)||b.absoluteURL||ee,onClick:w?C:e,ref:kn(m,ie),target:c,"data-discover":!y&&t===`render`?`true`:void 0});return x&&!y?_.createElement(_.Fragment,null,oe,_.createElement(Tn,{page:ee})):oe});j.displayName=`Link`;var Mn=_.forwardRef(function({"aria-current":e=`page`,caseSensitive:t=!1,className:n=``,end:r=!1,style:i,to:a,viewTransition:o,children:s,...c},l){let u=Tt(a,{relative:c.relative}),d=bt(),f=_.useContext(rt),{navigator:p,basename:m}=_.useContext(lt),h=f!=null&&Vn(u)&&o===!0,g=p.encodeLocation?p.encodeLocation(u).pathname:u.pathname,v=d.pathname,y=f&&f.navigation&&f.navigation.location?f.navigation.location.pathname:null;t||(v=v.toLowerCase(),y=y?y.toLowerCase():null,g=g.toLowerCase()),y&&m&&(y=O(y,m)||y);let b=g!==`/`&&g.endsWith(`/`)?g.length-1:g.length,ee=v===g||!r&&v.startsWith(g)&&v.charAt(b)===`/`,te=y!=null&&(y===g||!r&&y.startsWith(g)&&y.charAt(g.length)===`/`),ne={isActive:ee,isPending:te,isTransitioning:h},re=ee?e:void 0,x;x=typeof n==`function`?n(ne):[n,ee?`active`:null,te?`pending`:null,h?`transitioning`:null].filter(Boolean).join(` `);let ie=typeof i==`function`?i(ne):i;return _.createElement(j,{...c,"aria-current":re,className:x,ref:l,style:ie,to:a,viewTransition:o},typeof s==`function`?s(ne):s)});Mn.displayName=`NavLink`;var Nn=_.forwardRef(({discover:e=`render`,fetcherKey:t,navigate:n,reloadDocument:r,replace:i,state:a,method:o=Yt,action:s,onSubmit:c,relative:l,preventScrollReset:u,viewTransition:d,defaultShouldRevalidate:f,...p},m)=>{let{useTransitions:h}=_.useContext(lt),g=zn(),v=Bn(s,{relative:l}),y=o.toLowerCase()===`get`?`get`:`post`,b=typeof s==`string`&&ne.test(s);return _.createElement(`form`,{ref:m,method:y,action:v,onSubmit:r?c:e=>{if(c&&c(e),e.defaultPrevented)return;e.preventDefault();let r=e.nativeEvent.submitter,s=r?.getAttribute(`formmethod`)||o,p=()=>g(r||e.currentTarget,{fetcherKey:t,method:s,navigate:n,replace:i,state:a,relative:l,preventScrollReset:u,viewTransition:d,defaultShouldRevalidate:f});h&&n!==!1?_.startTransition(()=>p()):p()},...p,"data-discover":!b&&e===`render`?`true`:void 0})});Nn.displayName=`Form`;function Pn(e){return`${e} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`}function Fn(e){let t=_.useContext(nt);return C(t,Pn(e)),t}function In(e,{target:t,replace:n,mask:r,state:i,preventScrollReset:a,relative:o,viewTransition:s,defaultShouldRevalidate:c,useTransitions:l}={}){let u=Ct(),d=bt(),f=Tt(e,{relative:o});return _.useCallback(p=>{if(tn(p,t)){p.preventDefault();let t=n===void 0?le(d)===le(f):n,m=()=>u(e,{replace:t,mask:r,state:i,preventScrollReset:a,relative:o,viewTransition:s,defaultShouldRevalidate:c});l?_.startTransition(()=>m()):m()}},[d,u,f,n,r,i,t,e,a,o,s,c,l])}var Ln=0,Rn=()=>`__${String(++Ln)}__`;function zn(){let{router:e}=Fn(`useSubmit`),{basename:t}=_.useContext(lt),n=Bt(),r=e.fetch,i=e.navigate;return _.useCallback(async(e,a={})=>{let{action:o,method:s,encType:c,formData:l,body:u}=sn(e,t);if(a.navigate===!1){let e=a.fetcherKey||Rn();await r(e,n,a.action||o,{defaultShouldRevalidate:a.defaultShouldRevalidate,preventScrollReset:a.preventScrollReset,formData:l,body:u,formMethod:a.method||s,formEncType:a.encType||c,flushSync:a.flushSync})}else await i(a.action||o,{defaultShouldRevalidate:a.defaultShouldRevalidate,preventScrollReset:a.preventScrollReset,formData:l,body:u,formMethod:a.method||s,formEncType:a.encType||c,replace:a.replace,state:a.state,fromRouteId:n,flushSync:a.flushSync,viewTransition:a.viewTransition})},[r,i,t,n])}function Bn(e,{relative:t}={}){let{basename:n}=_.useContext(lt),r=_.useContext(dt);C(r,`useFormAction must be used inside a RouteContext`);let[i]=r.matches.slice(-1),a={...Tt(e||`.`,{relative:t})},o=bt();if(e==null){a.search=o.search;let e=new URLSearchParams(a.search),t=e.getAll(`index`);if(t.some(e=>e===``)){e.delete(`index`),t.filter(e=>e).forEach(t=>e.append(`index`,t));let n=e.toString();a.search=n?`?${n}`:``}}return(!e||e===`.`)&&i.route.index&&(a.search=a.search?a.search.replace(/^\?/,`?index&`):`?index`),n!==`/`&&(a.pathname=a.pathname===`/`?n:Le([n,a.pathname])),le(a)}function Vn(e,{relative:t}={}){let n=_.useContext(ot);C(n!=null,"`useViewTransitionState` must be used within `react-router-dom`'s `RouterProvider`.  Did you accidentally import `RouterProvider` from `react-router`?");let{basename:r}=Fn(`useViewTransitionState`),i=Tt(e,{relative:t});if(!n.isTransitioning)return!1;let a=O(n.currentLocation.pathname,r)||n.currentLocation.pathname,o=O(n.nextLocation.pathname,r)||n.nextLocation.pathname;return Ee(i.pathname,o)!=null||Ee(i.pathname,a)!=null}var Hn=new URL(`Gryphon_Cyber_Hero_Background-DTjRvDIF.png`,import.meta.url).href,Un=new URL(`gryphon-logo-D8xdoNAB.png`,import.meta.url).href,Wn={color:void 0,size:void 0,className:void 0,style:void 0,attr:void 0},Gn=_.createContext&&_.createContext(Wn),Kn=[`attr`,`size`,`title`];function qn(e,t){if(e==null)return{};var n,r,i=Jn(e,t);if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(e);for(r=0;r<a.length;r++)n=a[r],t.indexOf(n)===-1&&{}.propertyIsEnumerable.call(e,n)&&(i[n]=e[n])}return i}function Jn(e,t){if(e==null)return{};var n={};for(var r in e)if({}.hasOwnProperty.call(e,r)){if(t.indexOf(r)!==-1)continue;n[r]=e[r]}return n}function Yn(){return Yn=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)({}).hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e},Yn.apply(null,arguments)}function Xn(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter(function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable})),n.push.apply(n,r)}return n}function Zn(e){for(var t=1;t<arguments.length;t++){var n=arguments[t]==null?{}:arguments[t];t%2?Xn(Object(n),!0).forEach(function(t){Qn(e,t,n[t])}):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):Xn(Object(n)).forEach(function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))})}return e}function Qn(e,t,n){return(t=$n(t))in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function $n(e){var t=er(e,`string`);return typeof t==`symbol`?t:t+``}function er(e,t){if(typeof e!=`object`||!e)return e;var n=e[Symbol.toPrimitive];if(n!==void 0){var r=n.call(e,t||`default`);if(typeof r!=`object`)return r;throw TypeError(`@@toPrimitive must return a primitive value.`)}return(t===`string`?String:Number)(e)}function tr(e){return e&&e.map((e,t)=>_.createElement(e.tag,Zn({key:t},e.attr),tr(e.child)))}function nr(e){return t=>_.createElement(rr,Yn({attr:Zn({},e.attr)},t),tr(e.child))}function rr(e){var t=t=>{var n=e.attr,r=e.size,i=e.title,a=qn(e,Kn),o=r||t.size||`1em`,s;return t.className&&(s=t.className),e.className&&(s=(s?s+` `:``)+e.className),_.createElement(`svg`,Yn({stroke:`currentColor`,fill:`currentColor`,strokeWidth:`0`},t.attr,n,a,{className:s,style:Zn(Zn({color:e.color||t.color},t.style),e.style),height:o,width:o,xmlns:`http://www.w3.org/2000/svg`}),i&&_.createElement(`title`,null,i),e.children)};return Gn===void 0?t(Wn):_.createElement(Gn.Consumer,null,e=>t(e))}function ir(e){return nr({tag:`svg`,attr:{viewBox:`0 0 512 512`},child:[{tag:`path`,attr:{d:`M389.2 48h70.6L305.6 224.2 487 464H345L233.7 318.6 106.5 464H35.8L200.7 275.5 26.8 48H172.4L272.9 180.9 389.2 48zM364.4 421.8h39.1L151.1 88h-42L364.4 421.8z`},child:[]}]})(e)}function ar(e){return nr({tag:`svg`,attr:{viewBox:`0 0 448 512`},child:[{tag:`path`,attr:{d:`M100.28 448H7.4V148.9h92.88zM53.79 108.1C24.09 108.1 0 83.5 0 53.8a53.79 53.79 0 0 1 107.58 0c0 29.7-24.1 54.3-53.79 54.3zM447.9 448h-92.68V302.4c0-34.7-.7-79.2-48.29-79.2-48.29 0-55.69 37.7-55.69 76.7V448h-92.78V148.9h89.08v40.8h1.3c12.4-23.5 42.69-48.3 87.88-48.3 94 0 111.28 61.9 111.28 142.3V448z`},child:[]}]})(e)}function or(e){return nr({tag:`svg`,attr:{viewBox:`0 0 448 512`},child:[{tag:`path`,attr:{d:`M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z`},child:[]}]})(e)}var sr=o((e=>{var t=Symbol.for(`react.transitional.element`),n=Symbol.for(`react.fragment`);function r(e,n,r){var i=null;if(r!==void 0&&(i=``+r),n.key!==void 0&&(i=``+n.key),`key`in n)for(var a in r={},n)a!==`key`&&(r[a]=n[a]);else r=n;return n=r.ref,{$$typeof:t,type:e,key:i,ref:n===void 0?null:n,props:r}}e.Fragment=n,e.jsx=r,e.jsxs=r})),M=o(((e,t)=>{t.exports=sr()}))(),cr=[{label:`Instagram`,href:`https://www.instagram.com/gryphoncyber/`,Icon:or},{label:`X (Twitter)`,href:`https://x.com/gryphon_cyber`,Icon:ir},{label:`LinkedIn`,href:`https://www.linkedin.com/company/109755959/`,Icon:ar}],lr=`https://www.google.com/maps/place/Gryphon+Cyber+Private+Limited/@19.0082821,72.8208377,17z/`,ur=`https://www.google.com/maps?q=Upasana+building,+1,+Hamdard+Nagar,+Vakil+Lane,+Mandi+House,+New+Delhi,+Delhi+110001`;function dr(){return(0,M.jsxs)(`footer`,{className:`gryphon-footer`,"aria-label":`Gryphon Cyber website footer`,children:[(0,M.jsxs)(`div`,{className:`gryphon-footer__main`,children:[(0,M.jsxs)(`div`,{className:`gryphon-footer__brand`,children:[(0,M.jsx)(j,{to:`/`,className:`gryphon-footer__logo-link`,"aria-label":`Gryphon Cyber home`,children:(0,M.jsx)(`img`,{src:Un,alt:`Gryphon Cyber`,className:`gryphon-footer__logo`})}),(0,M.jsx)(`p`,{children:`Cyber intelligence and ground operations for complex investigations, intelligence gathering and digital security.`}),(0,M.jsx)(`div`,{className:`gryphon-footer__socials`,"aria-label":`Social media`,children:cr.map(({label:e,href:t,Icon:n})=>(0,M.jsxs)(`a`,{className:`gryphon-footer__social-link`,href:t,target:`_blank`,rel:`noopener noreferrer`,"aria-label":`Gryphon Cyber on ${e}`,title:e,children:[(0,M.jsx)(n,{"aria-hidden":`true`}),(0,M.jsx)(`span`,{children:e})]},e))})]}),(0,M.jsxs)(`nav`,{className:`gryphon-footer__column`,"aria-label":`Company links`,children:[(0,M.jsx)(`h2`,{children:`Company`}),(0,M.jsx)(j,{to:`/`,children:`Home`}),(0,M.jsx)(j,{to:`/about`,children:`About`}),(0,M.jsx)(j,{to:`/services`,children:`Services`}),(0,M.jsx)(j,{to:`/contact`,children:`Contact`}),(0,M.jsx)(j,{to:`/training`,children:`Training`})]}),(0,M.jsxs)(`nav`,{className:`gryphon-footer__column`,"aria-label":`Solutions links`,children:[(0,M.jsx)(`h2`,{children:`Solutions`}),(0,M.jsx)(j,{to:`/solutions#saksham`,children:`SAKSHAM`}),(0,M.jsx)(j,{to:`/solutions#spider`,children:`SPIDER`}),(0,M.jsx)(j,{to:`/solutions#oversight`,children:`OVERSIGHT`}),(0,M.jsx)(j,{to:`/solutions#lawsync`,children:`LawSync`})]}),(0,M.jsxs)(`div`,{className:`gryphon-footer__column gryphon-footer__office`,children:[(0,M.jsx)(`h2`,{children:`Mumbai Office`}),(0,M.jsx)(`a`,{href:lr,target:`_blank`,rel:`noopener noreferrer`,children:`Unit No. 220, 2nd Floor, Gryphon Cyber Pvt Ltd, T V Industrial Estate, Hind Cycle Marg, Worli, Mumbai, Maharashtra 400030`}),(0,M.jsx)(`h2`,{className:`gryphon-footer__second-office`,children:`Delhi Office`}),(0,M.jsx)(`a`,{href:ur,target:`_blank`,rel:`noopener noreferrer`,children:`H-1, Upasana Building, J-1, Hailey Rd, Hamdard Nagar, Vakil Lane, Mandi House, New Delhi, Delhi 110001`})]})]}),(0,M.jsxs)(`div`,{className:`gryphon-footer__bottom`,children:[(0,M.jsxs)(`span`,{children:[`© `,new Date().getFullYear(),` Gryphon Cyber Pvt. Ltd.`]}),(0,M.jsx)(`span`,{children:`Cyber Intelligence · Ground Operations`})]})]})}function fr(){return(0,_.useEffect)(()=>{let e=document.querySelector(`header.navbar.gryphon-standard-navbar`);if(!e)return;e.classList.remove(`navbar-scroll-hidden`);let t=Math.max(window.scrollY||0,0),n=0,r=0,i=()=>{let i=Math.max(window.scrollY||0,0),a=!!e.querySelector(`button[aria-expanded="true"]`);if(i<=45||a){e.classList.remove(`navbar-scroll-hidden`),t=i,n=0,r=0;return}let o=i-t;if(o===0)return;let s=o>0?1:-1;s!==r&&(n=0,r=s),n+=Math.abs(o),t=i,n>=7&&(s>0?e.classList.add(`navbar-scroll-hidden`):e.classList.remove(`navbar-scroll-hidden`),n=0)};return window.addEventListener(`scroll`,i,{passive:!0}),()=>{window.removeEventListener(`scroll`,i),e.classList.remove(`navbar-scroll-hidden`)}},[]),(0,M.jsxs)(M.Fragment,{children:[(0,M.jsx)(`img`,{src:Un,alt:`Gryphon Cyber Private Limited`,className:`navbar-logo`}),(0,M.jsxs)(`span`,{className:`navbar-company-name`,children:[(0,M.jsx)(`span`,{className:`navbar-company-main`,children:`GRYPHON CYBER`}),(0,M.jsx)(`span`,{className:`navbar-company-sub`,children:`PRIVATE LIMITED`})]})]})}function pr(){let[e,t]=(0,_.useState)(!1);return(0,_.useEffect)(()=>{let e=document.querySelectorAll(`.story-intro, .intelligence-network, .network-trust-logos, .services-story-heading, .story-service-card, .product-story`),t=new IntersectionObserver(e=>{e.forEach(e=>{e.isIntersecting&&e.target.classList.add(`story-visible`)})},{threshold:.15});return e.forEach(e=>{e.classList.add(`story-hidden`),t.observe(e)}),()=>{t.disconnect()}},[]),(0,M.jsxs)(`div`,{className:`app`,children:[(0,M.jsxs)(`header`,{className:`navbar gryphon-standard-navbar`,children:[(0,M.jsxs)(`div`,{className:`nav-container`,children:[(0,M.jsx)(j,{to:`/`,className:`logo-link`,onClick:()=>t(!1),children:(0,M.jsx)(fr,{})}),(0,M.jsxs)(`nav`,{className:`nav-links`,children:[(0,M.jsx)(j,{to:`/`,className:`active`,children:`Home`}),(0,M.jsx)(j,{to:`/about`,children:`About`}),(0,M.jsx)(j,{to:`/services`,children:`Services`}),(0,M.jsx)(j,{to:`/solutions`,children:`Solutions`}),(0,M.jsx)(j,{to:`/engagements`,children:`Engagements`}),(0,M.jsx)(j,{to:`/training`,children:`Training`}),(0,M.jsx)(j,{to:`/contact`,children:`Contact`})]}),(0,M.jsxs)(j,{to:`/book-demo`,className:`demo-button`,children:[`Book a Demo`,(0,M.jsx)(`span`,{children:`→`})]}),(0,M.jsxs)(`button`,{type:`button`,className:`mobile-menu-toggle ${e?`open`:``}`,"aria-label":e?`Close menu`:`Open menu`,"aria-expanded":e,onClick:()=>t(!e),children:[(0,M.jsx)(`span`,{}),(0,M.jsx)(`span`,{}),(0,M.jsx)(`span`,{})]})]}),(0,M.jsxs)(`div`,{className:`mobile-nav-menu ${e?`show`:``}`,children:[(0,M.jsx)(j,{to:`/`,className:`mobile-active`,onClick:()=>t(!1),children:`Home`}),(0,M.jsx)(j,{to:`/about`,onClick:()=>t(!1),children:`About`}),(0,M.jsx)(j,{to:`/services`,onClick:()=>t(!1),children:`Services`}),(0,M.jsx)(j,{to:`/solutions`,onClick:()=>t(!1),children:`Solutions`}),(0,M.jsx)(j,{to:`/engagements`,onClick:()=>t(!1),children:`Engagements`}),(0,M.jsx)(j,{to:`/training`,onClick:()=>t(!1),children:`Training`}),(0,M.jsx)(j,{to:`/contact`,onClick:()=>t(!1),children:`Contact`}),(0,M.jsxs)(j,{to:`/book-demo`,className:`mobile-demo-button`,onClick:()=>t(!1),children:[`Book a Demo `,(0,M.jsx)(`span`,{children:`→`})]})]}),(0,M.jsx)(`style`,{children:`

          /* Mobile-only additions.

             Desktop navbar keeps the existing App.css appearance. */

          .mobile-menu-toggle,

          .mobile-nav-menu {

            display: none;

          }

          @media (max-width: 760px) {

            .navbar .nav-links,

            .navbar .demo-button {

              display: none !important;

            }

            .navbar .nav-container {

              position: relative !important;

            }

            .mobile-menu-toggle {

              width: 44px !important;

              height: 44px !important;

              display: flex !important;

              flex-direction: column !important;

              align-items: center !important;

              justify-content: center !important;

              gap: 5px !important;

              margin-left: auto !important;

              padding: 0 !important;

              border: 1px solid rgba(34, 211, 238, .35) !important;

              border-radius: 8px !important;

              background: rgba(7, 20, 38, .90) !important;

              cursor: pointer !important;

            }

            .mobile-menu-toggle span {

              width: 21px !important;

              height: 2px !important;

              display: block !important;

              border-radius: 10px !important;

              background: #ffffff !important;

              transition:

                transform .25s ease,

                opacity .2s ease !important;

            }

            .mobile-menu-toggle.open span:nth-child(1) {

              transform: translateY(7px) rotate(45deg) !important;

            }

            .mobile-menu-toggle.open span:nth-child(2) {

              opacity: 0 !important;

            }

            .mobile-menu-toggle.open span:nth-child(3) {

              transform: translateY(-7px) rotate(-45deg) !important;

            }

            .mobile-nav-menu {

              position: absolute !important;

              top: 100% !important;

              left: 0 !important;

              right: 0 !important;

              display: flex !important;

              flex-direction: column !important;

              box-sizing: border-box !important;

              padding: 10px 18px 18px !important;

              background: rgba(4, 12, 24, .98) !important;

              backdrop-filter: blur(18px) !important;

              -webkit-backdrop-filter: blur(18px) !important;

              border-top: 1px solid rgba(34, 211, 238, .12) !important;

              border-bottom: 1px solid rgba(34, 211, 238, .18) !important;

              box-shadow: 0 18px 40px rgba(0, 0, 0, .45) !important;

              transform: translateY(-12px) !important;

              opacity: 0 !important;

              visibility: hidden !important;

              pointer-events: none !important;

              transition:

                opacity .22s ease,

                transform .22s ease,

                visibility .22s ease !important;

            }

            .mobile-nav-menu.show {

              transform: translateY(0) !important;

              opacity: 1 !important;

              visibility: visible !important;

              pointer-events: auto !important;

            }

            .mobile-nav-menu a {

              width: 100% !important;

              box-sizing: border-box !important;

              padding: 14px 12px !important;

              color: #ffffff !important;

              font-size: 15px !important;

              font-weight: 500 !important;

              text-decoration: none !important;

              border-bottom: 1px solid rgba(255,255,255,.06) !important;

            }

            .mobile-nav-menu a:hover,

            .mobile-nav-menu a.mobile-active {

              color: #22d3ee !important;

            }

            .mobile-demo-button {

              display: flex !important;

              align-items: center !important;

              justify-content: center !important;

              gap: 10px !important;

              margin-top: 12px !important;

              border: 0 !important;

              border-radius: 8px !important;

              background: #ffffff !important;

              color: #071426 !important;

              font-weight: 700 !important;

            }

            .mobile-demo-button span {

              font-size: 19px !important;

            }

          }

          @media (max-width: 420px) {

            .mobile-menu-toggle {

              width: 42px !important;

              height: 42px !important;

            }

            .mobile-nav-menu {

              padding-left: 14px !important;

              padding-right: 14px !important;

            }

          }

        `})]}),(0,M.jsxs)(`main`,{children:[(0,M.jsx)(`section`,{className:`hero gc-home-hero`,id:`home`,style:{"--gc-hero-bg":`url("${Hn}")`},children:(0,M.jsxs)(`div`,{className:`hero-content gc-home-hero-content`,children:[(0,M.jsx)(`div`,{className:`hero-badge`,children:`CYBER INTELLIGENCE • GROUND OPERATIONS`}),(0,M.jsxs)(`h1`,{children:[`We serve who`,(0,M.jsx)(`span`,{children:`serves the nation`})]}),(0,M.jsx)(`p`,{className:`hero-description`,children:`Gryphon Cyber delivers cyber intelligence, investigative expertise and ground operations for complex investigations, intelligence gathering and digital security.`}),(0,M.jsxs)(`div`,{className:`hero-buttons`,children:[(0,M.jsxs)(`a`,{href:`#/solutions`,className:`primary-button`,children:[`Explore Solutions`,(0,M.jsx)(`span`,{children:`→`})]}),(0,M.jsxs)(`a`,{href:`#/about`,className:`secondary-button`,children:[`Discover Gryphon`,(0,M.jsx)(`span`,{children:`↗`})]})]}),(0,M.jsxs)(`div`,{className:`hero-features`,children:[(0,M.jsxs)(`div`,{className:`hero-feature`,children:[(0,M.jsx)(`span`,{className:`feature-number`,children:`01`}),(0,M.jsxs)(`div`,{children:[(0,M.jsx)(`strong`,{children:`Intelligence`}),(0,M.jsx)(`small`,{children:`Data-driven insight`})]})]}),(0,M.jsxs)(`div`,{className:`hero-feature`,children:[(0,M.jsx)(`span`,{className:`feature-number`,children:`02`}),(0,M.jsxs)(`div`,{children:[(0,M.jsx)(`strong`,{children:`Mission`}),(0,M.jsx)(`small`,{children:`Operational precision`})]})]}),(0,M.jsxs)(`div`,{className:`hero-feature`,children:[(0,M.jsx)(`span`,{className:`feature-number`,children:`03`}),(0,M.jsxs)(`div`,{children:[(0,M.jsx)(`strong`,{children:`Trusted`}),(0,M.jsx)(`small`,{children:`Built for complex realities`})]})]})]})]})}),(0,M.jsxs)(`section`,{className:`intelligence-story`,children:[(0,M.jsxs)(`div`,{className:`story-intro`,children:[(0,M.jsx)(`div`,{className:`story-label`,children:`01 — THE GRYPHON APPROACH`}),(0,M.jsxs)(`h2`,{children:[`From information`,(0,M.jsx)(`span`,{children:`to intelligence.`})]}),(0,M.jsx)(`p`,{children:`We transform complex information into actionable intelligence through technology, investigation, training and operational expertise.`})]}),(0,M.jsxs)(`div`,{className:`intelligence-network`,children:[(0,M.jsx)(`div`,{className:`network-orbit orbit-one`}),(0,M.jsx)(`div`,{className:`network-orbit orbit-two`}),(0,M.jsx)(`div`,{className:`network-orbit orbit-three`}),(0,M.jsx)(`div`,{className:`network-core`,"aria-label":`Gryphon Cyber company logo`,children:(0,M.jsx)(`img`,{src:Un,alt:`Gryphon Cyber`,className:`network-core-logo`})}),(0,M.jsx)(`div`,{className:`network-node node-1`,children:(0,M.jsx)(`span`,{children:`DATA`})}),(0,M.jsx)(`div`,{className:`network-node node-2`,children:(0,M.jsx)(`span`,{children:`ANALYSIS`})}),(0,M.jsx)(`div`,{className:`network-node node-3`,children:(0,M.jsx)(`span`,{children:`SECURITY`})}),(0,M.jsx)(`div`,{className:`network-node node-4`,children:(0,M.jsx)(`span`,{children:`ACTION`})}),(0,M.jsx)(`div`,{className:`network-line line-1`}),(0,M.jsx)(`div`,{className:`network-line line-2`}),(0,M.jsx)(`div`,{className:`network-line line-3`}),(0,M.jsx)(`div`,{className:`network-line line-4`})]}),(0,M.jsxs)(`div`,{className:`network-trust-logos`,children:[(0,M.jsxs)(`div`,{className:`network-trust-heading`,children:[(0,M.jsx)(`span`,{children:`CONNECTED INSTITUTIONAL ECOSYSTEM`}),(0,M.jsx)(`h3`,{children:`Built around trusted networks.`})]}),(0,M.jsxs)(`div`,{className:`network-trust-grid`,children:[(0,M.jsx)(`div`,{className:`network-trust-logo`,children:(0,M.jsx)(`img`,{src:`./logos/trust/maharashtra-police.png`,alt:`Maharashtra Police`,loading:`lazy`})}),(0,M.jsx)(`div`,{className:`network-trust-logo`,children:(0,M.jsx)(`img`,{src:`./logos/trust/indian-army.png`,alt:`Indian Army`,loading:`lazy`})}),(0,M.jsx)(`div`,{className:`network-trust-logo`,children:(0,M.jsx)(`img`,{src:`./logos/trust/indianoil.png`,alt:`IndianOil`,loading:`lazy`})}),(0,M.jsx)(`div`,{className:`network-trust-logo`,children:(0,M.jsx)(`img`,{src:`./logos/trust/hdfc-bank.png`,alt:`HDFC Bank`,loading:`lazy`})}),(0,M.jsx)(`div`,{className:`network-trust-logo`,children:(0,M.jsx)(`img`,{src:`./logos/trust/enforcement-directorate.png`,alt:`Enforcement Directorate`,loading:`lazy`})}),(0,M.jsx)(`div`,{className:`network-trust-logo`,children:(0,M.jsx)(`img`,{src:`./logos/trust/dggi.png`,alt:`Directorate General of GST Intelligence`,loading:`lazy`})}),(0,M.jsx)(`div`,{className:`network-trust-logo`,children:(0,M.jsx)(`img`,{src:`./logos/trust/intelligence-bureau.png`,alt:`Intelligence Bureau`,loading:`lazy`})}),(0,M.jsx)(`div`,{className:`network-trust-logo`,children:(0,M.jsx)(`img`,{src:`./logos/trust/bsf.png`,alt:`Border Security Force`,loading:`lazy`})}),(0,M.jsx)(`div`,{className:`network-trust-logo`,children:(0,M.jsx)(`img`,{src:`./logos/trust/ministry-home-affairs.png`,alt:`Ministry of Home Affairs`,loading:`lazy`})}),(0,M.jsx)(`div`,{className:`network-trust-logo`,children:(0,M.jsx)(`img`,{src:`./logos/trust/ministry-defence.png`,alt:`Ministry of Defence`,loading:`lazy`})}),(0,M.jsx)(`div`,{className:`network-trust-logo network-trust-existing`,children:(0,M.jsx)(`img`,{src:`./logos/service-logo-1.png`,alt:`Maharashtra Police institutional logo`,loading:`lazy`})}),(0,M.jsx)(`div`,{className:`network-trust-logo network-trust-existing`,children:(0,M.jsx)(`img`,{src:`./logos/service-logo-2.png`,alt:`Arunachal Pradesh Police institutional logo`,loading:`lazy`})}),(0,M.jsx)(`div`,{className:`network-trust-logo network-trust-existing`,children:(0,M.jsx)(`img`,{src:`./logos/service-logo-3.png`,alt:`Chhattisgarh Police institutional logo`,loading:`lazy`})}),(0,M.jsx)(`div`,{className:`network-trust-logo network-trust-existing`,children:(0,M.jsx)(`img`,{src:`./logos/service-logo-4.png`,alt:`West Bengal Police institutional logo`,loading:`lazy`})})]})]}),(0,M.jsxs)(`div`,{className:`services-story`,children:[(0,M.jsx)(`div`,{className:`story-label`,children:`02 — WHAT WE DO`}),(0,M.jsxs)(`div`,{className:`services-story-heading`,children:[(0,M.jsxs)(`h2`,{children:[`Intelligence`,(0,M.jsx)(`span`,{children:`in action.`})]}),(0,M.jsx)(`p`,{children:`Four capabilities designed to support complex investigations, operational challenges and digital security requirements.`})]}),(0,M.jsxs)(`div`,{className:`services-story-grid`,children:[(0,M.jsxs)(`article`,{className:`story-service-card`,children:[(0,M.jsx)(`div`,{className:`story-service-number`,children:`01`}),(0,M.jsx)(`div`,{className:`story-service-icon`,"aria-hidden":`true`,children:(0,M.jsxs)(`svg`,{className:`story-service-svg`,viewBox:`0 0 48 48`,fill:`none`,stroke:`currentColor`,strokeWidth:`1.8`,strokeLinecap:`round`,strokeLinejoin:`round`,children:[(0,M.jsx)(`path`,{d:`M5 18 24 8l19 10-19 10L5 18Z`}),(0,M.jsx)(`path`,{d:`M13 23v10c7 6 15 6 22 0V23`}),(0,M.jsx)(`path`,{d:`M43 19v13`}),(0,M.jsx)(`circle`,{cx:`43`,cy:`35`,r:`2`,fill:`currentColor`})]})}),(0,M.jsx)(`h3`,{children:`Training Programs`}),(0,M.jsx)(`p`,{children:`Comprehensive knowledge and practical skills for investigators handling real-world scenarios.`}),(0,M.jsxs)(`div`,{className:`story-service-list`,children:[(0,M.jsx)(`span`,{children:`Crime Investigation Techniques`}),(0,M.jsx)(`span`,{children:`Cyber Forensic Skills`}),(0,M.jsx)(`span`,{children:`Scenario-based Simulation`})]})]}),(0,M.jsxs)(`article`,{className:`story-service-card`,children:[(0,M.jsx)(`div`,{className:`story-service-number`,children:`02`}),(0,M.jsx)(`div`,{className:`story-service-icon`,"aria-hidden":`true`,children:(0,M.jsxs)(`svg`,{className:`story-service-svg`,viewBox:`0 0 48 48`,fill:`none`,stroke:`currentColor`,strokeWidth:`1.8`,strokeLinecap:`round`,strokeLinejoin:`round`,children:[(0,M.jsx)(`path`,{d:`M8 25v-4a16 16 0 0 1 32 0v4`}),(0,M.jsx)(`rect`,{x:`6`,y:`22`,width:`8`,height:`13`,rx:`3`}),(0,M.jsx)(`rect`,{x:`34`,y:`22`,width:`8`,height:`13`,rx:`3`}),(0,M.jsx)(`path`,{d:`M38 35c-2 5-7 7-14 7h-4`}),(0,M.jsx)(`path`,{d:`M20 42h5`})]})}),(0,M.jsx)(`h3`,{children:`Expert Consultation`}),(0,M.jsx)(`p`,{children:`Personalized guidance on IT strategies and cybersecurity for complex operational challenges.`}),(0,M.jsxs)(`div`,{className:`story-service-list`,children:[(0,M.jsx)(`span`,{children:`Strategic IT Planning`}),(0,M.jsx)(`span`,{children:`Cybersecurity Audits`}),(0,M.jsx)(`span`,{children:`Digital Risk Assessment`})]})]}),(0,M.jsxs)(`article`,{className:`story-service-card`,children:[(0,M.jsx)(`div`,{className:`story-service-number`,children:`03`}),(0,M.jsx)(`div`,{className:`story-service-icon`,"aria-hidden":`true`,children:(0,M.jsxs)(`svg`,{className:`story-service-svg`,viewBox:`0 0 48 48`,fill:`none`,stroke:`currentColor`,strokeWidth:`1.8`,strokeLinecap:`round`,strokeLinejoin:`round`,children:[(0,M.jsx)(`path`,{d:`M15 35h20a9 9 0 0 0 1-18 13 13 0 0 0-25-2 10 10 0 0 0 4 20Z`}),(0,M.jsx)(`path`,{d:`M16 25h5l3-5 4 10 3-5h4`}),(0,M.jsx)(`circle`,{cx:`24`,cy:`25`,r:`2`,fill:`currentColor`})]})}),(0,M.jsx)(`h3`,{children:`Digital Transformation`}),(0,M.jsx)(`p`,{children:`Cloud computing and data analytics solutions designed to streamline operations and improve efficiency.`}),(0,M.jsxs)(`div`,{className:`story-service-list`,children:[(0,M.jsx)(`span`,{children:`Cloud Infrastructure Setup`}),(0,M.jsx)(`span`,{children:`Data Analytics Implementation`}),(0,M.jsx)(`span`,{children:`Process Automation`})]})]}),(0,M.jsxs)(`article`,{className:`story-service-card`,children:[(0,M.jsx)(`div`,{className:`story-service-number`,children:`04`}),(0,M.jsx)(`div`,{className:`story-service-icon`,"aria-hidden":`true`,children:(0,M.jsxs)(`svg`,{className:`story-service-svg`,viewBox:`0 0 48 48`,fill:`none`,stroke:`currentColor`,strokeWidth:`1.8`,strokeLinecap:`round`,strokeLinejoin:`round`,children:[(0,M.jsx)(`path`,{d:`M24 5 40 11v12c0 10-7 17-16 20C15 40 8 33 8 23V11l16-6Z`}),(0,M.jsx)(`path`,{d:`m16 24 6 6 11-12`}),(0,M.jsx)(`path`,{d:`M8 11 24 18l16-7`})]})}),(0,M.jsx)(`h3`,{children:`Security Solutions`}),(0,M.jsx)(`p`,{children:`Robust protection for digital assets, networks and sensitive data against security threats.`}),(0,M.jsxs)(`div`,{className:`story-service-list`,children:[(0,M.jsx)(`span`,{children:`Network Security Hardening`}),(0,M.jsx)(`span`,{children:`Threat Monitoring Systems`}),(0,M.jsx)(`span`,{children:`Breach Prevention Protocols`})]})]})]})]}),(0,M.jsxs)(`div`,{className:`product-story`,children:[(0,M.jsx)(`div`,{className:`story-label`,children:`03 — INTEGRATED PRODUCT SUITE`}),(0,M.jsxs)(`h2`,{children:[`One ecosystem.`,(0,M.jsx)(`span`,{children:`Multiple intelligence capabilities.`})]}),(0,M.jsx)(`p`,{className:`product-story-description`,children:`A unified ecosystem designed for the Indian intelligence landscape, integrating predictive analysis, search and network mapping.`}),(0,M.jsxs)(`div`,{className:`product-story-grid`,children:[(0,M.jsxs)(j,{to:`/solutions#saksham`,className:`product-story-card`,children:[(0,M.jsx)(`span`,{className:`product-code`,children:`SAKSHAM`}),(0,M.jsx)(`h3`,{children:`Advanced Intelligence Analysis`}),(0,M.jsx)(`p`,{children:`Predictive behavioral analysis and threat quantification.`}),(0,M.jsx)(`span`,{className:`product-arrow`,children:`→`})]}),(0,M.jsxs)(j,{to:`/solutions#spider`,className:`product-story-card`,children:[(0,M.jsx)(`span`,{className:`product-code`,children:`SPIDER`}),(0,M.jsx)(`h3`,{children:`Unified Intelligence Search`}),(0,M.jsx)(`p`,{children:`Federated search across 20+ data sources.`}),(0,M.jsx)(`span`,{className:`product-arrow`,children:`→`})]}),(0,M.jsxs)(j,{to:`/solutions#oversight`,className:`product-story-card`,children:[(0,M.jsx)(`span`,{className:`product-code`,children:`OVERSIGHT`}),(0,M.jsx)(`h3`,{children:`Deep Network Analysis`}),(0,M.jsx)(`p`,{children:`Big-data link analysis for complex networks.`}),(0,M.jsx)(`span`,{className:`product-arrow`,children:`→`})]}),(0,M.jsxs)(j,{to:`/solutions#lawsync`,className:`product-story-card`,children:[(0,M.jsx)(`span`,{className:`product-code`,children:`LAWSYNC`}),(0,M.jsx)(`h3`,{children:`Law Enforcement & Intelligence`}),(0,M.jsx)(`p`,{children:`Unified real-time coordination and data management.`}),(0,M.jsx)(`span`,{className:`product-arrow`,children:`→`})]})]})]})]}),(0,M.jsx)(`section`,{className:`trust-strip`,children:(0,M.jsxs)(`div`,{className:`trust-container`,children:[(0,M.jsxs)(`div`,{className:`trust-item`,children:[(0,M.jsx)(`span`,{className:`trust-line`}),(0,M.jsx)(`span`,{children:`CYBER INTELLIGENCE`})]}),(0,M.jsxs)(`div`,{className:`trust-item`,children:[(0,M.jsx)(`span`,{className:`trust-line`}),(0,M.jsx)(`span`,{children:`GROUND OPERATIONS`})]}),(0,M.jsxs)(`div`,{className:`trust-item`,children:[(0,M.jsx)(`span`,{className:`trust-line`}),(0,M.jsx)(`span`,{children:`INVESTIGATIONS`})]}),(0,M.jsxs)(`div`,{className:`trust-item`,children:[(0,M.jsx)(`span`,{className:`trust-line`}),(0,M.jsx)(`span`,{children:`DIGITAL SECURITY`})]})]})})]}),(0,M.jsx)(dr,{})]})}var mr=[{src:`./logos/trust/maharashtra-police.png`,alt:`Maharashtra Police`},{src:`./logos/trust/indian-army.png`,alt:`Indian Army`},{src:`./logos/trust/indianoil.png`,alt:`IndianOil`},{src:`./logos/trust/hdfc-bank.png`,alt:`HDFC Bank`},{src:`./logos/trust/enforcement-directorate.png`,alt:`Enforcement Directorate`},{src:`./logos/trust/dggi.png`,alt:`Directorate General of GST Intelligence`},{src:`./logos/trust/intelligence-bureau.png`,alt:`Intelligence Bureau`},{src:`./logos/trust/bsf.png`,alt:`Border Security Force`},{src:`./logos/trust/ministry-home-affairs.png`,alt:`Ministry of Home Affairs`},{src:`./logos/trust/ministry-defence.png`,alt:`Ministry of Defence`},{src:`./logos/service-logo-1.png`,alt:`Maharashtra Police`},{src:`./logos/service-logo-2.png`,alt:`Arunachal Pradesh Police`},{src:`./logos/service-logo-3.png`,alt:`Chhattisgarh Police`},{src:`./logos/service-logo-4.png`,alt:`West Bengal Police`}];function hr(){let[e,t]=(0,_.useState)(!1),[n,r]=(0,_.useState)(()=>typeof window<`u`&&window.innerWidth<=760);return(0,_.useEffect)(()=>{let e=window.matchMedia(`(max-width: 760px)`),n=e=>{r(e.matches),e.matches||t(!1)};return r(e.matches),e.addEventListener(`change`,n),()=>{e.removeEventListener(`change`,n)}},[]),(0,_.useEffect)(()=>{let e=document.querySelectorAll(`.about-reveal, .about-capability-card, .about-why-item, .about-leader-card, .about-trust-section, .about-trust-card`),t=new IntersectionObserver(e=>{e.forEach(e=>{e.isIntersecting&&e.target.classList.add(`about-visible`)})},{threshold:.12});return e.forEach(e=>t.observe(e)),()=>{t.disconnect()}},[]),(0,M.jsxs)(`div`,{className:`about-page`,children:[(0,M.jsxs)(`header`,{className:`navbar gryphon-standard-navbar`,children:[(0,M.jsxs)(`div`,{className:`nav-container`,children:[(0,M.jsx)(j,{to:`/`,className:`logo-link`,onClick:()=>t(!1),children:(0,M.jsx)(fr,{})}),!n&&(0,M.jsxs)(M.Fragment,{children:[(0,M.jsxs)(`nav`,{className:`nav-links`,children:[(0,M.jsx)(j,{to:`/`,children:`Home`}),(0,M.jsx)(j,{to:`/about`,className:`active`,children:`About`}),(0,M.jsx)(j,{to:`/services`,children:`Services`}),(0,M.jsx)(j,{to:`/solutions`,children:`Solutions`}),(0,M.jsx)(j,{to:`/training`,children:`Training`}),(0,M.jsx)(j,{to:`/contact`,children:`Contact`})]}),(0,M.jsxs)(j,{to:`/contact`,className:`talk-button`,children:[`Talk to Us`,(0,M.jsx)(`span`,{children:`→`})]})]}),n&&(0,M.jsxs)(`button`,{type:`button`,className:`about-mobile-toggle ${e?`open`:``}`,"aria-label":e?`Close menu`:`Open menu`,"aria-expanded":e,onClick:()=>t(!e),children:[(0,M.jsx)(`span`,{}),(0,M.jsx)(`span`,{}),(0,M.jsx)(`span`,{})]})]}),n&&e&&(0,M.jsxs)(`div`,{className:`about-mobile-menu`,children:[(0,M.jsx)(j,{to:`/`,onClick:()=>t(!1),children:`Home`}),(0,M.jsx)(j,{to:`/about`,className:`mobile-active`,onClick:()=>t(!1),children:`About`}),(0,M.jsx)(j,{to:`/services`,onClick:()=>t(!1),children:`Services`}),(0,M.jsx)(j,{to:`/solutions`,onClick:()=>t(!1),children:`Solutions`}),(0,M.jsx)(j,{to:`/training`,onClick:()=>t(!1),children:`Training`}),(0,M.jsx)(j,{to:`/contact`,onClick:()=>t(!1),children:`Contact`}),(0,M.jsxs)(j,{to:`/contact`,className:`about-mobile-talk`,onClick:()=>t(!1),children:[`Talk to Us`,(0,M.jsx)(`span`,{children:`→`})]})]}),(0,M.jsx)(`style`,{children:`

          /* ABOUT MOBILE NAVIGATION */

          .about-mobile-toggle {

            width: 44px !important;

            height: 44px !important;

            display: flex !important;

            flex-direction: column !important;

            align-items: center !important;

            justify-content: center !important;

            gap: 5px !important;

            margin-left: auto !important;

            padding: 0 !important;

            border: 1px solid rgba(34, 211, 238, 0.35) !important;

            border-radius: 8px !important;

            background: rgba(7, 20, 38, 0.90) !important;

            cursor: pointer !important;

            outline: none !important;

            -webkit-tap-highlight-color: transparent !important;

            flex-shrink: 0 !important;

          }

          .about-mobile-toggle span {

            width: 21px !important;

            height: 2px !important;

            display: block !important;

            border-radius: 10px !important;

            background: #ffffff !important;

            transition: transform 0.25s ease, opacity 0.2s ease !important;

          }

          .about-mobile-toggle.open span:nth-child(1) {

            transform: translateY(7px) rotate(45deg) !important;

          }

          .about-mobile-toggle.open span:nth-child(2) {

            opacity: 0 !important;

          }

          .about-mobile-toggle.open span:nth-child(3) {

            transform: translateY(-7px) rotate(-45deg) !important;

          }

          .about-mobile-menu {

            position: absolute !important;

            top: 100% !important;

            left: 0 !important;

            right: 0 !important;

            display: flex !important;

            flex-direction: column !important;

            box-sizing: border-box !important;

            padding: 10px 18px 18px !important;

            background: rgba(4, 12, 24, 0.98) !important;

            backdrop-filter: blur(18px) !important;

            -webkit-backdrop-filter: blur(18px) !important;

            border-top: 1px solid rgba(34, 211, 238, 0.12) !important;

            border-bottom: 1px solid rgba(34, 211, 238, 0.18) !important;

            box-shadow: 0 18px 40px rgba(0, 0, 0, 0.45) !important;

            z-index: 99999 !important;

          }

          .about-mobile-menu a {

            width: 100% !important;

            box-sizing: border-box !important;

            padding: 14px 12px !important;

            color: #ffffff !important;

            font-size: 15px !important;

            font-weight: 500 !important;

            line-height: 1.3 !important;

            text-decoration: none !important;

            border-bottom: 1px solid rgba(255, 255, 255, 0.06) !important;

            transition: color 0.2s ease, background 0.2s ease !important;

          }

          .about-mobile-menu a:hover,

          .about-mobile-menu a.mobile-active {

            color: #22d3ee !important;

          }

          .about-mobile-talk {

            display: flex !important;

            align-items: center !important;

            justify-content: center !important;

            gap: 10px !important;

            margin-top: 12px !important;

            padding: 13px 16px !important;

            border: 0 !important;

            border-radius: 8px !important;

            background: #1764e8 !important;

            color: #ffffff !important;

            font-weight: 700 !important;

            text-decoration: none !important;

          }

          .about-mobile-talk span {

            font-size: 19px !important;

            color: #ffffff !important;

          }

          .about-mobile-talk:hover {

            background: #1764e8 !important;

            color: #ffffff !important;

          }

          

          @media (max-width: 420px) {

            .about-mobile-toggle {

              width: 42px !important;

              height: 42px !important;

            }

            .about-mobile-menu {

              padding-left: 14px !important;

              padding-right: 14px !important;

            }

          }

        `})]}),(0,M.jsxs)(`main`,{children:[(0,M.jsxs)(`section`,{className:`about-hero`,children:[(0,M.jsx)(`div`,{className:`about-hero-grid`}),(0,M.jsx)(`div`,{className:`about-hero-glow about-glow-one`}),(0,M.jsx)(`div`,{className:`about-hero-glow about-glow-two`}),(0,M.jsxs)(`div`,{className:`about-hero-content`,children:[(0,M.jsxs)(`div`,{className:`about-eyebrow about-brand-lockup`,children:[(0,M.jsx)(`img`,{src:Un,alt:`Gryphon Cyber Logo`,className:`about-brand-logo`}),(0,M.jsxs)(`span`,{className:`about-brand-name`,children:[(0,M.jsx)(`span`,{className:`about-brand-main`,children:`GRYPHON CYBER`}),(0,M.jsx)(`span`,{className:`about-brand-sub`,children:`PRIVATE LIMITED`})]})]}),(0,M.jsxs)(`h1`,{children:[`Beyond the`,(0,M.jsx)(`span`,{children:`Visible.`})]}),(0,M.jsx)(`p`,{children:`Cyber intelligence, investigative expertise and ground operations designed for complex missions, intelligence gathering and digital security.`}),(0,M.jsxs)(`div`,{className:`about-hero-actions`,children:[(0,M.jsxs)(j,{to:`/solutions`,className:`about-primary-button`,children:[`Explore Intelligence`,(0,M.jsx)(`span`,{children:`→`})]}),(0,M.jsxs)(`a`,{href:`#who-we-are`,className:`about-secondary-button`,onClick:e=>{e.preventDefault(),document.getElementById(`who-we-are`)?.scrollIntoView({behavior:`smooth`,block:`start`})},children:[`Discover Gryphon`,(0,M.jsx)(`span`,{children:`↓`})]})]}),(0,M.jsxs)(`div`,{className:`about-hero-meta`,children:[(0,M.jsxs)(`div`,{children:[(0,M.jsx)(`strong`,{children:`CYBER`}),(0,M.jsx)(`span`,{children:`INTELLIGENCE`})]}),(0,M.jsxs)(`div`,{children:[(0,M.jsx)(`strong`,{children:`GROUND`}),(0,M.jsx)(`span`,{children:`OPERATIONS`})]}),(0,M.jsxs)(`div`,{children:[(0,M.jsx)(`strong`,{children:`DIGITAL`}),(0,M.jsx)(`span`,{children:`SECURITY`})]})]})]}),(0,M.jsxs)(`div`,{className:`about-core-stage`,children:[(0,M.jsx)(`div`,{className:`about-core-label core-label-top`,children:`CYBER INTELLIGENCE CORE`}),(0,M.jsx)(`div`,{className:`about-core-label core-label-right`,children:`SECURITY / 01`}),(0,M.jsx)(`div`,{className:`about-core-label core-label-bottom`,children:`INTELLIGENCE • INVESTIGATION • SECURITY`}),(0,M.jsxs)(`div`,{className:`cyber-core-scene`,"aria-hidden":`true`,children:[(0,M.jsx)(`div`,{className:`cyber-core-haze`}),(0,M.jsxs)(`div`,{className:`cyber-orbit cyber-orbit-a`,children:[(0,M.jsx)(`span`,{className:`orbit-dot orbit-dot-1`}),(0,M.jsx)(`span`,{className:`orbit-dot orbit-dot-2`})]}),(0,M.jsx)(`div`,{className:`cyber-orbit cyber-orbit-b`,children:(0,M.jsx)(`span`,{className:`orbit-dot orbit-dot-3`})}),(0,M.jsx)(`div`,{className:`cyber-orbit cyber-orbit-c`}),(0,M.jsxs)(`div`,{className:`cyber-shield-3d`,children:[(0,M.jsx)(`div`,{className:`shield-depth shield-depth-1`}),(0,M.jsx)(`div`,{className:`shield-depth shield-depth-2`}),(0,M.jsxs)(`div`,{className:`shield-face shield-face-front`,children:[(0,M.jsx)(`span`,{className:`shield-top-line`}),(0,M.jsx)(`span`,{className:`shield-circuit circuit-1`}),(0,M.jsx)(`span`,{className:`shield-circuit circuit-2`}),(0,M.jsx)(`span`,{className:`shield-circuit circuit-3`}),(0,M.jsx)(`span`,{className:`shield-circuit circuit-4`}),(0,M.jsxs)(`span`,{className:`shield-lock`,children:[(0,M.jsx)(`span`,{className:`lock-shackle`}),(0,M.jsx)(`span`,{className:`lock-body`}),(0,M.jsx)(`span`,{className:`lock-dot`})]}),(0,M.jsx)(`span`,{className:`shield-scan`})]}),(0,M.jsx)(`div`,{className:`shield-face shield-face-back`})]}),(0,M.jsx)(`span`,{className:`intel-node node-1`}),(0,M.jsx)(`span`,{className:`intel-node node-2`}),(0,M.jsx)(`span`,{className:`intel-node node-3`}),(0,M.jsx)(`span`,{className:`intel-node node-4`}),(0,M.jsx)(`span`,{className:`intel-node node-5`}),(0,M.jsx)(`span`,{className:`intel-node node-6`}),(0,M.jsx)(`span`,{className:`data-trail trail-1`}),(0,M.jsx)(`span`,{className:`data-trail trail-2`}),(0,M.jsx)(`span`,{className:`data-trail trail-3`}),(0,M.jsx)(`div`,{className:`cyber-core-crosshair crosshair-horizontal`}),(0,M.jsx)(`div`,{className:`cyber-core-crosshair crosshair-vertical`})]}),(0,M.jsxs)(`div`,{className:`core-status`,children:[(0,M.jsx)(`span`,{className:`core-status-dot`}),(0,M.jsx)(`span`,{children:`INTELLIGENCE SYSTEM`}),(0,M.jsx)(`strong`,{children:`ONLINE`})]})]}),(0,M.jsx)(`style`,{children:`
            /* =====================================================
               CYBER SECURITY 3D CORE
               ===================================================== */
            .cyber-core-scene {
              position: absolute;
              left: 50%;
              top: 50%;
              width: 560px;
              height: 560px;
              transform: translate(-50%, -50%);
              transform-style: preserve-3d;
              perspective: 1200px;
              isolation: isolate;
            }

            .cyber-core-haze {
              position: absolute;
              left: 50%;
              top: 50%;
              width: 360px;
              height: 360px;
              transform: translate(-50%, -50%);
              border-radius: 50%;
              background: radial-gradient(circle, rgba(0, 221, 255, .28) 0%, rgba(0, 155, 255, .13) 32%, transparent 72%);
              filter: blur(28px);
              animation: cyberHazePulse 4s ease-in-out infinite;
              z-index: -4;
            }

            .cyber-orbit {
              position: absolute;
              left: 50%;
              top: 50%;
              border: 1px solid rgba(0, 218, 255, .38);
              transform-style: preserve-3d;
              border-radius: 50%;
              pointer-events: none;
            }

            .cyber-orbit-a {
              width: 400px;
              height: 138px;
              transform: translate(-50%, -50%) rotateX(68deg) rotateZ(-12deg);
              animation: cyberOrbitA 7s linear infinite;
              box-shadow: 0 0 18px rgba(0, 218, 255, .08);
            }

            .cyber-orbit-b {
              width: 430px;
              height: 430px;
              transform: translate(-50%, -50%) rotateX(67deg) rotateY(24deg);
              border-color: rgba(0, 218, 255, .22);
              animation: cyberOrbitB 11s linear infinite reverse;
            }

            .cyber-orbit-c {
              position: absolute;
              left: 50%;
              top: 50%;
              width: 300px;
              height: 300px;
              transform: translate(-50%, -50%) rotateY(68deg);
              border: 1px dashed rgba(0, 218, 255, .18);
              border-radius: 50%;
              animation: cyberOrbitC 9s linear infinite;
            }

            .orbit-dot {
              position: absolute;
              width: 7px;
              height: 7px;
              border-radius: 50%;
              background: #12ddff;
              box-shadow: 0 0 8px #12ddff, 0 0 22px rgba(18, 221, 255, .85);
            }

            .orbit-dot-1 { left: 6%; top: 50%; }
            .orbit-dot-2 { right: 12%; top: 24%; width: 5px; height: 5px; }
            .orbit-dot-3 { right: 6%; top: 48%; width: 6px; height: 6px; }

            /* 3D shield assembly */
            .cyber-shield-3d {
              position: absolute;
              left: 50%;
              top: 50%;
              width: 235px;
              height: 270px;
              transform: translate(-50%, -50%) translateZ(40px);
              transform-style: preserve-3d;
              animation: cyberShieldRotate 10s cubic-bezier(.45, .05, .25, .95) infinite;
              filter: drop-shadow(0 0 18px rgba(0, 218, 255, .22));
            }

            .shield-depth,
            .shield-face {
              position: absolute;
              inset: 0;
              clip-path: polygon(50% 0%, 94% 18%, 88% 65%, 72% 87%, 50% 100%, 28% 87%, 12% 65%, 6% 18%);
              transform-style: preserve-3d;
            }

            .shield-depth {
              background: linear-gradient(145deg, rgba(0, 216, 255, .10), rgba(0, 90, 160, .03));
              border: 1px solid rgba(0, 220, 255, .22);
            }

            .shield-depth::after {
              content: "";
              position: absolute;
              inset: 7px;
              clip-path: inherit;
              border: 1px solid rgba(0, 220, 255, .20);
            }

            .shield-depth-1 {
              transform: translateZ(-18px) translateX(-12px) translateY(8px);
              opacity: .22;
              animation: shieldDepthPulse 3s ease-in-out infinite;
            }

            .shield-depth-2 {
              transform: translateZ(-34px) translateX(-22px) translateY(16px);
              opacity: .10;
            }

            .shield-face-front {
              background:
                linear-gradient(135deg, rgba(13, 239, 255, .16), rgba(0, 62, 115, .12) 42%, rgba(0, 220, 255, .08)),
                rgba(2, 17, 29, .58);
              border: 1px solid rgba(0, 229, 255, .66);
              box-shadow: inset 0 0 45px rgba(0, 210, 255, .10), 0 0 30px rgba(0, 206, 255, .14);
              overflow: hidden;
              backface-visibility: hidden;
            }

            .shield-face-back {
              transform: rotateY(180deg) translateZ(2px);
              background: linear-gradient(135deg, rgba(0, 214, 255, .08), rgba(0, 40, 80, .16));
              border: 1px solid rgba(0, 214, 255, .30);
              backface-visibility: hidden;
            }

            .shield-top-line {
              position: absolute;
              left: 20%;
              top: 17%;
              width: 60%;
              height: 1px;
              background: linear-gradient(90deg, transparent, #12ddff, transparent);
              box-shadow: 0 0 12px rgba(18, 221, 255, .8);
            }

            .shield-circuit {
              position: absolute;
              height: 1px;
              background: linear-gradient(90deg, transparent, rgba(18, 221, 255, .72), rgba(18, 221, 255, .08));
              box-shadow: 0 0 7px rgba(18, 221, 255, .42);
              transform-origin: left center;
            }

            .circuit-1 { left: 23%; top: 31%; width: 55%; transform: rotate(7deg); }
            .circuit-2 { left: 18%; top: 53%; width: 64%; transform: rotate(-5deg); }
            .circuit-3 { left: 30%; top: 69%; width: 45%; transform: rotate(4deg); }
            .circuit-4 { left: 46%; top: 23%; width: 27%; transform: rotate(90deg); opacity: .55; }

            .shield-lock {
              position: absolute;
              left: 50%;
              top: 52%;
              width: 58px;
              height: 66px;
              transform: translate(-50%, -50%) translateZ(25px);
              filter: drop-shadow(0 0 12px rgba(18, 221, 255, .65));
            }

            .lock-shackle {
              position: absolute;
              left: 14px;
              top: 0;
              width: 30px;
              height: 30px;
              border: 4px solid #14dcff;
              border-bottom: 0;
              border-radius: 18px 18px 0 0;
            }

            .lock-body {
              position: absolute;
              left: 7px;
              bottom: 2px;
              width: 44px;
              height: 38px;
              border-radius: 6px;
              background: linear-gradient(135deg, rgba(15, 229, 255, .78), rgba(0, 106, 180, .45));
              border: 1px solid rgba(145, 245, 255, .85);
              box-shadow: inset 0 0 16px rgba(255,255,255,.12), 0 0 18px rgba(0, 220, 255, .30);
            }

            .lock-dot {
              position: absolute;
              left: 50%;
              top: 49px;
              width: 7px;
              height: 12px;
              transform: translateX(-50%);
              border-radius: 5px;
              background: #021522;
            }

            .shield-scan {
              position: absolute;
              left: 5%;
              top: -15%;
              width: 90%;
              height: 2px;
              background: linear-gradient(90deg, transparent, rgba(32, 239, 255, .95), transparent);
              box-shadow: 0 0 16px rgba(32, 239, 255, .9);
              animation: shieldScan 3.2s ease-in-out infinite;
            }

            /* Data nodes and trails */
            .intel-node {
              position: absolute;
              width: 6px;
              height: 6px;
              border-radius: 50%;
              background: #10dcff;
              box-shadow: 0 0 9px #10dcff, 0 0 24px rgba(16, 220, 255, .8);
              animation: nodeBlink 2.2s ease-in-out infinite;
            }

            .node-1 { left: 23%; top: 28%; animation-delay: -.3s; }
            .node-2 { left: 72%; top: 26%; animation-delay: -.9s; }
            .node-3 { left: 79%; top: 61%; animation-delay: -1.4s; }
            .node-4 { left: 24%; top: 68%; animation-delay: -1.8s; }
            .node-5 { left: 16%; top: 48%; width: 4px; height: 4px; }
            .node-6 { left: 84%; top: 43%; width: 4px; height: 4px; animation-delay: -1.1s; }

            .data-trail {
              position: absolute;
              height: 1px;
              width: 145px;
              background: linear-gradient(90deg, transparent, rgba(10, 215, 255, .55), transparent);
              opacity: .45;
              transform-origin: left center;
              animation: trailMove 4.5s ease-in-out infinite;
            }

            .trail-1 { left: 12%; top: 35%; transform: rotate(9deg); }
            .trail-2 { right: 7%; top: 54%; transform: rotate(-14deg); animation-delay: -1.8s; }
            .trail-3 { left: 30%; bottom: 24%; transform: rotate(-8deg); animation-delay: -3s; }

            .cyber-core-crosshair {
              position: absolute;
              background: rgba(0, 215, 255, .13);
              pointer-events: none;
            }

            .crosshair-horizontal { left: 7%; right: 7%; top: 50%; height: 1px; }
            .crosshair-vertical { top: 7%; bottom: 7%; left: 50%; width: 1px; opacity: .5; }

            @keyframes cyberShieldRotate {
              0% { transform: translate(-50%, -50%) translateZ(40px) rotateY(-22deg) rotateX(5deg) rotateZ(-2deg); }
              25% { transform: translate(-50%, -50%) translateZ(65px) rotateY(28deg) rotateX(-4deg) rotateZ(2deg); }
              50% { transform: translate(-50%, -50%) translateZ(48px) rotateY(180deg) rotateX(3deg) rotateZ(-2deg); }
              75% { transform: translate(-50%, -50%) translateZ(65px) rotateY(330deg) rotateX(-4deg) rotateZ(2deg); }
              100% { transform: translate(-50%, -50%) translateZ(40px) rotateY(338deg) rotateX(5deg) rotateZ(-2deg); }
            }

            @keyframes cyberOrbitA {
              from { transform: translate(-50%, -50%) rotateX(68deg) rotateZ(-12deg); }
              to { transform: translate(-50%, -50%) rotateX(68deg) rotateZ(348deg); }
            }

            @keyframes cyberOrbitB {
              from { transform: translate(-50%, -50%) rotateX(67deg) rotateY(24deg) rotateZ(0deg); }
              to { transform: translate(-50%, -50%) rotateX(67deg) rotateY(24deg) rotateZ(-360deg); }
            }

            @keyframes cyberOrbitC {
              from { transform: translate(-50%, -50%) rotateY(68deg) rotateZ(0deg); }
              to { transform: translate(-50%, -50%) rotateY(68deg) rotateZ(360deg); }
            }

            @keyframes cyberHazePulse {
              0%, 100% { opacity: .55; transform: translate(-50%, -50%) scale(.86); }
              50% { opacity: 1; transform: translate(-50%, -50%) scale(1.12); }
            }

            @keyframes shieldDepthPulse {
              0%, 100% { opacity: .16; }
              50% { opacity: .32; }
            }

            @keyframes shieldScan {
              0%, 12% { top: 8%; opacity: 0; }
              22% { opacity: .9; }
              75% { opacity: .65; }
              100% { top: 92%; opacity: 0; }
            }

            @keyframes nodeBlink {
              0%, 100% { opacity: .28; transform: scale(.7); }
              50% { opacity: 1; transform: scale(1.45); }
            }

            @keyframes trailMove {
              0%, 100% { opacity: .12; transform: translateX(-18px) scaleX(.7) rotate(9deg); }
              50% { opacity: .65; transform: translateX(24px) scaleX(1.1) rotate(9deg); }
            }

            @media (max-width: 900px) {
              .cyber-core-scene { width: 470px; height: 470px; }
              .cyber-shield-3d { width: 205px; height: 235px; }
              .cyber-orbit-a { width: 340px; }
              .cyber-orbit-b { width: 370px; height: 370px; }
            }

            @media (max-width: 600px) {
              .cyber-core-scene { width: 330px; height: 330px; }
              .cyber-shield-3d { width: 155px; height: 178px; }
              .cyber-orbit-a { width: 250px; height: 90px; }
              .cyber-orbit-b { width: 280px; height: 280px; }
              .cyber-orbit-c { width: 210px; height: 210px; }
              .cyber-core-haze { width: 240px; height: 240px; }
              .lock-shackle { transform: scale(.72); transform-origin: center top; }
              .lock-body { transform: scale(.72); transform-origin: center bottom; }
              .lock-dot { transform: translateX(-50%) scale(.72); }
            }

            @media (prefers-reduced-motion: reduce) {
              .cyber-core-scene *,
              .cyber-core-scene {
                animation: none !important;
              }
            }
          `})]}),(0,M.jsx)(`section`,{className:`about-section about-who`,id:`who-we-are`,style:{scrollMarginTop:`110px`},children:(0,M.jsxs)(`div`,{className:`about-section-container`,children:[(0,M.jsx)(`div`,{className:`about-section-number`,children:`01`}),(0,M.jsxs)(`div`,{className:`about-section-heading about-reveal`,children:[(0,M.jsx)(`div`,{className:`about-section-label`,children:`WHO WE ARE`}),(0,M.jsxs)(`h2`,{children:[`Intelligence`,(0,M.jsx)(`span`,{children:` beyond the obvious.`})]})]}),(0,M.jsxs)(`div`,{className:`about-who-layout`,children:[(0,M.jsxs)(`div`,{className:`about-who-text about-reveal`,children:[(0,M.jsx)(`p`,{className:`about-lead`,children:`Gryphon Cyber is a cyber intelligence and ground operations partner supporting complex investigations, intelligence gathering and digital security requirements.`}),(0,M.jsx)(`p`,{children:`We develop bespoke tools and operational capabilities tailored to demanding investigative environments.`}),(0,M.jsx)(`p`,{children:`Our work combines cyber intelligence, investigative expertise, training, consulting and operational support.`}),(0,M.jsxs)(`div`,{className:`about-inline-line`,children:[(0,M.jsx)(`span`,{}),(0,M.jsx)(`strong`,{children:`BEYOND THE VISIBLE`})]})]}),(0,M.jsxs)(`div`,{className:`about-data-architecture about-reveal`,children:[(0,M.jsx)(`div`,{className:`data-architecture-glow`}),(0,M.jsxs)(`div`,{className:`data-node data-node-one`,children:[(0,M.jsx)(`span`,{}),`INTELLIGENCE`]}),(0,M.jsxs)(`div`,{className:`data-node data-node-two`,children:[(0,M.jsx)(`span`,{}),`INVESTIGATION`]}),(0,M.jsxs)(`div`,{className:`data-node data-node-three`,children:[(0,M.jsx)(`span`,{}),`SECURITY`]}),(0,M.jsxs)(`div`,{className:`data-node data-node-four`,children:[(0,M.jsx)(`span`,{}),`OPERATIONS`]}),(0,M.jsx)(`div`,{className:`data-center`,children:(0,M.jsx)(`div`,{className:`data-center-inner`,children:`GC`})}),(0,M.jsx)(`div`,{className:`data-connection connection-one`}),(0,M.jsx)(`div`,{className:`data-connection connection-two`}),(0,M.jsx)(`div`,{className:`data-connection connection-three`}),(0,M.jsx)(`div`,{className:`data-connection connection-four`})]})]})]})}),(0,M.jsx)(`section`,{className:`about-section about-capabilities`,children:(0,M.jsxs)(`div`,{className:`about-section-container`,children:[(0,M.jsx)(`div`,{className:`about-section-number`,children:`02`}),(0,M.jsxs)(`div`,{className:`about-section-heading about-reveal`,children:[(0,M.jsx)(`div`,{className:`about-section-label`,children:`WHAT WE DO`}),(0,M.jsxs)(`h2`,{children:[`Intelligence`,(0,M.jsx)(`span`,{children:` in action.`})]}),(0,M.jsx)(`p`,{children:`Four connected capabilities supporting investigations, operational challenges and digital security.`})]}),(0,M.jsxs)(`div`,{className:`about-capability-grid`,children:[(0,M.jsxs)(`article`,{className:`about-capability-card about-reveal`,children:[(0,M.jsx)(`div`,{className:`capability-number`,children:`01`}),(0,M.jsx)(`div`,{className:`capability-icon capability-diamond`,children:(0,M.jsxs)(`svg`,{viewBox:`0 0 48 48`,fill:`none`,stroke:`currentColor`,strokeWidth:`1.8`,strokeLinecap:`round`,strokeLinejoin:`round`,"aria-hidden":`true`,children:[(0,M.jsx)(`path`,{d:`M24 8 9 20 24 40 39 20 24 8Z`}),(0,M.jsx)(`path`,{d:`M9 20h30M24 8v32M9 20l15 5 15-5M24 25v15`}),(0,M.jsx)(`circle`,{cx:`24`,cy:`8`,r:`2.5`,fill:`currentColor`}),(0,M.jsx)(`circle`,{cx:`9`,cy:`20`,r:`2.5`,fill:`currentColor`}),(0,M.jsx)(`circle`,{cx:`39`,cy:`20`,r:`2.5`,fill:`currentColor`}),(0,M.jsx)(`circle`,{cx:`24`,cy:`40`,r:`2.5`,fill:`currentColor`}),(0,M.jsx)(`circle`,{cx:`24`,cy:`25`,r:`2.5`,fill:`currentColor`})]})}),(0,M.jsxs)(`div`,{className:`capability-card-content`,children:[(0,M.jsx)(`h3`,{children:`Cyber Intelligence`}),(0,M.jsx)(`p`,{children:`Transform complex information into actionable intelligence through connected intelligence systems and advanced analysis.`}),(0,M.jsxs)(`span`,{className:`capability-link`,children:[`INTELLIGENCE`,(0,M.jsx)(`b`,{children:`→`})]})]})]}),(0,M.jsxs)(`article`,{className:`about-capability-card about-reveal`,children:[(0,M.jsx)(`div`,{className:`capability-number`,children:`02`}),(0,M.jsx)(`div`,{className:`capability-icon capability-rings`,children:(0,M.jsxs)(`svg`,{viewBox:`0 0 48 48`,fill:`none`,stroke:`currentColor`,strokeWidth:`2`,strokeLinecap:`round`,strokeLinejoin:`round`,"aria-hidden":`true`,children:[(0,M.jsx)(`circle`,{cx:`20`,cy:`20`,r:`12`}),(0,M.jsx)(`circle`,{cx:`20`,cy:`20`,r:`6`}),(0,M.jsx)(`path`,{d:`m29 29 11 11M20 15v10M15 20h10`})]})}),(0,M.jsxs)(`div`,{className:`capability-card-content`,children:[(0,M.jsx)(`h3`,{children:`Investigations`}),(0,M.jsx)(`p`,{children:`Bespoke capabilities for complex investigations, intelligence gathering, due diligence and operational requirements.`}),(0,M.jsxs)(`span`,{className:`capability-link`,children:[`INVESTIGATION`,(0,M.jsx)(`b`,{children:`→`})]})]})]}),(0,M.jsxs)(`article`,{className:`about-capability-card about-reveal`,children:[(0,M.jsx)(`div`,{className:`capability-number`,children:`03`}),(0,M.jsx)(`div`,{className:`capability-icon capability-cross`,children:(0,M.jsxs)(`svg`,{viewBox:`0 0 48 48`,fill:`none`,stroke:`currentColor`,strokeWidth:`2`,strokeLinecap:`round`,strokeLinejoin:`round`,"aria-hidden":`true`,children:[(0,M.jsx)(`path`,{d:`m4 18 20-11 20 11-20 11L4 18Z`}),(0,M.jsx)(`path`,{d:`M12 23v10c7 6 17 6 24 0V23M44 18v13`}),(0,M.jsx)(`circle`,{cx:`44`,cy:`34`,r:`2`,fill:`currentColor`})]})}),(0,M.jsxs)(`div`,{className:`capability-card-content`,children:[(0,M.jsx)(`h3`,{children:`Training & Consulting`}),(0,M.jsx)(`p`,{children:`Practical knowledge, scenario-based training and expert consultation for modern investigative environments.`}),(0,M.jsxs)(`span`,{className:`capability-link`,children:[`EXPERTISE`,(0,M.jsx)(`b`,{children:`→`})]})]})]}),(0,M.jsxs)(`article`,{className:`about-capability-card about-reveal`,children:[(0,M.jsx)(`div`,{className:`capability-number`,children:`04`}),(0,M.jsx)(`div`,{className:`capability-icon capability-target`,children:(0,M.jsxs)(`svg`,{viewBox:`0 0 48 48`,fill:`none`,stroke:`currentColor`,strokeWidth:`2`,strokeLinecap:`round`,strokeLinejoin:`round`,"aria-hidden":`true`,children:[(0,M.jsx)(`path`,{d:`M24 5 39 11v12c0 10-7 16-15 20C16 39 9 33 9 23V11L24 5Z`}),(0,M.jsx)(`path`,{d:`m17 24 5 5 10-11`}),(0,M.jsx)(`path`,{d:`M24 5v6M9 11l15 6 15-6`})]})}),(0,M.jsxs)(`div`,{className:`capability-card-content`,children:[(0,M.jsx)(`h3`,{children:`Ground Operations`}),(0,M.jsx)(`p`,{children:`On-ground operational support connecting digital intelligence with real-world investigative requirements.`}),(0,M.jsxs)(`span`,{className:`capability-link`,children:[`OPERATIONS`,(0,M.jsx)(`b`,{children:`→`})]})]})]})]})]})}),(0,M.jsxs)(`section`,{className:`about-all-network-section`,"aria-labelledby":`about-trust-title`,children:[(0,M.jsx)(`div`,{className:`about-all-network-bg`,"aria-hidden":`true`}),(0,M.jsxs)(`div`,{className:`about-all-network-inner`,children:[(0,M.jsxs)(`div`,{className:`services-3d-header about-reveal`,children:[(0,M.jsxs)(`div`,{className:`services-3d-eyebrow`,children:[(0,M.jsx)(`span`,{}),(0,M.jsx)(`strong`,{children:`CONNECTED INSTITUTIONAL ECOSYSTEM`}),(0,M.jsx)(`span`,{})]}),(0,M.jsxs)(`h2`,{id:`about-trust-title`,children:[`Built around `,(0,M.jsx)(`span`,{children:`trusted networks.`})]}),(0,M.jsx)(`p`,{children:`Our work is designed for complex environments where intelligence, technology and operational trust matter.`})]}),(0,M.jsxs)(`div`,{className:`all-logo-3d-stage`,role:`list`,children:[(0,M.jsx)(`div`,{className:`all-logo-stage-glow`,"aria-hidden":`true`}),(0,M.jsx)(`div`,{className:`all-logo-energy-line`,"aria-hidden":`true`,children:(0,M.jsx)(`span`,{})}),mr.map((e,t)=>(0,M.jsxs)(`article`,{className:`all-logo-3d-card about-reveal`,style:{"--logo-delay":`${t*80}ms`,"--rotation-delay":`-${t*.42}s`},role:`listitem`,"aria-label":e.alt,children:[(0,M.jsxs)(`div`,{className:`all-logo-card-shell`,children:[(0,M.jsx)(`div`,{className:`all-logo-card-top-line`}),(0,M.jsx)(`div`,{className:`all-logo-card-corner corner-tl`}),(0,M.jsx)(`div`,{className:`all-logo-card-corner corner-tr`}),(0,M.jsx)(`div`,{className:`all-logo-card-corner corner-bl`}),(0,M.jsx)(`div`,{className:`all-logo-card-corner corner-br`}),(0,M.jsx)(`div`,{className:`all-logo-card-number`,children:String(t+1).padStart(2,`0`)}),(0,M.jsxs)(`div`,{className:`all-logo-card-face`,children:[(0,M.jsx)(`div`,{className:`all-logo-image-wrap`,children:(0,M.jsx)(`img`,{src:e.src,alt:e.alt,loading:`lazy`})}),(0,M.jsx)(`div`,{className:`all-logo-scan-line`})]}),(0,M.jsx)(`div`,{className:`all-logo-orbit`,"aria-hidden":`true`,children:(0,M.jsx)(`span`,{})}),(0,M.jsx)(`div`,{className:`all-logo-card-shadow`,"aria-hidden":`true`})]}),(0,M.jsxs)(`div`,{className:`all-logo-card-label`,children:[(0,M.jsx)(`span`,{children:String(t+1).padStart(2,`0`)}),(0,M.jsx)(`strong`,{children:e.alt})]})]},`${e.alt}-${t}`))]}),(0,M.jsxs)(`div`,{className:`services-3d-status all-logo-status`,children:[(0,M.jsxs)(`div`,{children:[(0,M.jsx)(`span`,{className:`services-status-dot`}),(0,M.jsx)(`strong`,{children:`OPERATIONAL NETWORK`})]}),(0,M.jsx)(`span`,{className:`services-status-divider`}),(0,M.jsxs)(`div`,{children:[`INTELLIGENCE `,(0,M.jsx)(`span`,{children:`•`}),` TECHNOLOGY `,(0,M.jsx)(`span`,{children:`•`}),` OPERATIONS`]})]})]}),(0,M.jsx)(`style`,{children:`
            /* =====================================================
               ALL 14 LOGOS — CONSISTENT 3D CYBER CARD SYSTEM
               Self-contained so it does not depend on conflicting
               older .about-trust-* rules in App.css.
            ===================================================== */
            .about-all-network-section {
              position: relative;
              overflow: hidden;
              min-height: 1250px;
              padding: 90px 0 120px;
              background:
                radial-gradient(circle at 50% 34%, rgba(0, 211, 255, .075), transparent 30%),
                linear-gradient(180deg, #020811 0%, #02070e 100%);
              isolation: isolate;
            }

            .about-all-network-bg {
              position: absolute;
              inset: 0;
              pointer-events: none;
              opacity: .55;
              background-image:
                linear-gradient(rgba(0, 208, 255, .035) 1px, transparent 1px),
                linear-gradient(90deg, rgba(0, 208, 255, .035) 1px, transparent 1px);
              background-size: 70px 70px;
              mask-image: linear-gradient(to bottom, transparent, black 18%, black 82%, transparent);
            }

            .about-all-network-inner {
              position: relative;
              z-index: 2;
              width: min(1540px, calc(100% - 70px));
              margin: 0 auto;
            }

            .about-all-network-section .services-3d-header {
              position: relative;
              z-index: 4;
              max-width: 920px;
              margin: 0 auto 58px;
              text-align: center;
            }

            .about-all-network-section .services-3d-header h2 {
              margin: 12px 0 14px;
              color: #f4f8ff;
              font-size: clamp(38px, 4vw, 64px);
              line-height: 1.05;
              letter-spacing: -2.2px;
            }

            .about-all-network-section .services-3d-header h2 span {
              color: #11d8ff;
            }

            .about-all-network-section .services-3d-header p {
              max-width: 760px;
              margin: 0 auto;
              color: #91a5b8;
              font-size: 15px;
              line-height: 1.8;
            }

            .all-logo-3d-stage {
              position: relative;
              display: grid;
              grid-template-columns: repeat(7, minmax(0, 1fr));
              gap: 66px 20px;
              align-items: start;
              width: 100%;
              padding: 18px 0 30px;
              perspective: 1600px;
              transform-style: preserve-3d;
            }

            .all-logo-stage-glow {
              position: absolute;
              left: 50%;
              top: 40%;
              width: 72%;
              height: 300px;
              transform: translate(-50%, -50%);
              border-radius: 50%;
              background: radial-gradient(ellipse, rgba(0, 215, 255, .10), transparent 68%);
              filter: blur(20px);
              pointer-events: none;
              animation: allLogoAmbientGlow 6s ease-in-out infinite;
            }

            .all-logo-energy-line {
              position: absolute;
              left: 2%;
              right: 2%;
              top: 50%;
              height: 1px;
              background: linear-gradient(90deg, transparent, rgba(0, 218, 255, .32), transparent);
              opacity: .65;
              pointer-events: none;
            }

            .all-logo-energy-line span {
              position: absolute;
              left: -5%;
              top: -2px;
              width: 90px;
              height: 4px;
              border-radius: 50%;
              background: #12dfff;
              box-shadow: 0 0 18px #12dfff, 0 0 38px rgba(18, 223, 255, .65);
              animation: allLogoEnergyTravel 4.5s linear infinite;
            }

            .all-logo-3d-card {
              position: relative;
              min-width: 0;
              display: flex;
              flex-direction: column;
              align-items: center;
              transform-style: preserve-3d;
              opacity: 0;
              animation: allLogoCardReveal .9s cubic-bezier(.16, 1, .3, 1) forwards;
              animation-delay: var(--logo-delay);
            }

            .all-logo-card-shell {
              position: relative;
              width: 100%;
              height: 205px;
              border: 1px solid rgba(0, 214, 255, .32);
              border-radius: 8px;
              background:
                linear-gradient(145deg, rgba(8, 27, 42, .82), rgba(2, 11, 20, .92)),
                radial-gradient(circle at 50% 40%, rgba(0, 214, 255, .10), transparent 65%);
              box-shadow:
                inset 0 0 0 1px rgba(255, 255, 255, .025),
                0 18px 40px rgba(0, 0, 0, .30),
                0 0 24px rgba(0, 210, 255, .035);
              transform: rotateX(8deg) rotateY(-10deg) translateZ(0);
              transform-style: preserve-3d;
              transform-origin: center center;
              animation: allLogoCard3DRotation 7s ease-in-out infinite;
              animation-delay: var(--rotation-delay);
              will-change: transform;
              transition: transform .65s cubic-bezier(.16, 1, .3, 1), box-shadow .65s ease, border-color .5s ease;
              overflow: visible;
            }

            .all-logo-card-shell::before {
              content: "";
              position: absolute;
              inset: 0;
              border-radius: inherit;
              background: linear-gradient(120deg, transparent 20%, rgba(0, 224, 255, .12) 50%, transparent 80%);
              background-size: 220% 100%;
              animation: allLogoSurfaceSweep 4.5s linear infinite;
              pointer-events: none;
              z-index: 5;
            }

            .all-logo-card-shell::after {
              content: "";
              position: absolute;
              inset: -1px;
              border-radius: inherit;
              padding: 1px;
              background: linear-gradient(115deg, rgba(0, 220, 255, .75), transparent 25%, transparent 72%, rgba(0, 122, 255, .65));
              -webkit-mask: linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0);
              -webkit-mask-composite: xor;
              mask-composite: exclude;
              opacity: .8;
              animation: allLogoBorderRotate 4s linear infinite;
              pointer-events: none;
              z-index: 6;
            }

            .all-logo-3d-card:hover .all-logo-card-shell {
              transform: rotateX(0deg) rotateY(0deg) translateY(-14px) translateZ(32px) scale(1.045);
              animation-play-state: paused;
              border-color: rgba(0, 225, 255, .9);
              box-shadow:
                inset 0 0 30px rgba(0, 210, 255, .07),
                0 28px 55px rgba(0, 0, 0, .48),
                0 0 36px rgba(0, 210, 255, .16);
            }

            .all-logo-card-top-line {
              position: absolute;
              left: 14px;
              top: 10px;
              width: 42px;
              height: 1px;
              background: #13dfff;
              box-shadow: 0 0 10px rgba(19, 223, 255, .8);
              z-index: 10;
            }

            .all-logo-card-corner {
              position: absolute;
              width: 22px;
              height: 22px;
              border-color: rgba(0, 224, 255, .75);
              border-style: solid;
              z-index: 10;
              pointer-events: none;
            }

            .corner-tl { left: -1px; top: -1px; border-width: 1px 0 0 1px; }
            .corner-tr { right: -1px; top: -1px; border-width: 1px 1px 0 0; }
            .corner-bl { left: -1px; bottom: -1px; border-width: 0 0 1px 1px; }
            .corner-br { right: -1px; bottom: -1px; border-width: 0 1px 1px 0; }

            .all-logo-card-number {
              position: absolute;
              top: 9px;
              right: 12px;
              z-index: 11;
              color: rgba(87, 224, 247, .85);
              font-size: 8px;
              font-weight: 800;
              letter-spacing: .18em;
            }

            .all-logo-card-face {
              position: absolute;
              inset: 18px;
              display: flex;
              align-items: center;
              justify-content: center;
              border: 1px solid rgba(0, 203, 255, .11);
              background: radial-gradient(circle at 50% 45%, rgba(0, 215, 255, .07), rgba(1, 9, 17, .25) 65%, transparent);
              transform: translateZ(18px);
              transform-style: preserve-3d;
              overflow: hidden;
            }

            .all-logo-image-wrap {
              position: relative;
              z-index: 4;
              width: 82%;
              height: 82%;
              display: flex;
              align-items: center;
              justify-content: center;
              transform: translateZ(28px);
              transform-style: preserve-3d;
            }

            .all-logo-image-wrap::before {
              content: "";
              position: absolute;
              inset: 8%;
              border-radius: 50%;
              background: radial-gradient(circle, rgba(0, 215, 255, .16), transparent 68%);
              filter: blur(10px);
              z-index: -1;
            }

            .all-logo-image-wrap img {
              display: block;
              width: 100%;
              height: 100%;
              object-fit: contain;
              filter: drop-shadow(0 8px 15px rgba(0, 0, 0, .28));
              transition: transform .65s cubic-bezier(.16, 1, .3, 1), filter .5s ease;
              backface-visibility: hidden;
            }

            .all-logo-3d-card:hover .all-logo-image-wrap img {
              transform: translateZ(14px) scale(1.08);
              filter: drop-shadow(0 0 12px rgba(0, 213, 255, .20)) drop-shadow(0 10px 18px rgba(0, 0, 0, .3));
            }

            .all-logo-scan-line {
              position: absolute;
              left: 0;
              right: 0;
              top: -20%;
              height: 1px;
              background: linear-gradient(90deg, transparent, rgba(0, 226, 255, .9), transparent);
              box-shadow: 0 0 12px rgba(0, 226, 255, .65);
              animation: allLogoScan 3.4s ease-in-out infinite;
              z-index: 8;
              pointer-events: none;
            }

            .all-logo-orbit {
              position: absolute;
              left: 50%;
              top: 50%;
              width: 104%;
              height: 34%;
              transform: translate(-50%, -50%) translateZ(7px) rotateX(68deg) rotateZ(4deg);
              border: 1px solid rgba(0, 210, 255, .16);
              border-radius: 50%;
              pointer-events: none;
              z-index: 9;
              animation: allLogoOrbit 5.5s linear infinite;
            }

            .all-logo-orbit span {
              position: absolute;
              left: 4%;
              top: 50%;
              width: 5px;
              height: 5px;
              transform: translateY(-50%);
              border-radius: 50%;
              background: #16dcff;
              box-shadow: 0 0 10px #16dcff, 0 0 24px rgba(22, 220, 255, .7);
            }

            .all-logo-card-shadow {
              position: absolute;
              left: 8%;
              right: 8%;
              bottom: -26px;
              height: 40px;
              border-radius: 50%;
              background: rgba(0, 205, 255, .12);
              filter: blur(18px);
              transform: translateZ(-15px);
              opacity: .6;
              transition: opacity .5s ease, transform .5s ease;
            }

            .all-logo-3d-card:hover .all-logo-card-shadow {
              opacity: 1;
              transform: translateZ(-5px) scale(1.15);
            }

            .all-logo-card-label {
              width: 100%;
              display: flex;
              align-items: baseline;
              gap: 9px;
              margin-top: 22px;
              padding: 0 5px;
              color: #a7bacb;
              text-transform: uppercase;
              letter-spacing: .08em;
              font-size: 10px;
              line-height: 1.4;
            }

            .all-logo-card-label span {
              color: #19dfff;
              font-weight: 900;
              font-size: 9px;
            }

            .all-logo-card-label strong {
              color: #d8e6f1;
              font-size: 10px;
              font-weight: 800;
            }

            .all-logo-status {
              margin-top: 46px;
            }

            @keyframes allLogoCardReveal {
              from { opacity: 0; transform: translateY(45px) rotateX(18deg) rotateY(-5deg); }
              to { opacity: 1; transform: translateY(0) rotateX(0deg) rotateY(0deg); }
            }

            @keyframes allLogoCard3DRotation {
              0% { transform: rotateX(8deg) rotateY(-10deg) translateZ(0) translateY(0); }
              25% { transform: rotateX(-5deg) rotateY(9deg) translateZ(10px) translateY(-4px); }
              50% { transform: rotateX(7deg) rotateY(13deg) translateZ(18px) translateY(0); }
              75% { transform: rotateX(-7deg) rotateY(-8deg) translateZ(10px) translateY(-4px); }
              100% { transform: rotateX(8deg) rotateY(-10deg) translateZ(0) translateY(0); }
            }

            @keyframes allLogoAmbientGlow {
              0%, 100% { transform: translate(-50%, -50%) scale(.92); opacity: .55; }
              50% { transform: translate(-50%, -50%) scale(1.08); opacity: 1; }
            }

            @keyframes allLogoEnergyTravel {
              from { left: -8%; }
              to { left: 108%; }
            }

            @keyframes allLogoSurfaceSweep {
              from { background-position: 220% 0; }
              to { background-position: -220% 0; }
            }

            @keyframes allLogoBorderRotate {
              from { filter: hue-rotate(0deg); }
              to { filter: hue-rotate(30deg); }
            }

            @keyframes allLogoScan {
              0%, 15% { top: -10%; opacity: 0; }
              25% { opacity: .9; }
              70% { opacity: .75; }
              100% { top: 110%; opacity: 0; }
            }

            @keyframes allLogoOrbit {
              from { transform: translate(-50%, -50%) translateZ(7px) rotateX(68deg) rotateZ(0deg); }
              to { transform: translate(-50%, -50%) translateZ(7px) rotateX(68deg) rotateZ(360deg); }
            }

            @media (max-width: 1250px) {
              .all-logo-3d-stage { grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 60px 22px; }
            }

            @media (max-width: 760px) {
              .about-all-network-section { min-height: auto; padding: 75px 0 90px; }
              .about-all-network-inner { width: min(94%, 620px); }
              .all-logo-3d-stage { grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 48px 16px; }
              .all-logo-card-shell { height: 175px; }
              .all-logo-card-face { inset: 15px; }
              .all-logo-card-label { margin-top: 18px; font-size: 9px; }
              .all-logo-card-label strong { font-size: 9px; }
              .all-logo-status { flex-direction: column; gap: 14px; }
            }

            @media (prefers-reduced-motion: reduce) {
              .all-logo-3d-card,
              .all-logo-card-shell,
              .all-logo-stage-glow,
              .all-logo-energy-line span,
              .all-logo-card-shell::before,
              .all-logo-card-shell::after,
              .all-logo-scan-line,
              .all-logo-orbit {
                animation: none !important;
              }
              .all-logo-card-shell,
              .all-logo-image-wrap img {
                transition: none !important;
              }
            }
          `})]}),(0,M.jsx)(`section`,{className:`about-section about-why`,children:(0,M.jsxs)(`div`,{className:`about-section-container`,children:[(0,M.jsx)(`div`,{className:`about-section-number`,children:`03`}),(0,M.jsxs)(`div`,{className:`about-section-heading about-reveal`,children:[(0,M.jsx)(`div`,{className:`about-section-label`,children:`WHY GRYPHON`}),(0,M.jsxs)(`h2`,{children:[`Built around`,(0,M.jsx)(`span`,{children:` reality.`})]}),(0,M.jsx)(`p`,{children:`Our approach combines localized expertise, operational understanding and technology.`})]}),(0,M.jsxs)(`div`,{className:`about-why-system`,children:[(0,M.jsx)(`div`,{className:`why-system-line`,children:(0,M.jsx)(`div`,{className:`why-progress`})}),(0,M.jsxs)(`div`,{className:`about-why-item about-reveal`,children:[(0,M.jsx)(`div`,{className:`why-point`,children:`01`}),(0,M.jsxs)(`div`,{children:[(0,M.jsx)(`h3`,{children:`Localized Expertise`}),(0,M.jsx)(`p`,{children:`Deep alignment with the Indian intelligence and security environment.`})]})]}),(0,M.jsxs)(`div`,{className:`about-why-item about-reveal`,children:[(0,M.jsx)(`div`,{className:`why-point`,children:`02`}),(0,M.jsxs)(`div`,{children:[(0,M.jsx)(`h3`,{children:`Operational Reality`}),(0,M.jsx)(`p`,{children:`Technology designed around real investigative and operational requirements.`})]})]}),(0,M.jsxs)(`div`,{className:`about-why-item about-reveal`,children:[(0,M.jsx)(`div`,{className:`why-point`,children:`03`}),(0,M.jsxs)(`div`,{children:[(0,M.jsx)(`h3`,{children:`Proven Deployment`}),(0,M.jsx)(`p`,{children:`Experience supporting deployments across multiple states and agencies.`})]})]}),(0,M.jsxs)(`div`,{className:`about-why-item about-reveal`,children:[(0,M.jsx)(`div`,{className:`why-point`,children:`04`}),(0,M.jsxs)(`div`,{children:[(0,M.jsx)(`h3`,{children:`Cost Efficiency`}),(0,M.jsx)(`p`,{children:`Intelligence capabilities developed with operational efficiency in mind.`})]})]}),(0,M.jsxs)(`div`,{className:`about-why-item about-reveal`,children:[(0,M.jsx)(`div`,{className:`why-point`,children:`05`}),(0,M.jsxs)(`div`,{children:[(0,M.jsx)(`h3`,{children:`Holistic Support`}),(0,M.jsx)(`p`,{children:`Beyond software: training, consultation and operational support.`})]})]})]}),(0,M.jsxs)(`div`,{className:`about-stat-strip`,children:[(0,M.jsxs)(`div`,{children:[(0,M.jsx)(`strong`,{children:`36+`}),(0,M.jsx)(`span`,{children:`YEARS OF GOVERNMENT SERVICE EXPERIENCE`})]}),(0,M.jsxs)(`div`,{children:[(0,M.jsx)(`strong`,{children:`12+`}),(0,M.jsx)(`span`,{children:`STATES WITH TRAINING DEPLOYMENTS`})]}),(0,M.jsxs)(`div`,{children:[(0,M.jsx)(`strong`,{children:`INDIA`}),(0,M.jsx)(`span`,{children:`LOCALIZED INTELLIGENCE CAPABILITIES`})]})]})]})}),(0,M.jsx)(`section`,{className:`about-section about-leadership`,children:(0,M.jsxs)(`div`,{className:`about-section-container`,children:[(0,M.jsx)(`div`,{className:`about-section-number`,children:`04`}),(0,M.jsxs)(`div`,{className:`about-section-heading about-reveal`,children:[(0,M.jsx)(`div`,{className:`about-section-label`,children:`OUR LEADERSHIP`}),(0,M.jsxs)(`h2`,{children:[`Experience behind`,(0,M.jsx)(`span`,{children:` the mission.`})]})]}),(0,M.jsxs)(`div`,{className:`about-leaders-grid`,children:[(0,M.jsxs)(`article`,{className:`about-leader-card about-reveal`,children:[(0,M.jsxs)(`div`,{className:`leader-card-top`,children:[(0,M.jsx)(`span`,{children:`01`}),(0,M.jsx)(`span`,{children:`EXECUTIVE`})]}),(0,M.jsxs)(`div`,{className:`leader-avatar`,children:[(0,M.jsx)(`div`,{className:`leader-avatar-ring`}),(0,M.jsx)(`div`,{className:`leader-avatar-core leader-photo-core`,children:(0,M.jsx)(`img`,{src:`./logos/govind-ray.png`,alt:`Mr. Govind Ray`})}),(0,M.jsx)(`div`,{className:`leader-avatar-orbit`,children:(0,M.jsx)(`span`,{})})]}),(0,M.jsxs)(`div`,{className:`leader-information`,children:[(0,M.jsx)(`h3`,{children:`Mr. Govind Ray`}),(0,M.jsx)(`div`,{className:`leader-role`,children:`Managing Director & CEO`}),(0,M.jsx)(`p`,{children:`A cybersecurity investigator with experience in high-stakes digital investigations and government cyber operations, with expertise in strategic consulting and advanced vigilance systems.`})]}),(0,M.jsxs)(`div`,{className:`leader-footer`,children:[(0,M.jsx)(`span`,{children:`10+ YEARS`}),(0,M.jsx)(`span`,{children:`EXPERIENCE`})]})]}),(0,M.jsxs)(`article`,{className:`about-leader-card about-reveal`,children:[(0,M.jsxs)(`div`,{className:`leader-card-top`,children:[(0,M.jsx)(`span`,{children:`02`}),(0,M.jsx)(`span`,{children:`Executive Director`})]}),(0,M.jsxs)(`div`,{className:`leader-avatar leader-avatar-second`,children:[(0,M.jsx)(`div`,{className:`leader-avatar-ring`}),(0,M.jsx)(`div`,{className:`leader-avatar-core leader-photo-core`,children:(0,M.jsx)(`img`,{src:`./logos/sm-sahai.png`,alt:`Shri S.M. Sahai, IPS (Retd.)`})}),(0,M.jsx)(`div`,{className:`leader-avatar-orbit`,children:(0,M.jsx)(`span`,{})})]}),(0,M.jsxs)(`div`,{className:`leader-information`,children:[(0,M.jsx)(`h3`,{children:`Shri S.M. Sahai, IPS (Retd.)`}),(0,M.jsx)(`div`,{className:`leader-role`,children:`Executive Director`}),(0,M.jsx)(`p`,{children:`A digital security professional with 36 years of distinguished government service and experience in national security, counter-terrorism and technology-led law enforcement.`})]}),(0,M.jsxs)(`div`,{className:`leader-footer`,children:[(0,M.jsx)(`span`,{children:`36 YEARS`}),(0,M.jsx)(`span`,{children:`GOVERNMENT SERVICE`})]})]})]})]})}),(0,M.jsxs)(`section`,{className:`about-final-cta`,children:[(0,M.jsx)(`div`,{className:`about-final-grid`}),(0,M.jsx)(`div`,{className:`about-final-glow`}),(0,M.jsxs)(`div`,{className:`about-final-core`,children:[(0,M.jsx)(`div`,{className:`final-core-ring ring-one`}),(0,M.jsx)(`div`,{className:`final-core-ring ring-two`}),(0,M.jsx)(`div`,{className:`final-core-ring ring-three`}),(0,M.jsx)(`div`,{className:`final-core-center`,children:`GC`})]}),(0,M.jsxs)(`div`,{className:`about-final-content`,children:[(0,M.jsx)(`div`,{className:`about-section-label`,children:`THE NEXT MOVE`}),(0,M.jsxs)(`h2`,{children:[`Ready to see`,(0,M.jsx)(`span`,{children:` beyond?`})]}),(0,M.jsx)(`p`,{children:`Explore the intelligence capabilities, technology and operational systems built by Gryphon Cyber.`}),(0,M.jsxs)(`div`,{className:`about-final-actions`,children:[(0,M.jsxs)(j,{to:`/solutions`,className:`about-primary-button`,children:[`Explore Solutions`,(0,M.jsx)(`span`,{children:`→`})]}),(0,M.jsxs)(j,{to:`/contact`,className:`about-secondary-button`,children:[`Talk to Gryphon`,(0,M.jsx)(`span`,{children:`↗`})]})]})]})]})]}),(0,M.jsx)(`style`,{children:`
        /* Keep all text comfortably readable while preserving the existing layout. */
        .about-page .about-hero-content > p {
          max-width: 680px;
          color: #bdcbd9 !important;
          font-size: 18px !important;
          line-height: 1.8 !important;
          font-weight: 400 !important;
        }

        .about-page .about-hero-meta strong {
          color: #f1f7ff !important;
          font-size: 13px !important;
          line-height: 1.5 !important;
          letter-spacing: 0.08em !important;
        }

        .about-page .about-hero-meta span {
          color: #a9bdcf !important;
          font-size: 11px !important;
          line-height: 1.6 !important;
          letter-spacing: 0.12em !important;
        }

        /* Section numbers and eyebrow labels */
        .about-page .about-section-number {
          color: #48dff8 !important;
          font-size: 13px !important;
          font-weight: 800 !important;
          letter-spacing: 0.16em !important;
        }

        .about-page .about-section-label {
          color: #48e2ff !important;
          font-size: 12px !important;
          font-weight: 800 !important;
          letter-spacing: 0.20em !important;
          line-height: 1.6 !important;
        }

        .about-page .about-section-heading > p {
          color: #c0cedc !important;
          font-size: 17px !important;
          line-height: 1.8 !important;
        }

        /* Who we are */
        .about-page .about-who-text p {
          color: #c5d1de !important;
          font-size: 16px !important;
          line-height: 1.85 !important;
          font-weight: 400 !important;
        }

        .about-page .about-who-text p.about-lead {
          color: #eef5fc !important;
          font-size: 18px !important;
          line-height: 1.8 !important;
          font-weight: 500 !important;
        }

        .about-page .about-inline-line strong {
          color: #55e4fa !important;
          font-size: 11px !important;
          letter-spacing: 0.16em !important;
        }

        /* Capability cards */
        .about-page .capability-number {
          color: #55e4fa !important;
          font-size: 13px !important;
          font-weight: 800 !important;
          letter-spacing: 0.12em !important;
        }

        .about-page .capability-icon {
          color: #12d8ff !important;
        }

        .about-page .capability-icon svg {
          display: block !important;
          width: 38px !important;
          height: 38px !important;
          color: #12d8ff !important;
          stroke: currentColor !important;
          flex: 0 0 auto !important;
        }

        .about-page .capability-card-content h3 {
          color: #f1f6fc !important;
          font-size: 21px !important;
          line-height: 1.45 !important;
          font-weight: 750 !important;
        }

        .about-page .capability-card-content p {
          color: #c1cedb !important;
          font-size: 16px !important;
          line-height: 1.8 !important;
          font-weight: 400 !important;
        }

        .about-page .capability-link {
          color: #9eb4c8 !important;
          font-size: 11px !important;
          line-height: 1.6 !important;
          font-weight: 800 !important;
          letter-spacing: 0.15em !important;
        }

        .about-page .capability-link b {
          color: #12d8ff !important;
          font-size: 18px !important;
        }

        /* Why Gryphon items */
        .about-page .why-point {
          color: #55e4fa !important;
          font-size: 13px !important;
          font-weight: 800 !important;
        }

        .about-page .about-why-item h3 {
          color: #f0f5fb !important;
          font-size: 19px !important;
          line-height: 1.45 !important;
          font-weight: 750 !important;
        }

        .about-page .about-why-item p {
          color: #bdcbd9 !important;
          font-size: 15px !important;
          line-height: 1.8 !important;
        }

        /* Statistics */
        .about-page .about-stat-strip strong {
          color: #f5f9ff !important;
          font-size: 27px !important;
          line-height: 1.25 !important;
          font-weight: 850 !important;
        }

        .about-page .about-stat-strip span {
          color: #b5c7d8 !important;
          font-size: 11px !important;
          line-height: 1.7 !important;
          font-weight: 750 !important;
          letter-spacing: 0.12em !important;
        }

        /* Institutional reach / 3D service stage */
        .about-page .services-3d-eyebrow strong {
          color: #62e7fa !important;
          font-size: 12px !important;
          letter-spacing: 0.18em !important;
        }

        .about-page .services-3d-header > p {
          color: #bdcbd9 !important;
          font-size: 17px !important;
          line-height: 1.8 !important;
        }

        .about-page .logo-object-label {
          color: #a9bdcf !important;
          font-size: 11px !important;
          line-height: 1.6 !important;
          letter-spacing: 0.12em !important;
        }

        .about-page .logo-object-label > span {
          color: #45dcf5 !important;
          font-size: 11px !important;
          font-weight: 850 !important;
        }

        .about-page .logo-object-label strong {
          color: #e1edf7 !important;
          font-size: 11px !important;
          font-weight: 800 !important;
          letter-spacing: 0.12em !important;
        }

        .about-page .services-3d-status {
          color: #b5c7d8 !important;
          font-size: 11px !important;
          line-height: 1.7 !important;
          letter-spacing: 0.12em !important;
        }

        .about-page .services-3d-status strong {
          color: #d8e8f5 !important;
          font-size: 11px !important;
        }

        /* Leadership cards */
        .about-page .leader-card-top span {
          color: #b5c7d8 !important;
          font-size: 11px !important;
          line-height: 1.6 !important;
          font-weight: 750 !important;
          letter-spacing: 0.12em !important;
        }

        .about-page .leader-information h3 {
          color: #f2f7fc !important;
          font-size: 22px !important;
          line-height: 1.4 !important;
          font-weight: 800 !important;
        }

        .about-page .leader-role {
          color: #55ddf5 !important;
          font-size: 14px !important;
          line-height: 1.6 !important;
          font-weight: 700 !important;
        }

        .about-page .leader-information p {
          color: #c7d4e0 !important;
          font-size: 15px !important;
          line-height: 1.85 !important;
        }

        .about-page .leader-footer span {
          color: #b0c2d4 !important;
          font-size: 11px !important;
          line-height: 1.7 !important;
          font-weight: 800 !important;
          letter-spacing: 0.12em !important;
        }

        /* Final call to action */
        .about-page .about-final-content > p {
          color: #c7d4e0 !important;
          font-size: 17px !important;
          line-height: 1.8 !important;
        }

        .about-page .about-final-actions a {
          font-size: 15px !important;
          font-weight: 750 !important;
        }

        /* Tablet and mobile: readable without causing overflow */
        @media (max-width: 900px) {
          .about-page .about-hero-content > p,
          .about-page .about-section-heading > p,
          .about-page .services-3d-header > p {
            font-size: 16px !important;
          }

          .about-page .capability-card-content h3,
          .about-page .leader-information h3 {
            font-size: 19px !important;
          }

          .about-page .capability-card-content p,
          .about-page .about-why-item p,
          .about-page .leader-information p {
            font-size: 15px !important;
          }
        }

        @media (max-width: 600px) {
          .about-page .about-hero-content > p {
            font-size: 15px !important;
            line-height: 1.75 !important;
          }

          .about-page .about-hero-meta strong {
            font-size: 12px !important;
          }

          .about-page .about-hero-meta span,
          .about-page .about-stat-strip span,
          .about-page .logo-object-label,
          .about-page .services-3d-status,
          .about-page .leader-footer span {
            font-size: 10px !important;
          }

          .about-page .about-section-label {
            font-size: 11px !important;
          }

          .about-page .about-who-text p,
          .about-page .about-who-text p.about-lead,
          .about-page .capability-card-content p,
          .about-page .about-why-item p,
          .about-page .leader-information p,
          .about-page .about-final-content > p {
            font-size: 15px !important;
            line-height: 1.75 !important;
          }

          .about-page .capability-card-content h3,
          .about-page .about-why-item h3 {
            font-size: 18px !important;
          }

          .about-page .capability-link {
            font-size: 10px !important;
          }

          .about-page .about-stat-strip strong {
            font-size: 23px !important;
          }
        }

        @media (prefers-reduced-motion: reduce) {
          .about-page .capability-icon svg {
            transition: none !important;
          }
        }
      `}),(0,M.jsx)(dr,{})]})}function gr(){let[e,t]=(0,_.useState)(!1),[n,r]=(0,_.useState)(()=>typeof window<`u`&&window.innerWidth<=760);return(0,_.useEffect)(()=>{let e=window.matchMedia(`(max-width: 760px)`),n=e=>{r(e.matches),e.matches||t(!1)};return r(e.matches),e.addEventListener(`change`,n),()=>{e.removeEventListener(`change`,n)}},[]),(0,M.jsxs)(`div`,{className:`app`,children:[(0,M.jsxs)(`header`,{className:`navbar gryphon-standard-navbar`,children:[(0,M.jsxs)(`div`,{className:`nav-container`,children:[(0,M.jsx)(j,{to:`/`,className:`logo-link`,onClick:()=>t(!1),children:(0,M.jsx)(fr,{})}),!n&&(0,M.jsxs)(M.Fragment,{children:[(0,M.jsxs)(`nav`,{className:`nav-links`,children:[(0,M.jsx)(j,{to:`/`,children:`Home`}),(0,M.jsx)(j,{to:`/about`,children:`About`}),(0,M.jsx)(j,{to:`/services`,className:`active`,children:`Services`}),(0,M.jsx)(j,{to:`/solutions`,children:`Solutions`}),(0,M.jsx)(j,{to:`/engagements`,children:`Engagements`}),(0,M.jsx)(j,{to:`/training`,children:`Training`}),(0,M.jsx)(j,{to:`/contact`,children:`Contact`})]}),(0,M.jsxs)(j,{to:`/contact`,className:`talk-button`,children:[`Talk to Us`,(0,M.jsx)(`span`,{children:`→`})]})]}),n&&(0,M.jsxs)(`button`,{type:`button`,className:`services-mobile-toggle ${e?`open`:``}`,"aria-label":e?`Close navigation menu`:`Open navigation menu`,"aria-expanded":e,onClick:()=>t(!e),children:[(0,M.jsx)(`span`,{}),(0,M.jsx)(`span`,{}),(0,M.jsx)(`span`,{})]})]}),n&&e&&(0,M.jsxs)(`div`,{className:`services-mobile-menu`,children:[(0,M.jsx)(j,{to:`/`,onClick:()=>t(!1),children:`Home`}),(0,M.jsx)(j,{to:`/about`,onClick:()=>t(!1),children:`About`}),(0,M.jsx)(j,{to:`/services`,className:`mobile-active`,onClick:()=>t(!1),children:`Services`}),(0,M.jsx)(j,{to:`/solutions`,onClick:()=>t(!1),children:`Solutions`}),(0,M.jsx)(j,{to:`/engagements`,onClick:()=>t(!1),children:`Engagements`}),(0,M.jsx)(j,{to:`/training`,onClick:()=>t(!1),children:`Training`}),(0,M.jsx)(j,{to:`/contact`,onClick:()=>t(!1),children:`Contact`}),(0,M.jsxs)(j,{to:`/contact`,className:`services-mobile-talk`,onClick:()=>t(!1),children:[`Talk to Us`,(0,M.jsx)(`span`,{children:`→`})]})]}),(0,M.jsx)(`style`,{children:`

          /* SERVICES MOBILE NAVIGATION */

          .services-mobile-toggle {

            width: 44px !important;

            height: 44px !important;

            display: flex !important;

            flex-direction: column !important;

            align-items: center !important;

            justify-content: center !important;

            gap: 5px !important;

            margin-left: auto !important;

            padding: 0 !important;

            border: 1px solid rgba(34, 211, 238, 0.35) !important;

            border-radius: 8px !important;

            background: rgba(7, 20, 38, 0.90) !important;

            cursor: pointer !important;

            outline: none !important;

            flex-shrink: 0 !important;

          }

          .services-mobile-toggle span {

            width: 21px !important;

            height: 2px !important;

            display: block !important;

            border-radius: 10px !important;

            background: #ffffff !important;

            transition: transform 0.25s ease, opacity 0.2s ease !important;

          }

          .services-mobile-toggle.open span:nth-child(1) {

            transform: translateY(7px) rotate(45deg) !important;

          }

          .services-mobile-toggle.open span:nth-child(2) {

            opacity: 0 !important;

          }

          .services-mobile-toggle.open span:nth-child(3) {

            transform: translateY(-7px) rotate(-45deg) !important;

          }

          .services-mobile-menu {

            position: absolute !important;

            top: 100% !important;

            left: 0 !important;

            right: 0 !important;

            display: flex !important;

            flex-direction: column !important;

            box-sizing: border-box !important;

            padding: 10px 18px 18px !important;

            background: rgba(4, 12, 24, 0.98) !important;

            backdrop-filter: blur(18px) !important;

            -webkit-backdrop-filter: blur(18px) !important;

            border-top: 1px solid rgba(34, 211, 238, 0.12) !important;

            border-bottom: 1px solid rgba(34, 211, 238, 0.18) !important;

            box-shadow: 0 18px 40px rgba(0, 0, 0, 0.45) !important;

            z-index: 99999 !important;

          }

          .services-mobile-menu a {

            width: 100% !important;

            box-sizing: border-box !important;

            padding: 14px 12px !important;

            color: #ffffff !important;

            font-size: 15px !important;

            font-weight: 500 !important;

            line-height: 1.3 !important;

            text-decoration: none !important;

            border-bottom: 1px solid rgba(255, 255, 255, 0.06) !important;

          }

          .services-mobile-menu a:hover,

          .services-mobile-menu a.mobile-active {

            color: #22d3ee !important;

          }

          .services-mobile-talk {

            display: flex !important;

            align-items: center !important;

            justify-content: center !important;

            gap: 10px !important;

            margin-top: 12px !important;

            padding: 13px 16px !important;

            border: 0 !important;

            border-radius: 8px !important;

            background: #1764e8 !important;

            color: #ffffff !important;

            font-weight: 700 !important;

            text-decoration: none !important;

          }

          .services-mobile-talk span {

            font-size: 19px !important;

            color: #ffffff !important;

          }

          .services-mobile-talk:hover {

            background: #1764e8 !important;

            color: #ffffff !important;

          }

          @media (max-width: 760px) {

            .navbar,

            .navbar .nav-container {

              position: relative !important;

            }

          }

          @media (max-width: 420px) {

            .services-mobile-toggle {

              width: 42px !important;

              height: 42px !important;

            }

            .services-mobile-menu {

              padding-left: 14px !important;

              padding-right: 14px !important;

            }

          }

        `})]}),(0,M.jsxs)(`main`,{children:[(0,M.jsxs)(`section`,{className:`inner-page-hero`,children:[(0,M.jsx)(`div`,{className:`inner-page-grid`}),(0,M.jsx)(`div`,{className:`inner-page-glow`}),(0,M.jsxs)(`div`,{className:`inner-page-content`,children:[(0,M.jsxs)(`div`,{className:`inner-page-label services-brand-label`,children:[(0,M.jsx)(`img`,{src:Un,alt:`Gryphon Cyber logo`,className:`services-brand-logo`}),(0,M.jsx)(`span`,{children:`GRYPHON CYBER • CAPABILITIES`})]}),(0,M.jsxs)(`h1`,{children:[`Intelligence built`,(0,M.jsx)(`span`,{children:`for the real world.`})]}),(0,M.jsx)(`p`,{children:`From investigator training and expert consultation to digital transformation and security solutions, Gryphon Cyber combines technology with operational expertise.`})]})]}),(0,M.jsxs)(`section`,{className:`services-page-section`,children:[(0,M.jsxs)(`div`,{className:`services-page-header`,children:[(0,M.jsx)(`div`,{className:`section-label`,children:`01 — OUR SERVICES`}),(0,M.jsxs)(`h2`,{children:[`Four capabilities.`,(0,M.jsx)(`span`,{children:`One intelligence ecosystem.`})]}),(0,M.jsx)(`p`,{children:`Our services are designed to support complex investigations, cybersecurity requirements and operational transformation.`})]}),(0,M.jsx)(`div`,{className:`services-page-grid`,children:[{number:`01`,title:`Training Programs`,description:`Comprehensive knowledge and practical skills for investigators handling real-world scenarios with advanced methodologies.`,capabilities:[`Crime Investigation Techniques`,`Cyber Forensic Skills`,`Scenario-based Simulation`]},{number:`02`,title:`Expert Consultation`,description:`Personalized guidance on IT strategies and cybersecurity, leveraging deep industry knowledge to solve complex operational challenges.`,capabilities:[`Strategic IT Planning`,`Cybersecurity Audits`,`Digital Risk Assessment`]},{number:`03`,title:`Digital Transformation`,description:`Cloud computing and data analytics solutions designed to streamline operations and unlock new levels of efficiency.`,capabilities:[`Cloud Infrastructure Setup`,`Data Analytics Implementation`,`Process Automation`]},{number:`04`,title:`Security Solutions`,description:`Robust protection for digital assets, networks and sensitive data through advanced security measures.`,capabilities:[`Network Security Hardening`,`Threat Monitoring Systems`,`Breach Prevention Protocols`]}].map(e=>(0,M.jsxs)(`article`,{className:`service-page-card`,children:[(0,M.jsx)(`div`,{className:`service-page-number`,children:e.number}),(0,M.jsxs)(`div`,{className:`service-page-status`,children:[(0,M.jsx)(`span`,{}),`ACTIVE CAPABILITY`]}),(0,M.jsx)(`h3`,{children:e.title}),(0,M.jsx)(`p`,{children:e.description}),(0,M.jsx)(`div`,{className:`service-page-divider`}),(0,M.jsx)(`div`,{className:`service-page-capabilities`,children:e.capabilities.map(e=>(0,M.jsxs)(`div`,{className:`service-capability`,children:[(0,M.jsx)(`span`,{children:`+`}),e]},e))})]},e.number))})]}),(0,M.jsxs)(`section`,{className:`services-page-cta`,children:[(0,M.jsxs)(`div`,{children:[(0,M.jsx)(`div`,{className:`section-label`,children:`NEXT STEP`}),(0,M.jsxs)(`h2`,{children:[`Have a complex`,(0,M.jsx)(`span`,{children:`challenge?`})]}),(0,M.jsx)(`p`,{children:`Let's discuss how Gryphon Cyber can support your intelligence, cybersecurity or operational requirements.`})]}),(0,M.jsxs)(j,{to:`/contact`,className:`services-cta-button`,children:[`Start a Conversation`,(0,M.jsx)(`span`,{children:`→`})]})]})]}),(0,M.jsx)(dr,{}),(0,M.jsx)(`style`,{children:`
        .services-brand-label {
          display: flex !important;
          align-items: center !important;
          justify-content: flex-start !important;
          gap: 14px !important;
          width: fit-content !important;
          max-width: 100% !important;
          margin-bottom: 28px !important;
          white-space: nowrap !important;
          color: #35e0ff !important;
          font-size: 18px !important;
          font-weight: 900 !important;
          letter-spacing: 3px !important;
          line-height: 1.4 !important;
        }

        .services-brand-logo {
          display: block !important;
          width: 52px !important;
          height: 52px !important;
          max-width: none !important;
          object-fit: contain !important;
          flex: 0 0 52px !important;
        }

        .services-brand-label > span {
          display: inline-block !important;
          color: #35e0ff !important;
          font-size: 18px !important;
          font-weight: 900 !important;
          letter-spacing: 3px !important;
          line-height: 1.4 !important;
        }

        @media (max-width: 760px) {
          .services-brand-label {
            gap: 10px !important;
            margin-bottom: 22px !important;
            white-space: normal !important;
            font-size: 14px !important;
            letter-spacing: 1.8px !important;
          }

          .services-brand-logo {
            width: 42px !important;
            height: 42px !important;
            flex-basis: 42px !important;
          }

          .services-brand-label > span {
            font-size: 13px !important;
            letter-spacing: 1.8px !important;
          }
        }

        @media (max-width: 380px) {
          .services-brand-label {
            gap: 8px !important;
          }

          .services-brand-logo {
            width: 36px !important;
            height: 36px !important;
            flex-basis: 36px !important;
          }

          .services-brand-label > span {
            font-size: 11px !important;
            letter-spacing: 1.2px !important;
          }
        }
      `})]})}var _r=new URL(`solutions-spider-logo-BwJWDyGY.png`,import.meta.url).href,vr=new URL(`solutions-oversight-logo-C84sNgpx.png`,import.meta.url).href,yr=new URL(`solutions-lawsync-logo-CWhlVeRi.png`,import.meta.url).href;function br(){let[e,t]=(0,_.useState)(!1),[n,r]=(0,_.useState)(()=>typeof window<`u`&&window.innerWidth<=760);(0,_.useEffect)(()=>{let e=window.matchMedia(`(max-width: 760px)`),n=e=>{r(e.matches),e.matches||t(!1)};return r(e.matches),e.addEventListener(`change`,n),()=>{e.removeEventListener(`change`,n)}},[]);let i=bt(),a=(e,t)=>{e.preventDefault();let n=t.toLowerCase(),r=document.getElementById(n);if(!r){console.error(`Solutions product section not found: #${n}`);return}window.history.replaceState(null,``,`${window.location.pathname}${window.location.search}#${n}`),r.scrollIntoView({behavior:`smooth`,block:`start`})},o=[{code:`SAKSHAM`,logo:Un,category:`PREDICTIVE INTELLIGENCE`,title:`Advanced Intelligence Analysis`,description:`Predictive behavioral analysis and threat quantification using the proprietary L-Square algorithm, shifting operations from reactive to proactive.`,stats:[[`01`,`Mirror Data Analysis`],[`02`,`Syndicate Matching`],[`03`,`Threat Quantification`],[`04`,`Behavioral Anomalies`],[`05`,`Real-Time Alerts`]]},{code:`SPIDER`,logo:_r,category:`SOCIAL INTELLIGENCE`,title:`Unified Intelligence Search`,description:`Parallel federated search across 20+ data sources including social media, telecom and vehicle records.`,stats:[[`20+`,`Data Sources`],[`< 5s`,`Query Response`],[`01`,`Linked Numbers & Addresses`],[`02`,`Social Handles & Aliases`],[`03`,`Automated Reporting`]]},{code:`OVERSIGHT`,logo:vr,category:`DEEP NETWORK ANALYSIS`,title:`Deep Network Intelligence`,description:`Big-data link analysis designed to visualize hidden connections, hierarchies and bridge nodes in complex networks.`,stats:[[`100M+`,`Records Processed Daily`],[`01`,`VoIP Party Identification`],[`02`,`Multi-Dataset Correlation`],[`03`,`Geo-Distributed Analysis`],[`04`,`Internet Usage Categorization`]]},{code:`LAWSYNC`,logo:yr,category:`LAW ENFORCEMENT & INTELLIGENCE`,title:`Digital Policing`,description:`A unified law enforcement platform that modernizes policing, improves data management and enables efficient role-based real-time coordination.`,stats:[[`01`,`Incident Management`],[`02`,`Third Eye`],[`03`,`Real-Time Collaboration`],[`04`,`Jail Release Management`],[`15+`,`Customizable Modules`]]}];return(0,_.useEffect)(()=>{let e=i.hash;if(!e){window.scrollTo({top:0,behavior:`auto`});return}let t=e.substring(1),n=setTimeout(()=>{let e=document.getElementById(t);e&&e.scrollIntoView({behavior:`smooth`,block:`start`})},150);return()=>{clearTimeout(n)}},[i.hash]),(0,M.jsxs)(`div`,{className:`app`,children:[(0,M.jsxs)(`header`,{className:`navbar gryphon-standard-navbar`,children:[(0,M.jsxs)(`div`,{className:`nav-container`,children:[(0,M.jsx)(j,{to:`/`,className:`logo-link`,onClick:()=>t(!1),children:(0,M.jsx)(fr,{})}),!n&&(0,M.jsxs)(M.Fragment,{children:[(0,M.jsxs)(`nav`,{className:`nav-links`,children:[(0,M.jsx)(j,{to:`/`,children:`Home`}),(0,M.jsx)(j,{to:`/about`,children:`About`}),(0,M.jsx)(j,{to:`/services`,children:`Services`}),(0,M.jsx)(j,{to:`/solutions`,className:`active`,children:`Solutions`}),(0,M.jsx)(j,{to:`/engagements`,children:`Engagements`}),(0,M.jsx)(j,{to:`/training`,children:`Training`}),(0,M.jsx)(j,{to:`/contact`,children:`Contact`})]}),(0,M.jsxs)(j,{to:`/contact`,className:`talk-button`,children:[`Talk to Us`,(0,M.jsx)(`span`,{children:`→`})]})]}),n&&(0,M.jsxs)(`button`,{type:`button`,className:`solutions-mobile-toggle ${e?`open`:``}`,"aria-label":e?`Close navigation menu`:`Open navigation menu`,"aria-expanded":e,onClick:()=>t(!e),children:[(0,M.jsx)(`span`,{}),(0,M.jsx)(`span`,{}),(0,M.jsx)(`span`,{})]})]}),n&&e&&(0,M.jsxs)(`div`,{className:`solutions-mobile-menu`,children:[(0,M.jsx)(j,{to:`/`,onClick:()=>t(!1),children:`Home`}),(0,M.jsx)(j,{to:`/about`,onClick:()=>t(!1),children:`About`}),(0,M.jsx)(j,{to:`/services`,onClick:()=>t(!1),children:`Services`}),(0,M.jsx)(j,{to:`/solutions`,className:`mobile-active`,onClick:()=>t(!1),children:`Solutions`}),(0,M.jsx)(j,{to:`/engagements`,onClick:()=>t(!1),children:`Engagements`}),(0,M.jsx)(j,{to:`/training`,onClick:()=>t(!1),children:`Training`}),(0,M.jsx)(j,{to:`/contact`,onClick:()=>t(!1),children:`Contact`}),(0,M.jsxs)(j,{to:`/contact`,className:`solutions-mobile-talk`,onClick:()=>t(!1),children:[`Talk to Us`,(0,M.jsx)(`span`,{children:`→`})]})]}),(0,M.jsx)(`style`,{children:`

          /* SOLUTIONS MOBILE NAVIGATION */

          .solutions-mobile-toggle {

            width: 44px !important;

            height: 44px !important;

            display: flex !important;

            flex-direction: column !important;

            align-items: center !important;

            justify-content: center !important;

            gap: 5px !important;

            margin-left: auto !important;

            padding: 0 !important;

            border: 1px solid rgba(34, 211, 238, 0.35) !important;

            border-radius: 8px !important;

            background: rgba(7, 20, 38, 0.90) !important;

            cursor: pointer !important;

            outline: none !important;

            -webkit-tap-highlight-color: transparent !important;

            flex-shrink: 0 !important;

          }

          .solutions-mobile-toggle span {

            width: 21px !important;

            height: 2px !important;

            display: block !important;

            border-radius: 10px !important;

            background: #ffffff !important;

            transition: transform 0.25s ease, opacity 0.2s ease !important;

          }

          .solutions-mobile-toggle.open span:nth-child(1) {

            transform: translateY(7px) rotate(45deg) !important;

          }

          .solutions-mobile-toggle.open span:nth-child(2) {

            opacity: 0 !important;

          }

          .solutions-mobile-toggle.open span:nth-child(3) {

            transform: translateY(-7px) rotate(-45deg) !important;

          }

          .solutions-mobile-menu {

            position: absolute !important;

            top: 100% !important;

            left: 0 !important;

            right: 0 !important;

            display: flex !important;

            flex-direction: column !important;

            box-sizing: border-box !important;

            padding: 10px 18px 18px !important;

            background: rgba(4, 12, 24, 0.98) !important;

            backdrop-filter: blur(18px) !important;

            -webkit-backdrop-filter: blur(18px) !important;

            border-top: 1px solid rgba(34, 211, 238, 0.12) !important;

            border-bottom: 1px solid rgba(34, 211, 238, 0.18) !important;

            box-shadow: 0 18px 40px rgba(0, 0, 0, 0.45) !important;

            z-index: 99999 !important;

          }

          .solutions-mobile-menu a {

            width: 100% !important;

            box-sizing: border-box !important;

            padding: 14px 12px !important;

            color: #ffffff !important;

            font-size: 15px !important;

            font-weight: 500 !important;

            line-height: 1.3 !important;

            text-decoration: none !important;

            border-bottom: 1px solid rgba(255, 255, 255, 0.06) !important;

            transition: color 0.2s ease, background 0.2s ease !important;

          }

          .solutions-mobile-menu a:hover,

          .solutions-mobile-menu a.mobile-active {

            color: #22d3ee !important;

          }

          .solutions-mobile-talk {

            display: flex !important;

            align-items: center !important;

            justify-content: center !important;

            gap: 10px !important;

            margin-top: 12px !important;

            padding: 13px 16px !important;

            border: 0 !important;

            border-radius: 8px !important;

            background: #1764e8 !important;

            color: #ffffff !important;

            font-weight: 700 !important;

            text-decoration: none !important;

          }

          .solutions-mobile-talk span {

            font-size: 19px !important;

            color: #ffffff !important;

          }

          .solutions-mobile-talk:hover {

            background: #1764e8 !important;

            color: #ffffff !important;

          }

          @media (max-width: 420px) {

            .solutions-mobile-toggle {

              width: 42px !important;

              height: 42px !important;

            }

            .solutions-mobile-menu {

              padding-left: 14px !important;

              padding-right: 14px !important;

            }

          }


          /* SOLUTIONS HERO BRAND LABEL — MATCH SERVICES PAGE */
          .solutions-page-hero .solutions-brand-label {
            display: flex !important;
            align-items: center !important;
            justify-content: flex-start !important;
            gap: 14px !important;
            width: fit-content !important;
            color: #35e0ff !important;
            font-size: 17px !important;
            font-weight: 900 !important;
            letter-spacing: 3.5px !important;
            line-height: 1.45 !important;
            text-transform: uppercase !important;
          }

          .solutions-page-hero .solutions-brand-logo {
            display: block !important;
            width: 48px !important;
            height: 48px !important;
            min-width: 48px !important;
            object-fit: contain !important;
            flex: 0 0 48px !important;
          }

          .solutions-page-hero .solutions-brand-label span {
            display: inline-block !important;
            color: #35e0ff !important;
            font: inherit !important;
            letter-spacing: inherit !important;
            line-height: inherit !important;
          }

          /* PRODUCT LINKS — CLICKABLE AND CLEARLY VISIBLE */
          .solutions-page-hero ~ .solution-index .solution-index-links a {
            position: relative !important;
            z-index: 2 !important;
            display: inline-flex !important;
            align-items: center !important;
            justify-content: center !important;
            gap: 10px !important;
            color: #e7f2fa !important;
            opacity: 1 !important;
            visibility: visible !important;
            pointer-events: auto !important;
            cursor: pointer !important;
            text-decoration: none !important;
          }

          .solutions-page-hero ~ .solution-index .solution-index-links a span {
            color: #22dfff !important;
            opacity: 1 !important;
          }

          .solutions-page-hero ~ .solution-index .solution-index-links a:hover {
            color: #22dfff !important;
          }

          .solutions-products .solution-product {
            scroll-margin-top: 125px !important;
          }

          @media (max-width: 760px) {
            .solutions-page-hero .solutions-brand-label {
              gap: 10px !important;
              font-size: 12px !important;
              letter-spacing: 2px !important;
            }

            .solutions-page-hero .solutions-brand-logo {
              width: 38px !important;
              height: 38px !important;
              min-width: 38px !important;
              flex-basis: 38px !important;
            }
          }

        `})]}),(0,M.jsxs)(`main`,{children:[(0,M.jsxs)(`section`,{className:`solutions-page-hero`,children:[(0,M.jsx)(`div`,{className:`solutions-grid`}),(0,M.jsx)(`div`,{className:`solutions-glow`}),(0,M.jsxs)(`div`,{className:`solutions-hero-content`,children:[(0,M.jsxs)(`div`,{className:`inner-page-label solutions-brand-label`,children:[(0,M.jsx)(`img`,{src:Un,alt:`Gryphon Cyber logo`,className:`solutions-brand-logo`}),(0,M.jsx)(`span`,{children:`GRYPHON CYBER • INTELLIGENCE PLATFORM`})]}),(0,M.jsxs)(`h1`,{children:[`Intelligence,`,(0,M.jsx)(`span`,{children:`connected.`})]}),(0,M.jsx)(`p`,{children:`An integrated product ecosystem combining predictive analysis, intelligence search, deep network analysis and digital policing.`})]})]}),(0,M.jsx)(`section`,{className:`solution-index`,children:(0,M.jsxs)(`div`,{className:`solution-index-inner`,children:[(0,M.jsx)(`div`,{className:`section-label`,children:`PRODUCT SUITE`}),(0,M.jsx)(`div`,{className:`solution-index-links`,children:o.map((e,t)=>(0,M.jsxs)(`a`,{href:`#${e.code.toLowerCase()}`,onClick:t=>a(t,e.code),"aria-label":`Scroll to ${e.code} product details`,children:[(0,M.jsxs)(`span`,{children:[`0`,t+1]}),e.code]},e.code))})]})}),(0,M.jsx)(`section`,{className:`solutions-products`,children:o.map((e,t)=>(0,M.jsxs)(`article`,{className:`solution-product`,id:e.code.toLowerCase(),children:[(0,M.jsxs)(`div`,{className:`solution-product-number`,children:[`0`,t+1]}),(0,M.jsxs)(`div`,{className:`solution-product-content`,children:[(0,M.jsx)(`div`,{className:`solution-product-category`,children:e.category}),(0,M.jsx)(`div`,{className:`solution-product-code`,children:e.code}),(0,M.jsx)(`h2`,{children:e.title}),(0,M.jsx)(`p`,{className:`solution-product-description`,children:e.description}),(0,M.jsx)(`div`,{className:`solution-product-line`}),(0,M.jsx)(`div`,{className:`solution-feature-grid`,children:e.stats.map(e=>(0,M.jsxs)(`div`,{className:`solution-feature`,children:[(0,M.jsx)(`span`,{className:`solution-feature-number`,children:e[0]}),(0,M.jsx)(`span`,{className:`solution-feature-name`,children:e[1]})]},e[0]+e[1]))})]}),(0,M.jsxs)(`div`,{className:`solution-product-visual`,children:[(0,M.jsx)(`div`,{className:`solution-orbit orbit-one`}),(0,M.jsx)(`div`,{className:`solution-orbit orbit-two`}),(0,M.jsx)(`div`,{className:`solution-orbit orbit-three`}),(0,M.jsx)(`div`,{className:`solution-core solution-core-${e.code.toLowerCase()}`,children:(0,M.jsx)(`img`,{src:e.logo,alt:`${e.code} application logo`,className:`solution-core-logo`,loading:`lazy`})}),(0,M.jsx)(`div`,{className:`solution-data-node node-a`,children:`INTEL`}),(0,M.jsx)(`div`,{className:`solution-data-node node-b`,children:`DATA`}),(0,M.jsx)(`div`,{className:`solution-data-node node-c`,children:`ANALYSIS`})]})]},e.code))}),(0,M.jsxs)(`section`,{className:`deployment-section`,children:[(0,M.jsx)(`div`,{className:`section-label`,children:`DEPLOYMENT & INTEGRATION`}),(0,M.jsxs)(`h2`,{children:[`Built for`,(0,M.jsx)(`span`,{children:`secure environments.`})]}),(0,M.jsxs)(`div`,{className:`deployment-grid`,children:[(0,M.jsxs)(`div`,{className:`deployment-card`,children:[(0,M.jsx)(`span`,{className:`deployment-number`,children:`01`}),(0,M.jsx)(`h3`,{children:`Flexible Hosting`}),(0,M.jsx)(`p`,{children:`Deploy on air-gapped on-premise servers for maximum security or utilize secure GovCloud infrastructure.`})]}),(0,M.jsxs)(`div`,{className:`deployment-card`,children:[(0,M.jsx)(`span`,{className:`deployment-number`,children:`02`}),(0,M.jsx)(`h3`,{children:`Seamless Integration`}),(0,M.jsx)(`p`,{children:`API-first architecture designed for compatibility with existing LEA databases, CCTNS and legacy intelligence systems.`})]}),(0,M.jsxs)(`div`,{className:`deployment-card`,children:[(0,M.jsx)(`span`,{className:`deployment-number`,children:`03`}),(0,M.jsx)(`h3`,{children:`Rapid Implementation`}),(0,M.jsx)(`p`,{children:`Standardized deployment protocols enable full operational capability within 6 weeks of project initiation.`})]})]}),(0,M.jsxs)(`div`,{className:`deployment-flow`,children:[(0,M.jsx)(`span`,{children:`SETUP`}),(0,M.jsx)(`i`,{}),(0,M.jsx)(`span`,{children:`INGEST`}),(0,M.jsx)(`i`,{}),(0,M.jsx)(`span`,{children:`TRAIN`}),(0,M.jsx)(`i`,{}),(0,M.jsx)(`span`,{children:`GO-LIVE`})]})]}),(0,M.jsxs)(`section`,{className:`solutions-cta`,children:[(0,M.jsxs)(`div`,{children:[(0,M.jsx)(`div`,{className:`section-label`,children:`INTELLIGENCE CAPABILITY`}),(0,M.jsxs)(`h2`,{children:[`Ready to modernize`,(0,M.jsx)(`span`,{children:`your intelligence capability?`})]})]}),(0,M.jsxs)(j,{to:`/contact`,className:`services-cta-button`,children:[`Discuss Your Requirements`,(0,M.jsx)(`span`,{children:`→`})]})]})]}),(0,M.jsx)(dr,{})]})}var xr=`

.training-mobile-toggle{display:none;}

@media(max-width:760px){

.training-mobile-toggle{display:flex;width:44px;height:44px;padding:0;margin-left:auto;border:0;background:transparent;cursor:pointer;flex-direction:column;align-items:center;justify-content:center;gap:5px;z-index:100001;}

.training-mobile-toggle span{display:block;width:24px;height:2px;background:#fff;transition:transform .25s ease,opacity .25s ease;}

.training-mobile-toggle.open span:nth-child(1){transform:translateY(7px) rotate(45deg);}

.training-mobile-toggle.open span:nth-child(2){opacity:0;}

.training-mobile-toggle.open span:nth-child(3){transform:translateY(-7px) rotate(-45deg);}

.training-mobile-menu{position:absolute;top:100%;left:0;right:0;z-index:100000;display:flex;flex-direction:column;padding:14px 22px 22px;background:rgba(7,20,38,.98);border-top:1px solid rgba(255,255,255,.1);box-shadow:0 18px 40px rgba(0,0,0,.35);}

.training-mobile-menu a{display:flex;align-items:center;justify-content:space-between;min-height:48px;padding:0 8px;color:#fff!important;text-decoration:none;border-bottom:1px solid rgba(255,255,255,.08);}

.training-mobile-menu a.active{color:#4ea1ff!important;}

.training-mobile-menu .training-mobile-talk{justify-content:center;gap:10px;margin-top:16px;min-height:48px;border:0;border-radius:8px;background:#1764e8!important;color:#fff!important;font-weight:700;}

}

@media(max-width:420px){.training-mobile-menu{padding-left:16px;padding-right:16px;}}

/* TRAINING PAGE — HERO BRAND LABEL */
.training-page .training-eyebrow {
  display: flex !important;
  align-items: center !important;
  gap: 14px !important;
  font-size: 17px !important;
  font-weight: 900 !important;
  letter-spacing: 3.5px !important;
  line-height: 1.45 !important;
  color: #35e0ff !important;
  text-transform: uppercase !important;
}

.training-page .training-eyebrow .training-brand-logo {
  display: block !important;
  width: 48px !important;
  height: 48px !important;
  min-width: 48px !important;
  object-fit: contain !important;
  flex: 0 0 48px !important;
}

.training-page .training-eyebrow .training-brand-text {
  display: inline-block !important;
  width: auto !important;
  height: auto !important;
  margin: 0 !important;
  padding: 0 !important;
  border: 0 !important;
  border-radius: 0 !important;
  background: transparent !important;
  box-shadow: none !important;
  animation: none !important;
  color: #35e0ff !important;
  font: inherit !important;
  letter-spacing: inherit !important;
  line-height: inherit !important;
  white-space: normal !important;
}

@media (max-width: 760px) {
  .training-page .training-eyebrow {
    gap: 10px !important;
    font-size: 12px !important;
    letter-spacing: 2px !important;
  }

  .training-page .training-eyebrow .training-brand-logo {
    width: 38px !important;
    height: 38px !important;
    min-width: 38px !important;
    flex-basis: 38px !important;
  }
}

`;function Sr(){let[e,t]=(0,_.useState)(`cyber`),[n,r]=(0,_.useState)(!1),[i,a]=(0,_.useState)(()=>typeof window<`u`&&window.innerWidth<=760);(0,_.useEffect)(()=>{let e=window.matchMedia(`(max-width: 760px)`),t=e=>{a(e.matches),e.matches||r(!1)};return a(e.matches),e.addEventListener(`change`,t),()=>e.removeEventListener(`change`,t)},[]),(0,_.useEffect)(()=>{let e=document.querySelectorAll(`.training-reveal`),t=new IntersectionObserver(e=>{e.forEach(e=>{e.isIntersecting&&e.target.classList.add(`training-visible`)})},{threshold:.15});return e.forEach(e=>{t.observe(e)}),()=>{t.disconnect()}},[]);let o=[{id:`cyber`,number:`01`,label:`CYBER INVESTIGATION`,title:`Cyber Investigation`,description:`Advanced techniques for digital crime scene analysis and evidence preservation.`,tag:`INVESTIGATION`,visual:`investigation`},{id:`forensics`,number:`02`,label:`FORENSIC ANALYSIS`,title:`Forensic Analysis`,description:`Deep-dive into digital forensics, data recovery, and chain of custody protocols.`,tag:`FORENSICS`,visual:`forensics`},{id:`simulation`,number:`03`,label:`SCENARIO SIMULATION`,title:`Scenario Simulation`,description:`Real-world scenario-based training for hands-on practical experience.`,tag:`FIELD SIMULATION`,visual:`simulation`},{id:`interview`,number:`04`,label:`INTERVIEW SKILLS`,title:`Interview Skills`,description:`Enhanced interrogation and intelligence gathering methodologies.`,tag:`INTELLIGENCE`,visual:`interview`}];return(0,M.jsxs)(`div`,{className:`app training-page`,children:[(0,M.jsx)(`style`,{children:xr}),(0,M.jsxs)(`header`,{className:`navbar gryphon-standard-navbar`,children:[(0,M.jsxs)(`div`,{className:`nav-container`,children:[(0,M.jsx)(j,{to:`/`,className:`logo-link`,onClick:()=>r(!1),children:(0,M.jsx)(fr,{})}),!i&&(0,M.jsxs)(M.Fragment,{children:[(0,M.jsxs)(`nav`,{className:`nav-links`,children:[(0,M.jsx)(j,{to:`/`,children:`Home`}),(0,M.jsx)(j,{to:`/about`,children:`About`}),(0,M.jsx)(j,{to:`/services`,children:`Services`}),(0,M.jsx)(j,{to:`/solutions`,children:`Solutions`}),(0,M.jsx)(j,{to:`/engagements`,children:`Engagements`}),(0,M.jsx)(j,{to:`/training`,className:`active`,children:`Training`}),(0,M.jsx)(j,{to:`/contact`,children:`Contact`})]}),(0,M.jsxs)(j,{to:`/contact`,className:`talk-button`,children:[`Talk to Us `,(0,M.jsx)(`span`,{children:`→`})]})]}),i&&(0,M.jsxs)(`button`,{type:`button`,className:`training-mobile-toggle ${n?`open`:``}`,onClick:()=>r(e=>!e),"aria-label":n?`Close menu`:`Open menu`,"aria-expanded":n,children:[(0,M.jsx)(`span`,{}),(0,M.jsx)(`span`,{}),(0,M.jsx)(`span`,{})]})]}),i&&n&&(0,M.jsxs)(`div`,{className:`training-mobile-menu`,children:[(0,M.jsx)(j,{to:`/`,onClick:()=>r(!1),children:`Home`}),(0,M.jsx)(j,{to:`/about`,onClick:()=>r(!1),children:`About`}),(0,M.jsx)(j,{to:`/services`,onClick:()=>r(!1),children:`Services`}),(0,M.jsx)(j,{to:`/solutions`,onClick:()=>r(!1),children:`Solutions`}),(0,M.jsx)(j,{to:`/engagements`,onClick:()=>r(!1),children:`Engagements`}),(0,M.jsx)(j,{to:`/training`,className:`active`,onClick:()=>r(!1),children:`Training`}),(0,M.jsx)(j,{to:`/contact`,onClick:()=>r(!1),children:`Contact`}),(0,M.jsxs)(j,{to:`/contact`,className:`training-mobile-talk`,onClick:()=>r(!1),children:[`Talk to Us `,(0,M.jsx)(`span`,{children:`→`})]})]})]}),(0,M.jsxs)(`main`,{children:[(0,M.jsxs)(`section`,{className:`training-hero`,children:[(0,M.jsx)(`div`,{className:`training-grid`}),(0,M.jsx)(`div`,{className:`training-glow training-glow-one`}),(0,M.jsx)(`div`,{className:`training-glow training-glow-two`}),(0,M.jsxs)(`div`,{className:`training-hero-content`,children:[(0,M.jsxs)(`div`,{className:`training-eyebrow`,children:[(0,M.jsx)(`img`,{src:Un,alt:`Gryphon Cyber logo`,className:`training-brand-logo`}),(0,M.jsx)(`span`,{className:`training-brand-text`,children:`GRYPHON CYBER • TRAINING & EXPERTISE`})]}),(0,M.jsxs)(`h1`,{children:[`Train for the`,(0,M.jsx)(`span`,{children:`investigation.`})]}),(0,M.jsx)(`p`,{children:`Practical cyber investigation training designed to equip investigative teams with advanced techniques and hands-on experience for modern investigations.`}),(0,M.jsxs)(`div`,{className:`training-hero-actions`,children:[(0,M.jsxs)(`a`,{href:`#training-programs`,className:`training-primary-button`,children:[`Explore Training`,(0,M.jsx)(`span`,{children:`↓`})]}),(0,M.jsxs)(j,{to:`/training/request`,className:`training-secondary-button`,children:[`Request Training`,(0,M.jsx)(`span`,{children:`→`})]})]}),(0,M.jsxs)(`div`,{className:`training-hero-meta`,children:[(0,M.jsxs)(`div`,{children:[(0,M.jsx)(`strong`,{children:`12+`}),(0,M.jsx)(`span`,{children:`STATES`})]}),(0,M.jsxs)(`div`,{children:[(0,M.jsx)(`strong`,{children:`01`}),(0,M.jsx)(`span`,{children:`PRACTICAL FOCUS`})]}),(0,M.jsxs)(`div`,{children:[(0,M.jsx)(`strong`,{children:`360°`}),(0,M.jsx)(`span`,{children:`INVESTIGATION`})]})]})]}),(0,M.jsxs)(`div`,{className:`training-command`,children:[(0,M.jsx)(`div`,{className:`training-command-label`,children:`TRAINING SYSTEM`}),(0,M.jsxs)(`div`,{className:`training-radar`,children:[(0,M.jsx)(`div`,{className:`training-radar-ring ring-one`}),(0,M.jsx)(`div`,{className:`training-radar-ring ring-two`}),(0,M.jsx)(`div`,{className:`training-radar-ring ring-three`}),(0,M.jsx)(`div`,{className:`training-radar-cross horizontal`}),(0,M.jsx)(`div`,{className:`training-radar-cross vertical`}),(0,M.jsx)(`div`,{className:`training-radar-sweep`}),(0,M.jsx)(`div`,{className:`training-radar-core`,children:(0,M.jsx)(`span`,{})}),(0,M.jsx)(`div`,{className:`training-radar-point point-one`,children:(0,M.jsx)(`span`,{children:`01`})}),(0,M.jsx)(`div`,{className:`training-radar-point point-two`,children:(0,M.jsx)(`span`,{children:`02`})}),(0,M.jsx)(`div`,{className:`training-radar-point point-three`,children:(0,M.jsx)(`span`,{children:`03`})}),(0,M.jsx)(`div`,{className:`training-radar-point point-four`,children:(0,M.jsx)(`span`,{children:`04`})})]}),(0,M.jsxs)(`div`,{className:`training-command-data`,children:[(0,M.jsxs)(`div`,{children:[(0,M.jsx)(`span`,{children:`MODE`}),(0,M.jsx)(`strong`,{children:`FIELD READY`})]}),(0,M.jsxs)(`div`,{children:[(0,M.jsx)(`span`,{children:`STATUS`}),(0,M.jsx)(`strong`,{children:`ACTIVE`})]})]})]})]}),(0,M.jsxs)(`section`,{className:`training-intro training-reveal`,children:[(0,M.jsx)(`div`,{className:`training-section-number`,children:`01`}),(0,M.jsxs)(`div`,{className:`training-intro-content`,children:[(0,M.jsx)(`div`,{className:`training-section-label`,children:`TRAINING & EXPERTISE`}),(0,M.jsxs)(`h2`,{children:[`Beyond tools.`,(0,M.jsx)(`span`,{children:`Build capability.`})]}),(0,M.jsx)(`p`,{children:`Gryphon Cyber's training programs go beyond technology demonstrations. The focus is on practical knowledge and techniques that investigators can apply to real-world investigative scenarios.`})]})]}),(0,M.jsxs)(`section`,{className:`training-programs`,id:`training-programs`,children:[(0,M.jsxs)(`div`,{className:`training-section-header training-reveal`,children:[(0,M.jsxs)(`div`,{children:[(0,M.jsx)(`div`,{className:`training-section-label`,children:`02 — CORE PROGRAMS`}),(0,M.jsxs)(`h2`,{children:[`Investigation`,(0,M.jsx)(`span`,{children:`in practice.`})]})]}),(0,M.jsx)(`p`,{children:`Four core training areas designed around practical investigative capability.`})]}),(0,M.jsxs)(`div`,{className:`training-program-layout`,children:[(0,M.jsx)(`div`,{className:`training-program-list`,children:o.map(n=>(0,M.jsxs)(`button`,{type:`button`,className:`training-program-item ${e===n.id?`active`:``}`,onClick:()=>t(n.id),children:[(0,M.jsx)(`span`,{className:`training-program-number`,children:n.number}),(0,M.jsx)(`span`,{className:`training-program-name`,children:n.label}),(0,M.jsx)(`span`,{className:`training-program-arrow`,children:`→`})]},n.id))}),(0,M.jsx)(`div`,{className:`training-program-detail`,children:o.map(t=>(0,M.jsxs)(`div`,{className:`training-detail-panel ${e===t.id?`active`:``}`,children:[(0,M.jsxs)(`div`,{className:`training-detail-top`,children:[(0,M.jsx)(`span`,{children:t.number}),(0,M.jsx)(`span`,{children:t.tag})]}),(0,M.jsxs)(`div`,{className:`training-detail-visual training-visual-${t.visual}`,children:[(0,M.jsx)(`div`,{className:`training-detail-grid`}),t.visual===`investigation`&&(0,M.jsxs)(`div`,{className:`visual-investigation`,children:[(0,M.jsxs)(`div`,{className:`investigation-target`,children:[(0,M.jsx)(`div`,{className:`target-ring target-ring-one`}),(0,M.jsx)(`div`,{className:`target-ring target-ring-two`}),(0,M.jsx)(`div`,{className:`target-cross horizontal`}),(0,M.jsx)(`div`,{className:`target-cross vertical`}),(0,M.jsx)(`div`,{className:`target-core`,children:`CYBER`})]}),(0,M.jsxs)(`div`,{className:`investigation-node investigation-node-one`,children:[(0,M.jsx)(`span`,{}),`DEVICE`]}),(0,M.jsxs)(`div`,{className:`investigation-node investigation-node-two`,children:[(0,M.jsx)(`span`,{}),`IP TRACE`]}),(0,M.jsxs)(`div`,{className:`investigation-node investigation-node-three`,children:[(0,M.jsx)(`span`,{}),`EVIDENCE`]}),(0,M.jsxs)(`div`,{className:`investigation-node investigation-node-four`,children:[(0,M.jsx)(`span`,{}),`TIMELINE`]}),(0,M.jsx)(`div`,{className:`investigation-line investigation-line-one`}),(0,M.jsx)(`div`,{className:`investigation-line investigation-line-two`}),(0,M.jsx)(`div`,{className:`investigation-line investigation-line-three`}),(0,M.jsx)(`div`,{className:`investigation-line investigation-line-four`}),(0,M.jsx)(`div`,{className:`investigation-scan`})]}),t.visual===`forensics`&&(0,M.jsxs)(`div`,{className:`visual-forensics`,children:[(0,M.jsxs)(`div`,{className:`forensic-disk`,children:[(0,M.jsx)(`div`,{className:`forensic-disk-inner`}),(0,M.jsx)(`div`,{className:`forensic-disk-center`,children:`DATA`})]}),(0,M.jsxs)(`div`,{className:`forensic-file file-one`,children:[(0,M.jsx)(`span`,{children:`FILE`}),(0,M.jsx)(`strong`,{children:`01`})]}),(0,M.jsxs)(`div`,{className:`forensic-file file-two`,children:[(0,M.jsx)(`span`,{children:`HASH`}),(0,M.jsx)(`strong`,{children:`02`})]}),(0,M.jsxs)(`div`,{className:`forensic-file file-three`,children:[(0,M.jsx)(`span`,{children:`IMAGE`}),(0,M.jsx)(`strong`,{children:`03`})]}),(0,M.jsx)(`div`,{className:`forensic-data-line data-line-one`}),(0,M.jsx)(`div`,{className:`forensic-data-line data-line-two`}),(0,M.jsx)(`div`,{className:`forensic-data-line data-line-three`}),(0,M.jsx)(`div`,{className:`forensic-scan`}),(0,M.jsxs)(`div`,{className:`forensic-status`,children:[`EVIDENCE INTEGRITY`,(0,M.jsx)(`strong`,{children:`VERIFIED`})]})]}),t.visual===`simulation`&&(0,M.jsxs)(`div`,{className:`visual-simulation`,children:[(0,M.jsx)(`div`,{className:`simulation-grid`}),(0,M.jsx)(`div`,{className:`simulation-zone zone-one`,children:`A`}),(0,M.jsx)(`div`,{className:`simulation-zone zone-two`,children:`B`}),(0,M.jsx)(`div`,{className:`simulation-zone zone-three`,children:`C`}),(0,M.jsx)(`div`,{className:`simulation-zone zone-four`,children:`D`}),(0,M.jsx)(`div`,{className:`simulation-route route-one`}),(0,M.jsx)(`div`,{className:`simulation-route route-two`}),(0,M.jsx)(`div`,{className:`simulation-route route-three`}),(0,M.jsx)(`div`,{className:`simulation-pulse pulse-one`}),(0,M.jsx)(`div`,{className:`simulation-pulse pulse-two`}),(0,M.jsx)(`div`,{className:`simulation-pulse pulse-three`}),(0,M.jsxs)(`div`,{className:`simulation-center`,children:[(0,M.jsx)(`span`,{children:`SCENARIO`}),(0,M.jsx)(`strong`,{children:`ACTIVE`})]})]}),t.visual===`interview`&&(0,M.jsxs)(`div`,{className:`visual-interview`,children:[(0,M.jsx)(`div`,{className:`interview-person person-one`,children:(0,M.jsx)(`span`,{children:`I`})}),(0,M.jsx)(`div`,{className:`interview-person person-two`,children:(0,M.jsx)(`span`,{children:`S`})}),(0,M.jsx)(`div`,{className:`interview-connection connection-one`}),(0,M.jsx)(`div`,{className:`interview-connection connection-two`}),(0,M.jsx)(`div`,{className:`interview-connection connection-three`}),(0,M.jsxs)(`div`,{className:`interview-wave`,children:[(0,M.jsx)(`span`,{}),(0,M.jsx)(`span`,{}),(0,M.jsx)(`span`,{}),(0,M.jsx)(`span`,{}),(0,M.jsx)(`span`,{}),(0,M.jsx)(`span`,{}),(0,M.jsx)(`span`,{}),(0,M.jsx)(`span`,{}),(0,M.jsx)(`span`,{}),(0,M.jsx)(`span`,{}),(0,M.jsx)(`span`,{}),(0,M.jsx)(`span`,{})]}),(0,M.jsx)(`div`,{className:`interview-data interview-data-one`,children:`QUESTION`}),(0,M.jsx)(`div`,{className:`interview-data interview-data-two`,children:`RESPONSE`}),(0,M.jsx)(`div`,{className:`interview-data interview-data-three`,children:`INTELLIGENCE`}),(0,M.jsx)(`div`,{className:`interview-scan`})]})]}),(0,M.jsx)(`h3`,{children:t.title}),(0,M.jsx)(`p`,{children:t.description}),(0,M.jsxs)(`div`,{className:`training-detail-status`,children:[(0,M.jsx)(`span`,{className:`status-dot`}),`TRAINING MODULE`,(0,M.jsx)(`strong`,{children:`ACTIVE`})]})]},t.id))})]})]}),(0,M.jsxs)(`section`,{className:`training-method`,children:[(0,M.jsxs)(`div`,{className:`training-method-header training-reveal`,children:[(0,M.jsx)(`div`,{className:`training-section-label`,children:`03 — TRAINING METHOD`}),(0,M.jsxs)(`h2`,{children:[`Learn.`,(0,M.jsx)(`span`,{children:`Simulate.`}),`Apply.`]})]}),(0,M.jsxs)(`div`,{className:`training-method-flow`,children:[(0,M.jsxs)(`div`,{className:`training-method-progress`,children:[(0,M.jsx)(`span`,{className:`training-flow-line`}),(0,M.jsx)(`span`,{className:`training-flow-pulse`})]}),(0,M.jsxs)(`div`,{className:`training-method-grid`,children:[(0,M.jsxs)(`div`,{className:`training-method-card training-reveal`,"data-step":`01`,children:[(0,M.jsx)(`span`,{children:`01`}),(0,M.jsx)(`div`,{className:`training-method-icon`,children:`◇`}),(0,M.jsx)(`h3`,{children:`Learn`}),(0,M.jsx)(`p`,{children:`Develop the foundational knowledge and investigative methodologies required for modern cyber investigations.`})]}),(0,M.jsxs)(`div`,{className:`training-method-card training-reveal`,"data-step":`02`,children:[(0,M.jsx)(`span`,{children:`02`}),(0,M.jsx)(`div`,{className:`training-method-icon`,children:`◎`}),(0,M.jsx)(`h3`,{children:`Simulate`}),(0,M.jsx)(`p`,{children:`Apply concepts through scenario-based training and practical investigative situations.`})]}),(0,M.jsxs)(`div`,{className:`training-method-card training-reveal`,"data-step":`03`,children:[(0,M.jsx)(`span`,{children:`03`}),(0,M.jsx)(`div`,{className:`training-method-icon`,children:`+`}),(0,M.jsx)(`h3`,{children:`Investigate`}),(0,M.jsx)(`p`,{children:`Develop hands-on capability across cyber investigation and forensic analysis.`})]}),(0,M.jsxs)(`div`,{className:`training-method-card training-reveal`,"data-step":`04`,children:[(0,M.jsx)(`span`,{children:`04`}),(0,M.jsx)(`div`,{className:`training-method-icon`,children:`→`}),(0,M.jsx)(`h3`,{children:`Apply`}),(0,M.jsx)(`p`,{children:`Translate training into practical investigative capability in operational environments.`})]})]})]})]}),(0,M.jsxs)(`section`,{className:`training-impact`,children:[(0,M.jsx)(`div`,{className:`training-impact-grid`}),(0,M.jsxs)(`div`,{className:`training-impact-content training-reveal`,children:[(0,M.jsx)(`div`,{className:`training-section-label`,children:`04 — FIELD EXPERIENCE`}),(0,M.jsxs)(`h2`,{children:[`Training built for`,(0,M.jsx)(`span`,{children:`real investigations.`})]}),(0,M.jsx)(`p`,{children:`The training approach emphasizes practical investigative skills, scenario simulation, evidence handling and intelligence gathering methodologies.`})]}),(0,M.jsxs)(`div`,{className:`training-impact-stats`,children:[(0,M.jsxs)(`div`,{className:`training-impact-stat`,children:[(0,M.jsx)(`strong`,{children:`12+`}),(0,M.jsx)(`span`,{children:`STATES`}),(0,M.jsx)(`p`,{children:`Training delivered to law enforcement agencies across India.`})]}),(0,M.jsxs)(`div`,{className:`training-impact-stat`,children:[(0,M.jsx)(`strong`,{children:`04`}),(0,M.jsx)(`span`,{children:`CORE AREAS`}),(0,M.jsx)(`p`,{children:`Cyber investigation, forensics, simulation and interview skills.`})]}),(0,M.jsxs)(`div`,{className:`training-impact-stat`,children:[(0,M.jsx)(`strong`,{children:`01`}),(0,M.jsx)(`span`,{children:`OBJECTIVE`}),(0,M.jsx)(`p`,{children:`Upskilling investigative personnel with practical capabilities.`})]})]})]}),(0,M.jsxs)(`section`,{className:`training-cta training-reveal`,children:[(0,M.jsx)(`div`,{className:`training-cta-grid`}),(0,M.jsx)(`div`,{className:`training-cta-glow`}),(0,M.jsxs)(`div`,{className:`training-cta-content`,children:[(0,M.jsx)(`div`,{className:`training-section-label`,children:`05 — START A TRAINING PROGRAM`}),(0,M.jsxs)(`h2`,{children:[`Build your`,(0,M.jsx)(`span`,{children:`investigative capability.`})]}),(0,M.jsx)(`p`,{children:`Connect with Gryphon Cyber to discuss training requirements for your team.`}),(0,M.jsxs)(j,{to:`/contact`,className:`training-cta-button`,children:[`Discuss Training`,(0,M.jsx)(`span`,{children:`→`})]})]})]})]}),(0,M.jsx)(dr,{})]})}function Cr(){let[e,t]=(0,_.useState)({name:``,organization:``,email:``,phone:``,subject:``,message:``}),[n,r]=(0,_.useState)(!1),[i,a]=(0,_.useState)({email:``,phone:``}),[o,s]=(0,_.useState)(()=>typeof window<`u`&&window.innerWidth<=760),[c,l]=(0,_.useState)(!1);(0,_.useEffect)(()=>{let e=window.matchMedia(`(max-width: 760px)`),t=e=>{s(e.matches),e.matches||l(!1)};return s(e.matches),e.addEventListener(`change`,t),()=>e.removeEventListener(`change`,t)},[]);let u=e=>{let{name:i,value:o}=e.target;t(e=>({...e,[i]:o})),(i===`email`||i===`phone`)&&a(e=>({...e,[i]:``})),n&&r(!1)};return(0,M.jsxs)(`div`,{className:`contact-page`,children:[(0,M.jsxs)(`header`,{className:`navbar gryphon-standard-navbar`,children:[(0,M.jsxs)(`div`,{className:`nav-container`,children:[(0,M.jsx)(j,{to:`/`,className:`logo-link`,onClick:()=>l(!1),children:(0,M.jsx)(fr,{})}),!o&&(0,M.jsxs)(M.Fragment,{children:[(0,M.jsxs)(`nav`,{className:`nav-links`,children:[(0,M.jsx)(j,{to:`/`,children:`Home`}),(0,M.jsx)(j,{to:`/about`,children:`About`}),(0,M.jsx)(j,{to:`/services`,children:`Services`}),(0,M.jsx)(j,{to:`/solutions`,children:`Solutions`}),(0,M.jsx)(j,{to:`/engagements`,children:`Engagements`}),(0,M.jsx)(j,{to:`/training`,children:`Training`}),(0,M.jsx)(j,{to:`/contact`,className:`active`,children:`Contact`})]}),(0,M.jsxs)(j,{to:`/training/request`,className:`talk-button`,children:[`Request Training `,(0,M.jsx)(`span`,{children:`→`})]})]}),o&&(0,M.jsxs)(`button`,{type:`button`,className:`contact-mobile-toggle ${c?`open`:``}`,onClick:()=>l(e=>!e),"aria-label":c?`Close navigation`:`Open navigation`,"aria-expanded":c,children:[(0,M.jsx)(`span`,{}),(0,M.jsx)(`span`,{}),(0,M.jsx)(`span`,{})]})]}),o&&c&&(0,M.jsxs)(`div`,{className:`contact-mobile-menu`,children:[(0,M.jsx)(j,{to:`/`,onClick:()=>l(!1),children:`Home`}),(0,M.jsx)(j,{to:`/about`,onClick:()=>l(!1),children:`About`}),(0,M.jsx)(j,{to:`/services`,onClick:()=>l(!1),children:`Services`}),(0,M.jsx)(j,{to:`/solutions`,onClick:()=>l(!1),children:`Solutions`}),(0,M.jsx)(j,{to:`/engagements`,onClick:()=>l(!1),children:`Engagements`}),(0,M.jsx)(j,{to:`/training`,onClick:()=>l(!1),children:`Training`}),(0,M.jsx)(j,{to:`/contact`,className:`active`,onClick:()=>l(!1),children:`Contact`}),(0,M.jsxs)(j,{to:`/training/request`,className:`contact-mobile-talk`,onClick:()=>l(!1),children:[`Request Training`,(0,M.jsx)(`span`,{children:`→`})]})]})]}),(0,M.jsxs)(`main`,{children:[(0,M.jsxs)(`section`,{className:`contact-hero`,children:[(0,M.jsx)(`div`,{className:`contact-grid`}),(0,M.jsx)(`div`,{className:`contact-glow contact-glow-one`}),(0,M.jsx)(`div`,{className:`contact-glow contact-glow-two`}),(0,M.jsxs)(`div`,{className:`contact-hero-content`,children:[(0,M.jsxs)(`div`,{className:`contact-eyebrow contact-brand-label`,children:[(0,M.jsx)(`img`,{src:Un,alt:`Gryphon Cyber Logo`,className:`contact-brand-logo`}),(0,M.jsx)(`span`,{className:`contact-brand-text`,children:`GRYPHON CYBER • CONNECT`})]}),(0,M.jsxs)(`h1`,{children:[`Start the`,(0,M.jsx)(`span`,{children:`conversation.`})]}),(0,M.jsx)(`p`,{children:`Tell us what you are working on, what capability you need, or how Gryphon Cyber can support your organization.`}),(0,M.jsxs)(`div`,{className:`contact-meta`,children:[(0,M.jsxs)(`div`,{children:[(0,M.jsx)(`strong`,{children:`01`}),(0,M.jsx)(`span`,{children:`CONNECT`})]}),(0,M.jsxs)(`div`,{children:[(0,M.jsx)(`strong`,{children:`02`}),(0,M.jsx)(`span`,{children:`DISCUSS`})]}),(0,M.jsxs)(`div`,{children:[(0,M.jsx)(`strong`,{children:`03`}),(0,M.jsx)(`span`,{children:`RESPOND`})]})]})]}),(0,M.jsxs)(`div`,{className:`contact-command`,children:[(0,M.jsx)(`div`,{className:`contact-command-label`,children:`SECURE COMMUNICATION CHANNEL`}),(0,M.jsx)(`div`,{className:`contact-orbit contact-orbit-one`}),(0,M.jsx)(`div`,{className:`contact-orbit contact-orbit-two`}),(0,M.jsx)(`div`,{className:`contact-orbit contact-orbit-three`}),(0,M.jsx)(`div`,{className:`contact-core`,children:(0,M.jsx)(`img`,{src:Un,alt:`Gryphon Cyber`,className:`contact-core-logo`})}),(0,M.jsxs)(`div`,{className:`contact-node contact-node-one`,children:[(0,M.jsx)(`i`,{}),`CONNECT`]}),(0,M.jsxs)(`div`,{className:`contact-node contact-node-two`,children:[(0,M.jsx)(`i`,{}),`VERIFY`]}),(0,M.jsxs)(`div`,{className:`contact-node contact-node-three`,children:[(0,M.jsx)(`i`,{}),`RESPOND`]}),(0,M.jsx)(`div`,{className:`contact-scan`}),(0,M.jsxs)(`div`,{className:`contact-command-status`,children:[(0,M.jsx)(`i`,{}),`CHANNEL`,(0,M.jsx)(`strong`,{children:`READY`})]})]})]}),(0,M.jsxs)(`section`,{className:`contact-main`,children:[(0,M.jsxs)(`div`,{className:`contact-information`,children:[(0,M.jsx)(`div`,{className:`contact-section-label`,children:`01 — CONTACT GRYPHON`}),(0,M.jsxs)(`h2`,{children:[`Let's discuss`,(0,M.jsx)(`span`,{children:`the mission.`})]}),(0,M.jsx)(`p`,{children:`For enquiries, consultations, cybersecurity requirements, training programs and organizational engagements, contact the Gryphon Cyber team.`}),(0,M.jsxs)(`div`,{className:`contact-detail-list`,children:[(0,M.jsxs)(`a`,{href:`mailto:support@gryphoncyber.com`,className:`contact-detail`,children:[(0,M.jsx)(`div`,{className:`contact-detail-icon`,children:`@`}),(0,M.jsxs)(`div`,{children:[(0,M.jsx)(`small`,{children:`EMAIL`}),(0,M.jsx)(`strong`,{children:`support@gryphoncyber.com`})]}),(0,M.jsx)(`span`,{children:`↗`})]}),(0,M.jsxs)(`div`,{className:`contact-detail`,children:[(0,M.jsx)(`div`,{className:`contact-detail-icon`,children:`◎`}),(0,M.jsxs)(`div`,{children:[(0,M.jsx)(`small`,{children:`LOCATION`}),(0,M.jsx)(`strong`,{children:`New Delhi, India`})]}),(0,M.jsx)(`span`,{children:`•`})]}),(0,M.jsxs)(`a`,{href:`https\\://www.gryphoncyber.in`,target:`\\_blank`,rel:`noreferrer`,className:`contact-detail`,children:[(0,M.jsx)(`div`,{className:`contact-detail-icon`,children:`↗`}),(0,M.jsxs)(`div`,{children:[(0,M.jsx)(`small`,{children:`WEB`}),(0,M.jsx)(`strong`,{children:`www.gryphoncyber.in`})]}),(0,M.jsx)(`span`,{children:`↗`})]})]}),(0,M.jsxs)(`div`,{className:`contact-response`,children:[(0,M.jsx)(`span`,{}),(0,M.jsxs)(`div`,{children:[(0,M.jsx)(`strong`,{children:`DIRECT CHANNEL`}),(0,M.jsx)(`small`,{children:`Email the Gryphon Cyber team directly for enquiries.`})]})]})]}),(0,M.jsxs)(`div`,{className:`contact-form-wrap`,children:[(0,M.jsxs)(`div`,{className:`contact-form-top`,children:[(0,M.jsx)(`span`,{children:`02`}),(0,M.jsx)(`strong`,{children:`SEND AN ENQUIRY`}),(0,M.jsx)(`small`,{children:`RESPONSE CHANNEL / ACTIVE`})]}),(0,M.jsxs)(`form`,{onSubmit:async n=>{n.preventDefault();let i=/^[^\s@]+@[^\s@]+\.[^\s@]+$/,o=/^(?:\+91[\s-]?|0)?[6-9]\d{9}$/,s=e.email.trim(),c=e.phone.trim(),l={email:``,phone:``};if(i.test(s)||(l.email=`Please enter a valid email address.`),c){let e=c.replace(/[\s-]/g,``);o.test(e)||(l.phone=`Please enter a valid Indian mobile number.`)}if(l.email||l.phone){a(l),l.email&&l.phone?alert(`Please correct the following:

• Invalid email address
• Invalid Indian mobile number`):l.email?alert(`Please enter a valid email address.

Example: name@organization.com`):l.phone&&alert(`Please enter a valid Indian mobile number.

Example: 9876543210`);return}if(!e.name.trim()){alert(`Please enter your full name.`);return}if(!e.email.trim()){alert(`Please enter your email address.`);return}if(!e.subject){alert(`Please select an enquiry type.`);return}if(!e.message.trim()){alert(`Please enter your message.`);return}try{let n=await fetch(`http://localhost:5000/api/contact`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({name:e.name,organization:e.organization,email:e.email,phone:e.phone,subject:e.subject,message:e.message})}),i=await n.json();if(!n.ok)throw Error(i.message||`Unable to save enquiry.`);r(!0),alert(`Thank you.

Your enquiry has been submitted successfully and saved.`),t({name:``,organization:``,email:``,phone:``,subject:``,message:``}),a({email:``,phone:``})}catch(e){console.error(`Contact form error:`,e),alert(`Unable to submit your enquiry.

Please make sure the Gryphon Cyber backend server is running.`)}},className:`contact-form`,noValidate:!0,children:[(0,M.jsxs)(`div`,{className:`contact-field-grid`,children:[(0,M.jsxs)(`div`,{className:`contact-field`,children:[(0,M.jsx)(`label`,{children:`FULL NAME *`}),(0,M.jsx)(`input`,{type:`text`,name:`name`,value:e.name,onChange:u,placeholder:`Your name`,required:!0})]}),(0,M.jsxs)(`div`,{className:`contact-field`,children:[(0,M.jsx)(`label`,{children:`ORGANIZATION`}),(0,M.jsx)(`input`,{type:`text`,name:`organization`,value:e.organization,onChange:u,placeholder:`Organization / Department`})]}),(0,M.jsxs)(`div`,{className:`contact-field`,children:[(0,M.jsx)(`label`,{children:`EMAIL *`}),(0,M.jsx)(`input`,{type:`text`,name:`email`,value:e.email,onChange:u,placeholder:`name@organization.com`,required:!0,className:i.email?`input-error`:``}),i.email&&(0,M.jsx)(`span`,{className:`field-error`,children:i.email})]}),(0,M.jsxs)(`div`,{className:`contact-field`,children:[(0,M.jsx)(`label`,{children:`PHONE`}),(0,M.jsx)(`input`,{type:`tel`,name:`phone`,value:e.phone,onChange:u,placeholder:`+91 XXXXX XXXXX`,className:i.phone?`input-error`:``}),i.phone&&(0,M.jsx)(`span`,{className:`field-error`,children:i.phone})]})]}),(0,M.jsxs)(`div`,{className:`contact-field`,children:[(0,M.jsx)(`label`,{children:`SUBJECT *`}),(0,M.jsxs)(`select`,{name:`subject`,value:e.subject,onChange:u,required:!0,children:[(0,M.jsx)(`option`,{value:``,children:`Select enquiry type`}),(0,M.jsx)(`option`,{value:`Cybersecurity Services`,children:`Cybersecurity Services`}),(0,M.jsx)(`option`,{value:`Training`,children:`Training`}),(0,M.jsx)(`option`,{value:`Digital Transformation`,children:`Digital Transformation`}),(0,M.jsx)(`option`,{value:`Security Solutions`,children:`Security Solutions`}),(0,M.jsx)(`option`,{value:`Expert Consultation`,children:`Expert Consultation`}),(0,M.jsx)(`option`,{value:`General Enquiry`,children:`General Enquiry`})]})]}),(0,M.jsxs)(`div`,{className:`contact-field`,children:[(0,M.jsx)(`label`,{children:`MESSAGE *`}),(0,M.jsx)(`textarea`,{name:`message`,value:e.message,onChange:u,placeholder:`Tell us about your requirement...`,rows:`7`,required:!0})]}),(0,M.jsxs)(`div`,{className:`contact-submit-row`,children:[(0,M.jsxs)(`div`,{className:`contact-submit-status`,children:[(0,M.jsx)(`span`,{}),(0,M.jsxs)(`div`,{children:[(0,M.jsx)(`strong`,{children:n?`REQUEST SAVED`:`SECURE ENQUIRY`}),(0,M.jsx)(`small`,{children:n?`Your enquiry has been saved to the Gryphon Cyber records.`:`Your message will be securely submitted to the Gryphon Cyber team.`})]})]}),(0,M.jsxs)(`button`,{type:`submit`,className:`contact-submit`,children:[n?`SUBMITTED`:`SEND ENQUIRY`,(0,M.jsx)(`span`,{children:`→`})]})]})]})]})]}),(0,M.jsxs)(`section`,{className:`contact-capabilities`,children:[(0,M.jsxs)(`div`,{className:`contact-capabilities-header`,children:[(0,M.jsx)(`div`,{className:`contact-section-label`,children:`02 — HOW WE CAN ENGAGE`}),(0,M.jsxs)(`h2`,{children:[`One channel.`,(0,M.jsx)(`span`,{children:`Multiple capabilities.`})]})]}),(0,M.jsxs)(`div`,{className:`contact-capability-grid`,children:[(0,M.jsxs)(j,{to:`/services`,className:`contact-capability-card`,children:[(0,M.jsx)(`span`,{children:`01`}),(0,M.jsx)(`div`,{className:`contact-capability-icon`,children:(0,M.jsxs)(`svg`,{viewBox:`0 0 48 48`,fill:`none`,stroke:`currentColor`,strokeWidth:`1.8`,strokeLinecap:`round`,strokeLinejoin:`round`,"aria-hidden":`true`,children:[(0,M.jsx)(`path`,{d:`M24 8 9 20 24 40 39 20 24 8Z`}),(0,M.jsx)(`path`,{d:`M9 20h30M24 8v32M9 20l15 5 15-5`}),(0,M.jsx)(`circle`,{cx:`24`,cy:`8`,r:`2.5`,fill:`currentColor`}),(0,M.jsx)(`circle`,{cx:`9`,cy:`20`,r:`2.5`,fill:`currentColor`}),(0,M.jsx)(`circle`,{cx:`39`,cy:`20`,r:`2.5`,fill:`currentColor`}),(0,M.jsx)(`circle`,{cx:`24`,cy:`40`,r:`2.5`,fill:`currentColor`}),(0,M.jsx)(`circle`,{cx:`24`,cy:`25`,r:`2.5`,fill:`currentColor`})]})}),(0,M.jsx)(`h3`,{children:`Cybersecurity`}),(0,M.jsx)(`p`,{children:`Discuss security requirements, implementation and organizational cybersecurity needs.`}),(0,M.jsx)(`b`,{children:`EXPLORE SERVICES →`})]}),(0,M.jsxs)(j,{to:`/training`,className:`contact-capability-card`,children:[(0,M.jsx)(`span`,{children:`02`}),(0,M.jsx)(`div`,{className:`contact-capability-icon`,children:(0,M.jsxs)(`svg`,{viewBox:`0 0 48 48`,fill:`none`,stroke:`currentColor`,strokeWidth:`2`,strokeLinecap:`round`,strokeLinejoin:`round`,"aria-hidden":`true`,children:[(0,M.jsx)(`circle`,{cx:`20`,cy:`20`,r:`12`}),(0,M.jsx)(`circle`,{cx:`20`,cy:`20`,r:`6`}),(0,M.jsx)(`path`,{d:`m29 29 10 10`}),(0,M.jsx)(`path`,{d:`M20 14v12M14 20h12`})]})}),(0,M.jsx)(`h3`,{children:`Training`}),(0,M.jsx)(`p`,{children:`Explore practical training programs for investigative and cybersecurity capabilities.`}),(0,M.jsx)(`b`,{children:`EXPLORE TRAINING →`})]}),(0,M.jsxs)(j,{to:`/solutions`,className:`contact-capability-card`,children:[(0,M.jsx)(`span`,{children:`03`}),(0,M.jsx)(`div`,{className:`contact-capability-icon`,children:(0,M.jsxs)(`svg`,{viewBox:`0 0 48 48`,fill:`none`,stroke:`currentColor`,strokeWidth:`1.8`,strokeLinecap:`round`,strokeLinejoin:`round`,"aria-hidden":`true`,children:[(0,M.jsx)(`path`,{d:`m5 17 19-10 19 10-19 10L5 17Z`}),(0,M.jsx)(`path`,{d:`M13 22v11c7 7 15 7 22 0V22`}),(0,M.jsx)(`path`,{d:`M43 18v14`}),(0,M.jsx)(`circle`,{cx:`43`,cy:`34`,r:`2`,fill:`currentColor`})]})}),(0,M.jsx)(`h3`,{children:`Solutions`}),(0,M.jsx)(`p`,{children:`Explore Gryphon Cyber's operational technology and intelligence solutions.`}),(0,M.jsx)(`b`,{children:`EXPLORE SOLUTIONS →`})]}),(0,M.jsxs)(j,{to:`/training/request`,className:`contact-capability-card`,children:[(0,M.jsx)(`span`,{children:`04`}),(0,M.jsx)(`div`,{className:`contact-capability-icon`,children:(0,M.jsxs)(`svg`,{viewBox:`0 0 48 48`,fill:`none`,stroke:`currentColor`,strokeWidth:`1.8`,strokeLinecap:`round`,strokeLinejoin:`round`,"aria-hidden":`true`,children:[(0,M.jsx)(`path`,{d:`M24 5 40 11v12c0 10-7 17-16 21C15 40 8 33 8 23V11l16-6Z`}),(0,M.jsx)(`path`,{d:`m16 24 6 6 11-12`}),(0,M.jsx)(`path`,{d:`M8 11 24 18l16-7`})]})}),(0,M.jsx)(`h3`,{children:`Request Training`}),(0,M.jsx)(`p`,{children:`Send your organization's training requirement directly to the Gryphon Cyber team.`}),(0,M.jsx)(`b`,{children:`REQUEST TRAINING →`})]})]})]}),(0,M.jsxs)(`section`,{className:`contact-final`,children:[(0,M.jsx)(`div`,{className:`contact-final-glow`}),(0,M.jsx)(`div`,{className:`contact-section-label`,children:`GRYPHON CYBER`}),(0,M.jsxs)(`h2`,{children:[`Your requirement.`,(0,M.jsx)(`span`,{children:`Our response.`})]}),(0,M.jsxs)(`a`,{href:`mailto:support@gryphoncyber.com`,className:`contact-final-button`,children:[`Email Gryphon Cyber`,(0,M.jsx)(`span`,{children:`↗`})]})]})]}),(0,M.jsx)(dr,{}),(0,M.jsx)(`style`,{children:`
/* Contact capability cards — professional cyan line icons */
.contact-page .contact-capability-icon {
  width: 48px !important;
  height: 48px !important;
  min-width: 48px !important;
  display: flex !important;
  align-items: center !important;
  justify-content: center !important;
  box-sizing: border-box !important;
  color: #00d9ff !important;
  background: rgba(0, 190, 230, 0.07) !important;
  border: 1px solid rgba(0, 217, 255, 0.4) !important;
  border-radius: 0 !important;
}
.contact-page .contact-capability-icon svg {
  display: block !important;
  width: 29px !important;
  height: 29px !important;
  flex-shrink: 0 !important;
  color: #00d9ff !important;
  overflow: visible !important;
}
@media (max-width: 760px) {
  .contact-page .contact-capability-icon {
    width: 44px !important;
    height: 44px !important;
    min-width: 44px !important;
  }
  .contact-page .contact-capability-icon svg {
    width: 27px !important;
    height: 27px !important;
  }
}

/* Contact page mobile navigation */
.contact-mobile-toggle { display:flex; width:44px; height:44px; margin-left:auto; padding:0; border:1px solid rgba(255,255,255,.22); border-radius:10px; background:rgba(7,20,38,.9); align-items:center; justify-content:center; flex-direction:column; gap:5px; cursor:pointer; z-index:100001; }
.contact-mobile-toggle span { display:block; width:21px; height:2px; border-radius:2px; background:#fff; transition:transform .25s ease, opacity .25s ease; }
.contact-mobile-toggle.open span:nth-child(1) { transform:translateY(7px) rotate(45deg); }
.contact-mobile-toggle.open span:nth-child(2) { opacity:0; }
.contact-mobile-toggle.open span:nth-child(3) { transform:translateY(-7px) rotate(-45deg); }
.contact-mobile-menu { position:absolute; top:100%; left:0; right:0; display:flex; flex-direction:column; gap:4px; padding:14px 20px 20px; background:rgba(5,16,31,.98); border-top:1px solid rgba(255,255,255,.08); border-bottom:1px solid rgba(255,255,255,.1); box-shadow:0 18px 40px rgba(0,0,0,.35); z-index:100000; }
.contact-mobile-menu > a { display:flex; align-items:center; justify-content:space-between; min-height:48px; padding:0 14px; color:#fff !important; text-decoration:none; border-radius:8px; }
.contact-mobile-menu > a:hover, .contact-mobile-menu > a.active { background:rgba(23,100,232,.16); color:#fff !important; }
.contact-mobile-menu .contact-mobile-talk { justify-content:center; gap:10px; margin-top:10px; background:#1764e8 !important; color:#fff !important; font-weight:700; }
.contact-mobile-menu .contact-mobile-talk:hover { background:#2875f0 !important; color:#fff !important; }
@media (min-width:761px) { .contact-mobile-toggle, .contact-mobile-menu { display:none !important; } }
@media (max-width:760px) { .contact-page .navbar { position:relative; z-index:100000; } .contact-page .nav-container { position:relative; } }
@media (max-width:420px) { .contact-mobile-toggle { width:40px; height:40px; } .contact-mobile-menu { padding-left:14px; padding-right:14px; } }
      `})]})}function wr(){let[e,t]=(0,_.useState)(!1),[n,r]=(0,_.useState)(!1),[i,a]=(0,_.useState)(()=>typeof window<`u`&&window.matchMedia(`(max-width: 760px)`).matches);(0,_.useEffect)(()=>{let e=window.matchMedia(`(max-width: 760px)`),t=()=>a(e.matches);return t(),e.addEventListener(`change`,t),()=>e.removeEventListener(`change`,t)},[]);let[o,s]=(0,_.useState)({name:``,organization:``,email:``,phone:``,designation:``,demoType:``,preferredDate:``,preferredTime:``,requirements:``}),c=e=>{let{name:t,value:n}=e.target;s(e=>({...e,[t]:n}))};return(0,M.jsxs)(`div`,{className:`app book-demo-page`,children:[(0,M.jsx)(`style`,{children:`
        .book-demo-responsive-navbar {
          position: relative;
          z-index: 1000;
        }

        .book-demo-responsive-navbar .book-demo-nav-container {
          min-width: 0;
        }

        .book-demo-responsive-navbar .navbar-logo {
          max-width: 100%;
          height: auto;
          object-fit: contain;
        }

        .book-demo-mobile-toggle {
          display: flex;
          width: 44px;
          height: 44px;
          flex: 0 0 44px;
          padding: 11px;
          flex-direction: column;
          justify-content: center;
          gap: 5px;
          align-items: center;
          border: 1px solid #00c6e8;
          border-radius: 11px;
          background: #06111f;
          cursor: pointer;
        }

        .book-demo-mobile-toggle span {
          display: block;
          width: 19px;
          height: 2px;
          background: #fff;
          border-radius: 2px;
          transition: transform .2s ease, opacity .2s ease;
        }

        .book-demo-mobile-toggle.is-open span:first-child {
          transform: translateY(7px) rotate(45deg);
        }

        .book-demo-mobile-toggle.is-open span:nth-child(2) {
          opacity: 0;
        }

        .book-demo-mobile-toggle.is-open span:last-child {
          transform: translateY(-7px) rotate(-45deg);
        }

        .book-demo-mobile-menu {
          position: absolute;
          top: 100%;
          left: 0;
          right: 0;
          z-index: 1001;
          display: flex;
          flex-direction: column;
          gap: 4px;
          max-height: calc(100dvh - 76px);
          overflow-y: auto;
          padding: 14px 16px 18px;
          background: #04101f;
          border-top: 1px solid rgba(255,255,255,.1);
          border-bottom: 1px solid rgba(255,255,255,.12);
          box-shadow: 0 18px 35px rgba(0,0,0,.35);
        }

        .book-demo-mobile-menu > a {
          display: flex;
          align-items: center;
          justify-content: space-between;
          width: 100%;
          min-height: 46px;
          padding: 12px 14px;
          color: #edf4fb;
          text-decoration: none;
          border-radius: 9px;
          box-sizing: border-box;
        }

        .book-demo-mobile-menu > a:hover {
          background: rgba(0,198,232,.08);
          color: #00c6e8;
        }

        .book-demo-mobile-menu .book-demo-mobile-cta {
          justify-content: center;
          gap: 10px;
          margin-top: 8px;
          background: #1764e8;
          color: #fff;
          font-weight: 700;
          text-align: center;
        }

        .book-demo-mobile-menu .book-demo-mobile-cta:hover {
          background: #0877f9;
          color: #fff;
        }

        .book-demo-page,
        .book-demo-page * {
          box-sizing: border-box;
        }

        .book-demo-page {
          width: 100%;
          max-width: 100%;
          overflow-x: clip;
        }

        .book-demo-page .demo-container,
        .book-demo-page .demo-form,
        .book-demo-page .demo-form-grid,
        .book-demo-page .demo-form-section,
        .book-demo-page .demo-field {
          min-width: 0;
        }

        .book-demo-page input,
        .book-demo-page select,
        .book-demo-page textarea,
        .book-demo-page button {
          max-width: 100%;
          font: inherit;
        }

        .book-demo-page input,
        .book-demo-page select,
        .book-demo-page textarea {
          width: 100%;
        }

        @media (max-width: 760px) {

          .book-demo-responsive-navbar {
            width: 100%;
          }

          .book-demo-responsive-navbar .nav-container {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            width: 100%;
            min-height: 76px;
            padding: 12px 18px;
          }

          .book-demo-responsive-navbar .logo-link {
            display: flex;
            align-items: center;
            min-width: 0;
            max-width: calc(100% - 60px);
          }

          .book-demo-responsive-navbar .navbar-logo {
            width: auto;
            max-width: 150px;
            max-height: 48px;
          }

          .book-demo-page .demo-page {
            padding-left: 18px;
            padding-right: 18px;
          }

          .book-demo-page .demo-container {
            width: 100%;
            max-width: 100%;
          }

          .book-demo-page .demo-heading h1 {
            font-size: clamp(2.4rem, 11vw, 4rem);
            line-height: .98;
            overflow-wrap: anywhere;
          }

          .book-demo-page .demo-heading p {
            font-size: 14px;
            line-height: 1.8;
          }

          .book-demo-page .demo-form-grid {
            grid-template-columns: minmax(0, 1fr) !important;
            gap: 18px;
          }

          .book-demo-page .demo-form-section {
            padding: 20px 16px;
          }

          .book-demo-page .demo-field {
            width: 100%;
          }

          .book-demo-page .demo-field input,
          .book-demo-page .demo-field select,
          .book-demo-page .demo-field textarea {
            min-width: 0;
            width: 100%;
            font-size: 16px;
          }

          .book-demo-page .demo-submit-area {
            display: flex;
            flex-direction: column;
            align-items: stretch;
            gap: 16px;
          }

          .book-demo-page .demo-submit-button {
            width: 100%;
            justify-content: center;
          }

          .book-demo-page .footer-container {
            grid-template-columns: minmax(0, 1fr) !important;
            gap: 28px;
          }

          .book-demo-page .footer-bottom {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            gap: 8px;
          }
        }

        @media (min-width: 761px) and (max-width: 1024px) {

          .book-demo-page .demo-form-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
          }

          .book-demo-responsive-navbar .nav-container {
            gap: 16px;
          }

          .book-demo-responsive-navbar .nav-links {
            gap: 14px;
          }
        }

        @media (prefers-reduced-motion: reduce) {
          .book-demo-mobile-toggle span {
            transition: none;
          }
        }
      `}),(0,M.jsxs)(`header`,{className:`navbar book-demo-responsive-navbar gryphon-standard-navbar`,children:[(0,M.jsxs)(`div`,{className:`nav-container book-demo-nav-container`,children:[(0,M.jsx)(j,{to:`/`,className:`logo-link`,onClick:()=>r(!1),children:(0,M.jsx)(fr,{})}),!i&&(0,M.jsxs)(M.Fragment,{children:[(0,M.jsxs)(`nav`,{className:`nav-links`,children:[(0,M.jsx)(j,{to:`/`,children:`Home`}),(0,M.jsx)(j,{to:`/about`,children:`About`}),(0,M.jsx)(j,{to:`/services`,children:`Services`}),(0,M.jsx)(j,{to:`/solutions`,children:`Solutions`}),(0,M.jsx)(j,{to:`/engagements`,children:`Engagements`}),(0,M.jsx)(j,{to:`/training`,children:`Training`}),(0,M.jsx)(j,{to:`/contact`,children:`Contact`})]}),(0,M.jsxs)(j,{to:`/book-demo`,className:`demo-button active-demo-button`,children:[`Book a Demo`,(0,M.jsx)(`span`,{children:`→`})]})]}),i&&(0,M.jsxs)(`button`,{type:`button`,className:`book-demo-mobile-toggle ${n?`is-open`:``}`,"aria-label":n?`Close navigation menu`:`Open navigation menu`,"aria-expanded":n,onClick:()=>r(e=>!e),children:[(0,M.jsx)(`span`,{}),(0,M.jsx)(`span`,{}),(0,M.jsx)(`span`,{})]})]}),i&&n&&(0,M.jsxs)(`nav`,{className:`book-demo-mobile-menu`,"aria-label":`Mobile navigation`,children:[(0,M.jsx)(j,{to:`/`,onClick:()=>r(!1),children:`Home`}),(0,M.jsx)(j,{to:`/about`,onClick:()=>r(!1),children:`About`}),(0,M.jsx)(j,{to:`/services`,onClick:()=>r(!1),children:`Services`}),(0,M.jsx)(j,{to:`/solutions`,onClick:()=>r(!1),children:`Solutions`}),(0,M.jsx)(j,{to:`/engagements`,onClick:()=>r(!1),children:`Engagements`}),(0,M.jsx)(j,{to:`/training`,onClick:()=>r(!1),children:`Training`}),(0,M.jsx)(j,{to:`/contact`,onClick:()=>r(!1),children:`Contact`}),(0,M.jsxs)(j,{to:`/book-demo`,className:`book-demo-mobile-cta`,onClick:()=>r(!1),children:[`Book a Demo`,(0,M.jsx)(`span`,{children:`→`})]})]})]}),(0,M.jsx)(`main`,{children:(0,M.jsxs)(`section`,{className:`demo-page`,children:[(0,M.jsx)(`div`,{className:`demo-background-grid`}),(0,M.jsx)(`div`,{className:`demo-glow`}),(0,M.jsxs)(`div`,{className:`demo-container`,children:[(0,M.jsxs)(`div`,{className:`demo-heading`,children:[(0,M.jsx)(`div`,{className:`demo-label`,children:`GRYPHON CYBER • DEMONSTRATION`}),(0,M.jsxs)(`h1`,{children:[`Book a`,(0,M.jsx)(`span`,{children:`private demo.`})]}),(0,M.jsx)(`p`,{children:`Tell us about your organization and requirements. Our team will arrange a focused demonstration of the relevant Gryphon Cyber capabilities.`})]}),e?(0,M.jsxs)(`div`,{className:`demo-success`,children:[(0,M.jsx)(`div`,{className:`demo-success-icon`,children:`✓`}),(0,M.jsxs)(`div`,{children:[(0,M.jsx)(`div`,{className:`demo-success-label`,children:`REQUEST RECEIVED`}),(0,M.jsx)(`h2`,{children:`Thank you.`}),(0,M.jsx)(`p`,{children:`Your demo request has been recorded. Our team will review the information and coordinate the next steps.`}),(0,M.jsx)(`button`,{type:`button`,className:`demo-secondary-button`,onClick:()=>{t(!1),s({name:``,organization:``,email:``,phone:``,designation:``,demoType:``,preferredDate:``,preferredTime:``,requirements:``})},children:`Submit another request`})]})]}):(0,M.jsxs)(`form`,{className:`demo-form`,onSubmit:async e=>{e.preventDefault();try{let e=await fetch(`http://localhost:5000/api/book-demo`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({name:o.name,organization:o.organization,designation:o.designation,email:o.email,phone:o.phone,demoType:o.demoType,preferredDate:o.preferredDate,preferredTime:o.preferredTime,requirements:o.requirements})}),n=await e.json();if(!e.ok)throw Error(n.message||`Unable to save demo request.`);t(!0),window.scrollTo({top:0,behavior:`smooth`})}catch(e){console.error(`Book Demo submission error:`,e),alert(`Unable to submit your demo request.

Please make sure the Gryphon Cyber backend server is running.`)}},children:[(0,M.jsxs)(`div`,{className:`demo-form-section`,children:[(0,M.jsxs)(`div`,{className:`demo-form-section-title`,children:[`01`,(0,M.jsx)(`span`,{children:`CONTACT INFORMATION`})]}),(0,M.jsxs)(`div`,{className:`demo-form-grid`,children:[(0,M.jsxs)(`div`,{className:`demo-field`,children:[(0,M.jsx)(`label`,{htmlFor:`name`,children:`Full Name *`}),(0,M.jsx)(`input`,{id:`name`,name:`name`,type:`text`,placeholder:`Enter your full name`,value:o.name,onChange:c,required:!0})]}),(0,M.jsxs)(`div`,{className:`demo-field`,children:[(0,M.jsx)(`label`,{htmlFor:`designation`,children:`Designation`}),(0,M.jsx)(`input`,{id:`designation`,name:`designation`,type:`text`,placeholder:`Your designation`,value:o.designation,onChange:c})]}),(0,M.jsxs)(`div`,{className:`demo-field`,children:[(0,M.jsx)(`label`,{htmlFor:`organization`,children:`Organization *`}),(0,M.jsx)(`input`,{id:`organization`,name:`organization`,type:`text`,placeholder:`Organization / Department`,value:o.organization,onChange:c,required:!0})]}),(0,M.jsxs)(`div`,{className:`demo-field`,children:[(0,M.jsx)(`label`,{htmlFor:`email`,children:`Official Email *`}),(0,M.jsx)(`input`,{id:`email`,name:`email`,type:`email`,placeholder:`name@organization.com`,value:o.email,onChange:c,required:!0})]}),(0,M.jsxs)(`div`,{className:`demo-field`,children:[(0,M.jsx)(`label`,{htmlFor:`phone`,children:`Phone Number *`}),(0,M.jsx)(`input`,{id:`phone`,name:`phone`,type:`tel`,placeholder:`+91 XXXXX XXXXX`,value:o.phone,onChange:c,required:!0})]})]})]}),(0,M.jsxs)(`div`,{className:`demo-form-section`,children:[(0,M.jsxs)(`div`,{className:`demo-form-section-title`,children:[`02`,(0,M.jsx)(`span`,{children:`DEMONSTRATION DETAILS`})]}),(0,M.jsxs)(`div`,{className:`demo-form-grid`,children:[(0,M.jsxs)(`div`,{className:`demo-field`,children:[(0,M.jsx)(`label`,{htmlFor:`demoType`,children:`Area of Interest *`}),(0,M.jsxs)(`select`,{id:`demoType`,name:`demoType`,value:o.demoType,onChange:c,required:!0,children:[(0,M.jsx)(`option`,{value:``,children:`Select an area`}),(0,M.jsx)(`option`,{value:`SAKSHAM`,children:`SAKSHAM — Predictive Intelligence`}),(0,M.jsx)(`option`,{value:`SPIDER`,children:`SPIDER — Unified Intelligence Search`}),(0,M.jsx)(`option`,{value:`OVERSIGHT`,children:`OVERSIGHT — Network Analysis`}),(0,M.jsx)(`option`,{value:`LAWSYNC`,children:`LawSync — Digital Policing`}),(0,M.jsx)(`option`,{value:`Cyber Security`,children:`Cyber Security`}),(0,M.jsx)(`option`,{value:`Training`,children:`Training Programs`}),(0,M.jsx)(`option`,{value:`Custom`,children:`Custom Requirement`})]})]}),(0,M.jsxs)(`div`,{className:`demo-field`,children:[(0,M.jsx)(`label`,{htmlFor:`preferredDate`,children:`Preferred Date *`}),(0,M.jsx)(`input`,{id:`preferredDate`,name:`preferredDate`,type:`date`,value:o.preferredDate,onChange:c,required:!0})]}),(0,M.jsxs)(`div`,{className:`demo-field`,children:[(0,M.jsx)(`label`,{htmlFor:`preferredTime`,children:`Preferred Time *`}),(0,M.jsxs)(`select`,{id:`preferredTime`,name:`preferredTime`,value:o.preferredTime,onChange:c,required:!0,children:[(0,M.jsx)(`option`,{value:``,children:`Select a time`}),(0,M.jsx)(`option`,{value:`10:00 AM`,children:`10:00 AM`}),(0,M.jsx)(`option`,{value:`11:00 AM`,children:`11:00 AM`}),(0,M.jsx)(`option`,{value:`12:00 PM`,children:`12:00 PM`}),(0,M.jsx)(`option`,{value:`2:00 PM`,children:`2:00 PM`}),(0,M.jsx)(`option`,{value:`3:00 PM`,children:`3:00 PM`}),(0,M.jsx)(`option`,{value:`4:00 PM`,children:`4:00 PM`}),(0,M.jsx)(`option`,{value:`5:00 PM`,children:`5:00 PM`})]})]})]})]}),(0,M.jsxs)(`div`,{className:`demo-form-section`,children:[(0,M.jsxs)(`div`,{className:`demo-form-section-title`,children:[`03`,(0,M.jsx)(`span`,{children:`REQUIREMENTS`})]}),(0,M.jsxs)(`div`,{className:`demo-field`,children:[(0,M.jsx)(`label`,{htmlFor:`requirements`,children:`Tell us about your requirement`}),(0,M.jsx)(`textarea`,{id:`requirements`,name:`requirements`,rows:`6`,placeholder:`Briefly describe your use case, operational requirement, or the capabilities you would like to explore.`,value:o.requirements,onChange:c})]})]}),(0,M.jsxs)(`div`,{className:`demo-submit-area`,children:[(0,M.jsx)(`p`,{children:`By submitting this form, you are requesting a demonstration and follow-up from Gryphon Cyber.`}),(0,M.jsxs)(`button`,{type:`submit`,className:`demo-submit-button`,children:[`Request Demo`,(0,M.jsx)(`span`,{children:`→`})]})]})]})]})]})}),(0,M.jsx)(dr,{})]})}function Tr(){let[e,t]=(0,_.useState)(!1),[n,r]=(0,_.useState)(!1),[i,a]=(0,_.useState)(!1);(0,_.useEffect)(()=>{let e=window.matchMedia(`(max-width: 760px)`),t=()=>{r(e.matches),e.matches||a(!1)};return t(),e.addEventListener(`change`,t),()=>{e.removeEventListener(`change`,t)}},[]);let o=()=>a(!1),[s,c]=(0,_.useState)({email:``,phone:``}),[l,u]=(0,_.useState)({name:``,organization:``,designation:``,email:``,phone:``,trainingArea:``,participants:``,preferredDate:``,mode:``,message:``}),d=n=>{let{name:r,value:i}=n.target;u(e=>({...e,[r]:i})),(r===`email`||r===`phone`)&&c(e=>({...e,[r]:``})),e&&t(!1)};return(0,M.jsxs)(`div`,{className:`app request-training-page`,children:[(0,M.jsx)(`style`,{children:`

        .request-training-page {

          width: 100%;

          min-width: 0;

          overflow-x: hidden;

        }

        .request-training-page .request-mobile-toggle,

        .request-training-page .request-mobile-menu {

          display: none;

        }

        .request-training-page .request-mobile-toggle {

          border: 1px solid rgba(0, 191, 255, 0.75);

          background: #02070d;

          color: #fff;

          width: 44px;

          height: 44px;

          border-radius: 10px;

          padding: 0;

          align-items: center;

          justify-content: center;

          flex-direction: column;

          gap: 5px;

          cursor: pointer;

          flex-shrink: 0;

        }

        .request-training-page .request-mobile-toggle span {

          width: 19px;

          height: 2px;

          background: #fff;

          border-radius: 2px;

          transition: transform 0.2s ease, opacity 0.2s ease;

        }

        .request-training-page .request-mobile-toggle.open span:nth-child(1) {

          transform: translateY(7px) rotate(45deg);

        }

        .request-training-page .request-mobile-toggle.open span:nth-child(2) {

          opacity: 0;

        }

        .request-training-page .request-mobile-toggle.open span:nth-child(3) {

          transform: translateY(-7px) rotate(-45deg);

        }

        @media (max-width: 760px) {

          .request-training-page {

            font-size: 15px;

          }

          .request-training-page .request-training-navbar {

            position: relative;

            z-index: 1000;

            width: 100%;

          }

          .request-training-page .request-training-navbar .nav-container {

            width: 100%;

            min-height: 72px;

            height: auto;

            padding: 12px 18px;

            box-sizing: border-box;

            display: flex;

            align-items: center;

            justify-content: space-between;

            gap: 14px;

          }

          .request-training-page .request-training-navbar .logo-link {

            min-width: 0;

            flex: 1;

          }

          .request-training-page .request-training-navbar .logo-link {

            flex: 0 1 auto;

            max-width: calc(100% - 58px);

          }

          .request-training-page .request-training-navbar .navbar-logo {

            width: 88px;

            min-width: 88px;

            max-width: 88px;

            height: 64px;

            max-height: 64px;

            object-fit: contain;

          }

          .request-training-page .request-training-navbar .navbar-company-name {

            display: flex;

            flex-direction: column;

            justify-content: center;

            gap: 2px;

            min-width: 0;

            white-space: nowrap;

          }

          .request-training-page .request-training-navbar .navbar-company-main {

            font-size: 13px;

            line-height: 1.15;

            letter-spacing: 0.3px;

          }

          .request-training-page .request-training-navbar .navbar-company-sub {

            font-size: 8px;

            line-height: 1.4;

            letter-spacing: 2px;

          }

          .request-training-page .request-mobile-toggle {

            display: flex;

          }

          .request-training-page .request-mobile-menu {

            position: absolute;

            top: 100%;

            left: 0;

            width: 100%;

            box-sizing: border-box;

            padding: 12px 14px 16px;

            background: #030b16;

            border-top: 1px solid rgba(255, 255, 255, 0.08);

            border-bottom: 1px solid rgba(0, 191, 255, 0.18);

            box-shadow: 0 18px 35px rgba(0, 0, 0, 0.42);

            display: block;

            max-height: calc(100vh - 72px);

            overflow-y: auto;

            opacity: 0;

            visibility: hidden;

            pointer-events: none;

            transform: translateY(-8px);

            transition: opacity 0.22s ease, transform 0.22s ease, visibility 0.22s ease;

          }

          .request-training-page .request-mobile-menu.open {

            opacity: 1;

            visibility: visible;

            pointer-events: auto;

            transform: translateY(0);

          }

          .request-training-page .request-mobile-menu nav {

            display: flex;

            flex-direction: column;

            gap: 4px;

          }

          .request-training-page .request-mobile-menu nav a {

            display: block;

            width: 100%;

            box-sizing: border-box;

            padding: 13px 14px;

            border-radius: 8px;

            color: #e7edf5;

            text-decoration: none;

            font-size: 15px;

            line-height: 1.2;

          }

          .request-training-page .request-mobile-menu nav a:hover,

          .request-training-page .request-mobile-menu nav a:focus-visible {

            background: rgba(23, 100, 232, 0.16);

          }

          .request-training-page .request-mobile-training {

            display: flex;

            width: 100%;

            box-sizing: border-box;

            margin-top: 10px;

            padding: 14px 16px;

            align-items: center;

            justify-content: center;

            gap: 10px;

            border-radius: 8px;

            background: #1764e8 !important;

            color: #fff !important;

            text-decoration: none;

            font-weight: 700;

            font-size: 14px;

          }

          .request-training-page .request-mobile-training span {

            font-size: 18px;

          }

          .request-training-page .request-training-hero {

            min-height: auto;

            padding: 78px 20px 70px;

            display: flex;

            flex-direction: column;

            gap: 0;

          }

          .request-training-page .request-hero-content {

            width: 100%;

            max-width: none;

          }

          .request-training-page .request-eyebrow {

            font-size: 10px;

            letter-spacing: 0.14em;

            line-height: 1.5;

          }

          .request-training-page .request-hero-content h1 {

            max-width: 100%;

            margin: 18px 0 20px;

            font-size: clamp(46px, 13vw, 72px);

            line-height: 0.94;

            overflow-wrap: anywhere;

          }

          .request-training-page .request-hero-content p {

            max-width: 100%;

            font-size: 14px;

            line-height: 1.75;

          }

          .request-training-page .request-hero-meta {

            width: 100%;

            display: grid;

            grid-template-columns: repeat(3, minmax(0, 1fr));

            gap: 12px;

            margin-top: 30px;

          }

          .request-training-page .request-hero-meta strong {

            font-size: 14px;

          }

          .request-training-page .request-hero-meta span {

            font-size: 8px;

            letter-spacing: 0.13em;

          }

          .request-training-page .request-command {

            width: min(100%, 330px);

            height: 330px;

            margin: 55px auto 0;

            transform: scale(0.9);

            transform-origin: center top;

          }

          .request-training-page .request-form-section,

          .request-training-page .request-process {

            padding-left: 20px;

            padding-right: 20px;

          }

          .request-training-page .request-form-section {

            padding-top: 72px;

            padding-bottom: 72px;

          }

          .request-training-page .request-form-header h2,

          .request-training-page .request-process-header h2 {

            font-size: clamp(42px, 11vw, 62px);

            line-height: 0.98;

          }

          .request-training-page .request-form-header p {

            max-width: 100%;

            font-size: 14px;

            line-height: 1.7;

          }

          .request-training-page .training-request-form {

            width: 100%;

          }

          .request-training-page .form-block {

            padding: 24px 0;

          }

          .request-training-page .form-grid {

            display: grid !important;

            grid-template-columns: minmax(0, 1fr) !important;

            gap: 20px;

          }

          .request-training-page .form-field {

            min-width: 0;

            width: 100%;

          }

          .request-training-page .form-field input,

          .request-training-page .form-field select,

          .request-training-page .form-field textarea {

            width: 100%;

            max-width: 100%;

            box-sizing: border-box;

            font-size: 16px;

          }

          .request-training-page .form-field textarea {

            min-height: 170px;

            resize: vertical;

          }

          .request-training-page .request-submit-area {

            display: flex;

            flex-direction: column;

            align-items: stretch;

            gap: 24px;

            padding-top: 24px;

          }

          .request-training-page .request-submit-info {

            width: 100%;

          }

          .request-training-page .request-submit-button {

            width: 100%;

            min-height: 54px;

            box-sizing: border-box;

            justify-content: center;

          }

          .request-training-page .request-process {

            padding-top: 72px;

            padding-bottom: 72px;

          }

          .request-training-page .request-process-flow {

            display: grid !important;

            grid-template-columns: minmax(0, 1fr) !important;

            gap: 14px;

            margin-top: 36px;

          }

          .request-training-page .request-process-card {

            width: 100%;

            min-width: 0;

            box-sizing: border-box;

          }

          .request-training-page .request-process-connector {

            display: none !important;

          }

          .request-training-page .request-bottom-cta {

            padding: 72px 20px;

          }

          .request-training-page .request-bottom-cta h2 {

            font-size: clamp(42px, 11vw, 62px);

            line-height: 0.98;

          }

          .request-training-page .request-back-button {

            max-width: 100%;

            box-sizing: border-box;

          }

          .request-training-page .site-footer {

            overflow: hidden;

          }

          .request-training-page .footer-container {

            width: 100%;

            box-sizing: border-box;

            grid-template-columns: repeat(2, minmax(0, 1fr));

            gap: 34px 20px;

            padding-left: 20px;

            padding-right: 20px;

          }

          .request-training-page .footer-brand {

            grid-column: 1 / -1;

          }

          .request-training-page .footer-bottom {

            padding: 18px 20px;

            display: flex;

            flex-direction: column;

            align-items: flex-start;

            gap: 8px;

          }

        }

        @media (max-width: 480px) {

          .request-training-page .request-training-navbar .nav-container {

            padding-left: 14px;

            padding-right: 14px;

          }

          .request-training-page .request-training-hero {

            padding-left: 16px;

            padding-right: 16px;

          }

          .request-training-page .request-hero-content h1 {

            font-size: clamp(43px, 14vw, 60px);

          }

          .request-training-page .request-command {

            width: min(100%, 300px);

            height: 300px;

            transform: scale(0.86);

            margin-bottom: -35px;

          }

          .request-training-page .request-form-section,

          .request-training-page .request-process,

          .request-training-page .request-bottom-cta {

            padding-left: 16px;

            padding-right: 16px;

          }

          .request-training-page .footer-container {

            grid-template-columns: minmax(0, 1fr);

          }

          .request-training-page .footer-brand {

            grid-column: auto;

          }

        }

      `}),(0,M.jsx)(`header`,{className:`navbar request-training-navbar gryphon-standard-navbar`,children:(0,M.jsxs)(`div`,{className:`nav-container`,children:[(0,M.jsx)(j,{to:`/`,className:`logo-link`,onClick:o,children:(0,M.jsx)(fr,{})}),!n&&(0,M.jsxs)(M.Fragment,{children:[(0,M.jsxs)(`nav`,{className:`nav-links`,children:[(0,M.jsx)(j,{to:`/`,children:`Home`}),(0,M.jsx)(j,{to:`/about`,children:`About`}),(0,M.jsx)(j,{to:`/services`,children:`Services`}),(0,M.jsx)(j,{to:`/solutions`,children:`Solutions`}),(0,M.jsx)(j,{to:`/training`,className:`active`,children:`Training`}),(0,M.jsx)(j,{to:`/contact`,children:`Contact`})]}),(0,M.jsxs)(j,{to:`/contact`,className:`talk-button`,children:[`Talk to Us `,(0,M.jsx)(`span`,{children:`→`})]})]}),n&&(0,M.jsxs)(M.Fragment,{children:[(0,M.jsxs)(`button`,{type:`button`,className:`request-mobile-toggle ${i?`open`:``}`,onClick:()=>a(e=>!e),"aria-label":i?`Close navigation menu`:`Open navigation menu`,"aria-expanded":i,children:[(0,M.jsx)(`span`,{}),(0,M.jsx)(`span`,{}),(0,M.jsx)(`span`,{})]}),(0,M.jsxs)(`div`,{className:`request-mobile-menu ${i?`open`:``}`,children:[(0,M.jsxs)(`nav`,{children:[(0,M.jsx)(j,{to:`/`,onClick:o,children:`Home`}),(0,M.jsx)(j,{to:`/about`,onClick:o,children:`About`}),(0,M.jsx)(j,{to:`/services`,onClick:o,children:`Services`}),(0,M.jsx)(j,{to:`/solutions`,onClick:o,children:`Solutions`}),(0,M.jsx)(j,{to:`/training`,onClick:o,children:`Training`}),(0,M.jsx)(j,{to:`/contact`,onClick:o,children:`Contact`})]}),(0,M.jsxs)(j,{to:`/training/request`,className:`request-mobile-training active`,onClick:o,children:[`Request Training `,(0,M.jsx)(`span`,{children:`→`})]})]})]})]})}),(0,M.jsxs)(`main`,{children:[(0,M.jsxs)(`section`,{className:`request-training-hero`,children:[(0,M.jsx)(`div`,{className:`request-grid`}),(0,M.jsx)(`div`,{className:`request-glow`}),(0,M.jsxs)(`div`,{className:`request-hero-content`,children:[(0,M.jsxs)(`div`,{className:`request-eyebrow`,children:[(0,M.jsx)(`span`,{}),`GRYPHON CYBER • TRAINING REQUEST`]}),(0,M.jsxs)(`h1`,{children:[`Build your`,(0,M.jsx)(`span`,{children:`training program.`})]}),(0,M.jsx)(`p`,{children:`Tell us about your team's training requirements and we'll help structure a program around your operational needs.`}),(0,M.jsxs)(`div`,{className:`request-hero-meta`,children:[(0,M.jsxs)(`div`,{children:[(0,M.jsx)(`strong`,{children:`01`}),(0,M.jsx)(`span`,{children:`REQUIREMENT`})]}),(0,M.jsxs)(`div`,{children:[(0,M.jsx)(`strong`,{children:`02`}),(0,M.jsx)(`span`,{children:`PLANNING`})]}),(0,M.jsxs)(`div`,{children:[(0,M.jsx)(`strong`,{children:`03`}),(0,M.jsx)(`span`,{children:`EXECUTION`})]})]})]}),(0,M.jsxs)(`div`,{className:`request-command`,children:[(0,M.jsx)(`div`,{className:`request-command-label`,children:`TRAINING INTAKE SYSTEM`}),(0,M.jsx)(`div`,{className:`request-orbit orbit-one`}),(0,M.jsx)(`div`,{className:`request-orbit orbit-two`}),(0,M.jsx)(`div`,{className:`request-orbit orbit-three`}),(0,M.jsx)(`div`,{className:`request-command-core`,children:(0,M.jsx)(`span`,{children:`GC`})}),(0,M.jsxs)(`div`,{className:`request-command-node node-one`,children:[(0,M.jsx)(`span`,{}),`01`]}),(0,M.jsxs)(`div`,{className:`request-command-node node-two`,children:[(0,M.jsx)(`span`,{}),`02`]}),(0,M.jsxs)(`div`,{className:`request-command-node node-three`,children:[(0,M.jsx)(`span`,{}),`03`]}),(0,M.jsx)(`div`,{className:`request-command-line line-one`}),(0,M.jsx)(`div`,{className:`request-command-line line-two`}),(0,M.jsx)(`div`,{className:`request-command-line line-three`}),(0,M.jsxs)(`div`,{className:`request-command-status`,children:[(0,M.jsx)(`span`,{}),`INTAKE SYSTEM`,(0,M.jsx)(`strong`,{children:`READY`})]})]})]}),(0,M.jsxs)(`section`,{className:`request-form-section`,children:[(0,M.jsxs)(`div`,{className:`request-form-header`,children:[(0,M.jsx)(`div`,{className:`request-section-label`,children:`01 — TRAINING REQUIREMENT`}),(0,M.jsxs)(`h2`,{children:[`Tell us what`,(0,M.jsx)(`span`,{children:`you need.`})]}),(0,M.jsx)(`p`,{children:`Provide the details below so the Gryphon Cyber team can understand your training requirement.`})]}),(0,M.jsxs)(`form`,{className:`training-request-form`,onSubmit:async e=>{e.preventDefault();let n=/^[^\s@]+@[^\s@]+\.[^\s@]+$/,r=/^(?:\+?91[\s-]?|0)?[6-9]\d{9}$/,i=l.email.trim(),a=l.phone.trim().replace(/[\s-]/g,``),o={email:``,phone:``};if(n.test(i)||(o.email=`Please enter a valid email address.`),r.test(a)||(o.phone=`Please enter a valid Indian mobile number.`),o.email||o.phone){c(o),o.email&&o.phone?alert(`Please correct the following:

• Invalid email address
• Invalid Indian mobile number`):o.email?alert(`Please enter a valid email address.

Example: name@organization.com`):o.phone&&alert(`Please enter a valid Indian mobile number.

Example: 9876543210`);return}try{let e=await fetch(`http://localhost:5000/api/training-request`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({name:l.name,organization:l.organization,designation:l.designation,email:l.email,phone:l.phone,trainingArea:l.trainingArea,participants:l.participants,preferredDate:l.preferredDate,mode:l.mode,message:l.message})}),n=await e.json();if(!e.ok)throw Error(n.message||`Unable to save training request.`);t(!0),alert(`Training request submitted successfully.

Your request has been saved.`),u({name:``,organization:``,designation:``,email:``,phone:``,trainingArea:``,participants:``,preferredDate:``,mode:``,message:``}),c({email:``,phone:``})}catch(e){console.error(`Training request error:`,e),alert(`Unable to submit your training request.

Please make sure the Gryphon Cyber backend server is running.`)}},noValidate:!0,children:[(0,M.jsxs)(`div`,{className:`form-block`,children:[(0,M.jsxs)(`div`,{className:`form-block-header`,children:[(0,M.jsx)(`span`,{children:`01`}),(0,M.jsx)(`div`,{children:`CONTACT & ORGANIZATION`})]}),(0,M.jsxs)(`div`,{className:`form-grid`,children:[(0,M.jsxs)(`div`,{className:`form-field`,children:[(0,M.jsx)(`label`,{children:`FULL NAME *`}),(0,M.jsx)(`input`,{type:`text`,name:`name`,value:l.name,onChange:d,placeholder:`Enter your full name`,required:!0})]}),(0,M.jsxs)(`div`,{className:`form-field`,children:[(0,M.jsx)(`label`,{children:`ORGANIZATION *`}),(0,M.jsx)(`input`,{type:`text`,name:`organization`,value:l.organization,onChange:d,placeholder:`Organization / Department`,required:!0})]}),(0,M.jsxs)(`div`,{className:`form-field`,children:[(0,M.jsx)(`label`,{children:`DESIGNATION`}),(0,M.jsx)(`input`,{type:`text`,name:`designation`,value:l.designation,onChange:d,placeholder:`Your designation`})]}),(0,M.jsxs)(`div`,{className:`form-field`,children:[(0,M.jsx)(`label`,{children:`EMAIL *`}),(0,M.jsx)(`input`,{type:`text`,name:`email`,value:l.email,onChange:d,placeholder:`name@organization.com`,required:!0,className:s.email?`input-error`:``}),s.email&&(0,M.jsx)(`span`,{className:`field-error`,children:s.email})]}),(0,M.jsxs)(`div`,{className:`form-field`,children:[(0,M.jsx)(`label`,{children:`PHONE NUMBER *`}),(0,M.jsx)(`input`,{type:`tel`,name:`phone`,value:l.phone,onChange:d,placeholder:`+91 XXXXX XXXXX`,required:!0,className:s.phone?`input-error`:``}),s.phone&&(0,M.jsx)(`span`,{className:`field-error`,children:s.phone})]})]})]}),(0,M.jsxs)(`div`,{className:`form-block`,children:[(0,M.jsxs)(`div`,{className:`form-block-header`,children:[(0,M.jsx)(`span`,{children:`02`}),(0,M.jsx)(`div`,{children:`TRAINING REQUIREMENT`})]}),(0,M.jsxs)(`div`,{className:`form-grid`,children:[(0,M.jsxs)(`div`,{className:`form-field`,children:[(0,M.jsx)(`label`,{children:`TRAINING AREA *`}),(0,M.jsxs)(`select`,{name:`trainingArea`,value:l.trainingArea,onChange:d,required:!0,children:[(0,M.jsx)(`option`,{value:``,children:`Select training area`}),(0,M.jsx)(`option`,{value:`Cyber Investigation`,children:`Cyber Investigation`}),(0,M.jsx)(`option`,{value:`Forensic Analysis`,children:`Forensic Analysis`}),(0,M.jsx)(`option`,{value:`Scenario Simulation`,children:`Scenario Simulation`}),(0,M.jsx)(`option`,{value:`Interview Skills`,children:`Interview Skills`}),(0,M.jsx)(`option`,{value:`Multiple Areas`,children:`Multiple Training Areas`})]})]}),(0,M.jsxs)(`div`,{className:`form-field`,children:[(0,M.jsx)(`label`,{children:`PARTICIPANTS *`}),(0,M.jsx)(`input`,{type:`number`,name:`participants`,value:l.participants,onChange:d,placeholder:`Number of participants`,min:`1`,required:!0})]}),(0,M.jsxs)(`div`,{className:`form-field`,children:[(0,M.jsx)(`label`,{children:`PREFERRED DATE`}),(0,M.jsx)(`input`,{type:`date`,name:`preferredDate`,value:l.preferredDate,onChange:d})]}),(0,M.jsxs)(`div`,{className:`form-field`,children:[(0,M.jsx)(`label`,{children:`TRAINING MODE`}),(0,M.jsxs)(`select`,{name:`mode`,value:l.mode,onChange:d,children:[(0,M.jsx)(`option`,{value:``,children:`Select mode`}),(0,M.jsx)(`option`,{value:`On-site`,children:`On-site`}),(0,M.jsx)(`option`,{value:`Online`,children:`Online`}),(0,M.jsx)(`option`,{value:`Hybrid`,children:`Hybrid`})]})]})]})]}),(0,M.jsxs)(`div`,{className:`form-block`,children:[(0,M.jsxs)(`div`,{className:`form-block-header`,children:[(0,M.jsx)(`span`,{children:`03`}),(0,M.jsx)(`div`,{children:`ADDITIONAL REQUIREMENTS`})]}),(0,M.jsxs)(`div`,{className:`form-field`,children:[(0,M.jsx)(`label`,{children:`TELL US ABOUT YOUR REQUIREMENT`}),(0,M.jsx)(`textarea`,{name:`message`,value:l.message,onChange:d,placeholder:`Tell us about your team, objectives, preferred topics or any specific requirements...`,rows:`7`})]})]}),(0,M.jsxs)(`div`,{className:`request-submit-area`,children:[(0,M.jsxs)(`div`,{className:`request-submit-info`,children:[(0,M.jsx)(`span`,{className:`request-submit-dot`}),(0,M.jsxs)(`div`,{children:[(0,M.jsx)(`strong`,{children:`READY TO BEGIN`}),(0,M.jsx)(`small`,{children:`Your request will be saved securely to the Gryphon Cyber training records.`})]})]}),(0,M.jsxs)(`button`,{type:`submit`,className:`request-submit-button`,children:[e?`REQUEST SAVED`:`SUBMIT TRAINING REQUEST`,(0,M.jsx)(`span`,{children:`→`})]})]})]})]}),(0,M.jsxs)(`section`,{className:`request-process`,children:[(0,M.jsxs)(`div`,{className:`request-process-header`,children:[(0,M.jsx)(`div`,{className:`request-section-label`,children:`02 — WHAT HAPPENS NEXT`}),(0,M.jsxs)(`h2`,{children:[`From request`,(0,M.jsx)(`span`,{children:`to training.`})]})]}),(0,M.jsxs)(`div`,{className:`request-process-flow`,children:[(0,M.jsxs)(`div`,{className:`request-process-card`,children:[(0,M.jsx)(`span`,{children:`01`}),(0,M.jsx)(`div`,{className:`request-process-icon`,children:`◇`}),(0,M.jsx)(`h3`,{children:`Request`}),(0,M.jsx)(`p`,{children:`Share your team's training requirements with Gryphon Cyber.`})]}),(0,M.jsx)(`div`,{className:`request-process-connector`}),(0,M.jsxs)(`div`,{className:`request-process-card`,children:[(0,M.jsx)(`span`,{children:`02`}),(0,M.jsx)(`div`,{className:`request-process-icon`,children:`◎`}),(0,M.jsx)(`h3`,{children:`Discuss`}),(0,M.jsx)(`p`,{children:`Discuss objectives, participants and training requirements.`})]}),(0,M.jsx)(`div`,{className:`request-process-connector`}),(0,M.jsxs)(`div`,{className:`request-process-card`,children:[(0,M.jsx)(`span`,{children:`03`}),(0,M.jsx)(`div`,{className:`request-process-icon`,children:`+`}),(0,M.jsx)(`h3`,{children:`Structure`}),(0,M.jsx)(`p`,{children:`Structure the training around the identified requirements.`})]}),(0,M.jsx)(`div`,{className:`request-process-connector`}),(0,M.jsxs)(`div`,{className:`request-process-card`,children:[(0,M.jsx)(`span`,{children:`04`}),(0,M.jsx)(`div`,{className:`request-process-icon`,children:`→`}),(0,M.jsx)(`h3`,{children:`Execute`}),(0,M.jsx)(`p`,{children:`Deliver practical training focused on investigative capability.`})]})]})]}),(0,M.jsxs)(`section`,{className:`request-bottom-cta`,children:[(0,M.jsx)(`div`,{className:`request-bottom-glow`}),(0,M.jsxs)(`div`,{children:[(0,M.jsx)(`div`,{className:`request-section-label`,children:`GRYPHON CYBER`}),(0,M.jsxs)(`h2`,{children:[`Ready to build`,(0,M.jsx)(`span`,{children:`capability?`})]}),(0,M.jsxs)(j,{to:`/training`,className:`request-back-button`,children:[`Back to Training`,(0,M.jsx)(`span`,{children:`←`})]})]})]})]}),(0,M.jsx)(dr,{})]})}var Er=[{src:`/engagements/police/police-training-01.jpeg`,title:`Cybersecurity Training`,description:`Cybersecurity awareness and technology-focused training for law enforcement personnel.`},{src:`/engagements/police/police-training-02.jpeg`,title:`Law Enforcement Engagement`,description:`Practical engagement with frontline security and law enforcement teams.`},{src:`/engagements/police/police-training-03.jpeg`,title:`Knowledge & Awareness`,description:`Sharing knowledge around emerging cyber threats and digital investigations.`}],Dr=[{src:`/engagements/leadership/leadership-01.jpeg`,title:`Cybersecurity Seminar`,description:`Gryphon Cyber leadership participating in cybersecurity discussions and seminars.`},{src:`/engagements/leadership/leadership-02.jpeg`,title:`Industry Engagement`,description:`Connecting with cybersecurity professionals and industry stakeholders.`},{src:`/engagements/leadership/leadership-03.jpeg`,title:`Strategic Discussions`,description:`Leadership engagement around emerging security challenges and technologies.`},{src:`/engagements/leadership/leadership-04.jpeg`,title:`Cybersecurity Community`,description:`Participating in forums that shape the future of cybersecurity.`}],Or=[{src:`/engagements/events/event-01.png`,title:`Industry Forum`,description:`Participation in technology and cybersecurity forums.`},{src:`/engagements/events/event-02.jpeg`,title:`Professional Collaboration`,description:`Building meaningful relationships across the security ecosystem.`},{src:`/engagements/events/event-03.jpeg`,title:`Cybersecurity Engagement`,description:`Gryphon Cyber participating in cybersecurity and technology-focused engagements.`}];function kr({image:e,index:t,onOpen:n}){return(0,M.jsxs)(`article`,{className:`engagement-image-card ${t===0?`engagement-featured-card`:``}`,onClick:()=>n(e),children:[(0,M.jsxs)(`div`,{className:`engagement-image-wrapper`,children:[(0,M.jsx)(`img`,{src:e.src,alt:e.title,loading:`lazy`,onError:e=>{e.currentTarget.style.display=`none`,e.currentTarget.parentElement.classList.add(`engagement-image-missing`)}}),(0,M.jsxs)(`div`,{className:`engagement-image-placeholder`,children:[(0,M.jsx)(`span`,{className:`placeholder-icon`,children:`GC`}),(0,M.jsx)(`span`,{children:`Add Engagement Image`})]}),(0,M.jsx)(`div`,{className:`engagement-image-overlay`,children:(0,M.jsxs)(`span`,{className:`view-image`,children:[`View Image `,(0,M.jsx)(`span`,{children:`↗`})]})})]}),(0,M.jsxs)(`div`,{className:`engagement-card-content`,children:[(0,M.jsx)(`span`,{className:`engagement-card-number`,children:String(t+1).padStart(2,`0`)}),(0,M.jsxs)(`div`,{children:[(0,M.jsx)(`h3`,{children:e.title}),(0,M.jsx)(`p`,{children:e.description})]})]})]})}function Ar({eyebrow:e,title:t,description:n,images:r,sectionClass:i=``,onOpen:a}){return(0,M.jsxs)(`section`,{className:`engagement-section ${i}`,children:[(0,M.jsxs)(`div`,{className:`engagement-section-heading`,children:[(0,M.jsxs)(`div`,{className:`engagement-section-eyebrow`,children:[(0,M.jsx)(`span`,{}),e]}),(0,M.jsx)(`h2`,{children:t}),(0,M.jsx)(`p`,{children:n})]}),(0,M.jsx)(`div`,{className:`engagement-gallery`,children:r.map((e,t)=>(0,M.jsx)(kr,{image:e,index:t,onOpen:a},`${e.title}-${t}`))})]})}function jr(){let[e,t]=(0,_.useState)(null),[n,r]=(0,_.useState)(!1),[i,a]=(0,_.useState)(()=>typeof window<`u`&&window.innerWidth<=760);(0,_.useEffect)(()=>{let e=window.matchMedia(`(max-width: 760px)`),t=e=>{a(e.matches),e.matches||r(!1)};return a(e.matches),e.addEventListener(`change`,t),()=>{e.removeEventListener(`change`,t)}},[]);let o=()=>{t(null)};return(0,M.jsxs)(`div`,{className:`engagements-page`,children:[(0,M.jsxs)(`header`,{className:`navbar gryphon-standard-navbar`,children:[(0,M.jsxs)(`div`,{className:`nav-container`,children:[(0,M.jsx)(j,{to:`/`,className:`logo-link`,onClick:()=>r(!1),children:(0,M.jsx)(fr,{})}),!i&&(0,M.jsxs)(M.Fragment,{children:[(0,M.jsxs)(`nav`,{className:`nav-links`,"aria-label":`Main navigation`,children:[(0,M.jsx)(j,{to:`/`,children:`Home`}),(0,M.jsx)(j,{to:`/about`,children:`About`}),(0,M.jsx)(j,{to:`/services`,children:`Services`}),(0,M.jsx)(j,{to:`/solutions`,children:`Solutions`}),(0,M.jsx)(j,{to:`/engagements`,className:`active`,children:`Engagements`}),(0,M.jsx)(j,{to:`/training`,children:`Training`}),(0,M.jsx)(j,{to:`/contact`,children:`Contact`})]}),(0,M.jsxs)(j,{to:`/contact`,className:`talk-button`,children:[`Talk to Us`,(0,M.jsx)(`span`,{children:`→`})]})]}),i&&(0,M.jsxs)(`button`,{type:`button`,className:`services-mobile-toggle ${n?`open`:``}`,"aria-label":n?`Close navigation menu`:`Open navigation menu`,"aria-expanded":n,onClick:()=>r(!n),children:[(0,M.jsx)(`span`,{}),(0,M.jsx)(`span`,{}),(0,M.jsx)(`span`,{})]})]}),i&&n&&(0,M.jsxs)(`div`,{className:`services-mobile-menu`,children:[(0,M.jsx)(j,{to:`/`,onClick:()=>r(!1),children:`Home`}),(0,M.jsx)(j,{to:`/about`,onClick:()=>r(!1),children:`About`}),(0,M.jsx)(j,{to:`/services`,onClick:()=>r(!1),children:`Services`}),(0,M.jsx)(j,{to:`/solutions`,onClick:()=>r(!1),children:`Solutions`}),(0,M.jsx)(j,{to:`/engagements`,className:`mobile-active`,onClick:()=>r(!1),children:`Engagements`}),(0,M.jsx)(j,{to:`/training`,onClick:()=>r(!1),children:`Training`}),(0,M.jsx)(j,{to:`/contact`,onClick:()=>r(!1),children:`Contact`}),(0,M.jsxs)(j,{to:`/contact`,className:`services-mobile-talk`,onClick:()=>r(!1),children:[`Talk to Us`,(0,M.jsx)(`span`,{children:`→`})]})]})]}),(0,M.jsxs)(`main`,{children:[(0,M.jsxs)(`section`,{className:`engagements-hero`,children:[(0,M.jsx)(`div`,{className:`engagements-hero-grid`}),(0,M.jsx)(`div`,{className:`engagements-hero-glow glow-one`}),(0,M.jsx)(`div`,{className:`engagements-hero-glow glow-two`}),(0,M.jsxs)(`div`,{className:`engagements-hero-content`,children:[(0,M.jsxs)(`div`,{className:`engagements-eyebrow`,children:[(0,M.jsx)(`span`,{className:`eyebrow-dot`}),`REAL-WORLD CYBERSECURITY ENGAGEMENTS`]}),(0,M.jsxs)(`h1`,{children:[`Beyond the Screen.`,(0,M.jsx)(`br`,{}),(0,M.jsx)(`span`,{children:`Into the Field.`})]}),(0,M.jsx)(`p`,{children:`Cybersecurity is not limited to technology and systems. Gryphon Cyber actively engages with law enforcement, security professionals, industry leaders and organizations to strengthen awareness, knowledge and operational readiness.`}),(0,M.jsxs)(`div`,{className:`engagements-hero-stats`,children:[(0,M.jsxs)(`div`,{className:`hero-stat`,children:[(0,M.jsx)(`strong`,{children:`01`}),(0,M.jsx)(`span`,{children:`Field Training`})]}),(0,M.jsxs)(`div`,{className:`hero-stat`,children:[(0,M.jsx)(`strong`,{children:`02`}),(0,M.jsx)(`span`,{children:`Industry Engagement`})]}),(0,M.jsxs)(`div`,{className:`hero-stat`,children:[(0,M.jsx)(`strong`,{children:`03`}),(0,M.jsx)(`span`,{children:`Leadership`})]})]})]})]}),(0,M.jsxs)(`section`,{className:`engagements-intro`,children:[(0,M.jsx)(`div`,{className:`intro-line`}),(0,M.jsxs)(`div`,{className:`intro-content`,children:[(0,M.jsx)(`span`,{className:`section-label`,children:`GRYPHON CYBER IN ACTION`}),(0,M.jsxs)(`h2`,{children:[`Turning Knowledge Into`,(0,M.jsx)(`span`,{children:` Real-World Impact.`})]}),(0,M.jsx)(`p`,{children:`Our engagement extends beyond the digital environment. Through training programs, cybersecurity seminars, professional forums and strategic interactions, Gryphon Cyber works with people and organizations at the forefront of today's security challenges.`})]})]}),(0,M.jsx)(Ar,{eyebrow:`LAW ENFORCEMENT`,title:`Empowering Those on the Front Lines`,description:`Gryphon Cyber conducts cybersecurity awareness, technology and knowledge-sharing engagements with law enforcement and security personnel, helping frontline teams better understand emerging digital threats and cyber-enabled challenges.`,images:Er,sectionClass:`police-section`,onOpen:t}),(0,M.jsx)(Ar,{eyebrow:`LEADERSHIP & INDUSTRY`,title:`Leadership in the Cybersecurity Community`,description:`Our leadership actively participates in cybersecurity seminars, conferences, professional forums and strategic discussions, staying connected with emerging technologies, threats and the evolving security landscape.`,images:Dr,sectionClass:`leadership-section`,onOpen:t}),(0,M.jsx)(Ar,{eyebrow:`EVENTS & COLLABORATION`,title:`Connecting. Learning. Advancing.`,description:`From professional events to knowledge-sharing sessions, Gryphon Cyber continues to connect with the wider cybersecurity ecosystem and contribute to meaningful conversations around digital security.`,images:Or,sectionClass:`events-section`,onOpen:t}),(0,M.jsxs)(`section`,{className:`engagements-cta`,children:[(0,M.jsx)(`div`,{className:`cta-grid`}),(0,M.jsxs)(`div`,{className:`cta-content`,children:[(0,M.jsx)(`span`,{className:`section-label`,children:`THE NEXT ENGAGEMENT`}),(0,M.jsxs)(`h2`,{children:[`Building a More`,(0,M.jsx)(`span`,{children:` Resilient Digital Environment.`})]}),(0,M.jsx)(`p`,{children:`Explore how Gryphon Cyber can support your organization's cybersecurity, intelligence and operational requirements.`}),(0,M.jsxs)(j,{to:`/contact`,className:`engagement-cta-button`,children:[(0,M.jsx)(`span`,{children:`Talk to Gryphon Cyber`}),(0,M.jsx)(`strong`,{children:`→`})]})]})]})]}),(0,M.jsx)(dr,{}),e&&(0,M.jsxs)(`div`,{className:`engagement-lightbox`,onClick:o,children:[(0,M.jsx)(`button`,{type:`button`,className:`lightbox-close`,onClick:o,"aria-label":`Close image`,children:`×`}),(0,M.jsxs)(`div`,{className:`lightbox-content`,onClick:e=>e.stopPropagation(),children:[(0,M.jsx)(`img`,{src:e.src,alt:e.title}),(0,M.jsxs)(`div`,{className:`lightbox-caption`,children:[(0,M.jsx)(`span`,{children:e.title}),(0,M.jsx)(`p`,{children:e.description})]})]})]})]})}function Mr({children:e}){let t=bt();return(0,M.jsx)(`div`,{className:`gryphon-page-transition`,children:e},t.pathname)}function Nr(){return(0,M.jsx)(Mr,{children:(0,M.jsxs)(qt,{children:[(0,M.jsx)(k,{path:`/`,element:(0,M.jsx)(pr,{})}),(0,M.jsx)(k,{path:`/about`,element:(0,M.jsx)(hr,{})}),(0,M.jsx)(k,{path:`/services`,element:(0,M.jsx)(gr,{})}),(0,M.jsx)(k,{path:`/solutions`,element:(0,M.jsx)(br,{})}),(0,M.jsx)(k,{path:`/training`,element:(0,M.jsx)(Sr,{})}),(0,M.jsx)(k,{path:`/contact`,element:(0,M.jsx)(Cr,{})}),(0,M.jsx)(k,{path:`/engagements`,element:(0,M.jsx)(jr,{})}),(0,M.jsx)(k,{path:`/book-demo`,element:(0,M.jsx)(wr,{})}),(0,M.jsx)(k,{path:`/training/request`,element:(0,M.jsx)(Tr,{})})]})})}function Pr(){return(0,M.jsx)(jn,{children:(0,M.jsx)(Nr,{})})}(0,v.createRoot)(document.getElementById(`root`)).render((0,M.jsx)(_.StrictMode,{children:(0,M.jsx)(Pr,{})}));